import java.awt.*;
import java.util.*;
import java.awt.event.*;
import java.lang.*;
import java.io.*;
import java.net.*;
import javax.swing.*;
import java.math.*;
import java.text.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import javax.swing.JComponent;
import javax.swing.JFrame;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

class myCanvas extends JComponent {
    int screenWidth, screenHeight, windowWidth, windowHeight;

    public static final Color myRed = new Color(200, 0, 0);
    public static final Color myBlue = new Color(0, 128, 255);
    public static final Color myGreen = new Color(0, 0, 0); //Color(50, 200, 50);

    public static final int SQUARE = 0;
    public static final int TRIANGLE = 1;
    public static final int CIRCLE = 2;
    public static final int RED = 0;
    public static final int BLUE = 1;
    public static final int GREEN = 2;

    public static final int NEUTRAL_FACE = 0;
    public static final int HAPPY_FACE = 1;
    public static final int SAD_FACE = 2;
    public static final int ANGRY_FACE = 3;
    public static final int SURPRISED_FACE = 4;

    boolean[][] theTable = new boolean[3][3];
    int[][] zerosBlocks = new int[9][2];
    int[][] onesBlocks = new int[9][2];
    int num0sBlocks = 0, num1sBlocks = 0;

    int[][][] M = new int[2][2][2];

    int numPastRounds = 0;
    int[][] histScores = new int[50][2];
    String[][][] histActions = new String[50][3][2];

    int plyrNum, currentTurn;
    boolean gameOver = false;

    String elPartido = "blockDilemma";
    boolean readIt = false;
    int action0Commit = -1, action1Commit = -1;

    public myCanvas(int _screenWidth, int _screenHeight, int _plyrNum) {
        //System.out.println("MyCanvas");
        screenWidth = 500;//_screenWidth;
        screenHeight = 240;//_screenHeight;
        windowWidth = _screenWidth;
        windowHeight = _screenHeight;
        plyrNum = _plyrNum;

        MyThread thread = new MyThread();
        thread.start(); //loopDLoo();

        try {
            Thread.sleep(500);
        } catch (InterruptedException e) {
            System.out.println(e);
        }
    }

    public class MyThread extends Thread {
        public void run() {
            try {
                // repeatedly read Table.txt and Said.txt
                while (true) {
                    determineGame();

                    if (elPartido.equals("blockDilemma")) {
                        updateTable();
                    }
                    else {
                        if (!readIt)
                            readPayoffMatrix();

                        readActionCommit();
                    }
                    updateHistory();
                    updateGameOver();

                    repaint();
                    Thread.sleep(313);
                }
            }
            catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }

    public void determineGame() {
        try {
            String file = "../SimulatedWorld/elPartido.txt";
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String elGame = reader.readLine();
            if (elGame.equals(elPartido))
                readIt = true;
            else
                readIt = false;
            elPartido = elGame;
            reader.close();
        }
        catch (IOException e) {
            System.out.println(e);
        }
    }

    public void registerClick(int x, int y) {
        if (elPartido.equals("blockDilemma")) {
            if ((currentTurn != plyrNum) || !ready2Act()) {
                System.out.println("Not your turn");
                return;
            }

            int cc = -1, cs = -1;

            if ((x > 153) && (x < 198))
                cc = RED;
            else if ((x > 227) && (x < 272))
                cc = BLUE;
            else if ((x > 300) && (x < 345))
                cc = GREEN;

            if ((y > 18) && (y < 64))
                cs = SQUARE;
            else if ((y > 81) && (y < 127))
                cs = TRIANGLE;
            else if ((y > 144) && (y < 191))
                cs = CIRCLE;

            if ((cc > -1) && (cs > -1)) {
                if (theTable[cc][cs]) {
                    // System.out.println("Selected block " + cc + ", " + cs);

                    // log the action
                    try {
                        // now write the information to the appropriate robotactuators file
                        String fnombre = "../SimulatedWorld/action" + plyrNum + ".tmp";
                        BufferedWriter writer = new BufferedWriter(new FileWriter(fnombre));		

                        writer.write("" + (cs * 3 + cc));

                        writer.close();

                        Process process = Runtime.getRuntime().exec("mv ../SimulatedWorld/action" + plyrNum + ".tmp ../SimulatedWorld/action" + plyrNum + ".txt");
                    }
                    catch (IOException e) {
                        System.out.println(e);
                    }		
                }
            }
        }
        else {
            // dealing with a matrix game
            // System.out.println("matrix game");
            int a = -1;
            if (plyrNum == 0) {
                // System.out.println(x + ", " + y);
                if ((x > 44) && (x < 124) && (y > 71) && (y < 117)) {
                    // System.out.println("action 0");
                    a = 0;
                }
                else if ((x > 44) && (x < 124) && (y > 138) && (y < 185)) {
                    // System.out.println("action 1");
                    a = 1;
                }
            }
            else {
                // System.out.println(x + ", " + y);
                if ((x > 175) && (x < 255) && (y > 11) && (y < 55)) {
                    // System.out.println("action 0");
                    a = 0;
                }
                else if ((x > 337) && (x < 418) && (y > 11) && (y < 55)) {
                    // System.out.println("action 1");
                    a = 1;
                }
            }

            if (a != -1) {
                // log the action
                try {
                    // now write the information to the appropriate robotactuators file
                    String fnombre = "../SimulatedWorld/action" + plyrNum + ".tmp";
                    BufferedWriter writer = new BufferedWriter(new FileWriter(fnombre));		

                    writer.write("" + a);

                    writer.close();

                    Process process = Runtime.getRuntime().exec("mv ../SimulatedWorld/action" + plyrNum + ".tmp ../SimulatedWorld/action" + plyrNum + ".txt");
                }
                catch (IOException e) {
                    System.out.println(e);
                }		
            }
        }
    }

    public boolean ready2Act() {
        try {
            String file = "../SimulatedWorld/action" + plyrNum + ".txt";

            BufferedReader reader = new BufferedReader(new FileReader(file));

            String buf;
            buf = reader.readLine();

            reader.close();

            if (buf.equals("?"))
                return true;
            else
                return false;
        }
        catch (IOException e) {
            System.out.println(e);
        }

        return false;
    }

    // read in Table.txt and store in theTable, zerosBlocks, onesBlocks
    public void updateTable() {
        try {
            //System.out.println("loopDLoo");

            String file = "../SimulatedWorld/Table.txt";

            BufferedReader reader = new BufferedReader(new FileReader(file));

            String[] buf = new String[12];

            for (int i = 0; i < 12; i++) {
                buf[i] = reader.readLine();
            }
            if (buf[11] == null) {
                System.out.println("failed to update GUI");
                return;
            }
            else if (!buf[11].equals("$$")) {
                System.out.println("failed to update GUI");
                return;
            }

            initializeState();

            // first line of table: buf[1]
            registerBlock(buf[1].substring(0, 2));
            registerBlock(buf[1].substring(3, 5));
            registerBlock(buf[1].substring(6, 8));
            registerBlock(buf[2].substring(0, 2));
            registerBlock(buf[2].substring(3, 5));
            registerBlock(buf[2].substring(6, 8));
            registerBlock(buf[3].substring(0, 2));
            registerBlock(buf[3].substring(3, 5));
            registerBlock(buf[3].substring(6, 8));

            register0sBlocks(buf[6]);
            register1sBlocks(buf[9]);

            reader.close();

            if ((num0sBlocks == 3) && (num1sBlocks == 3))
                currentTurn = -1;
            else if (num0sBlocks == num1sBlocks)
                currentTurn = 0;
            else
                currentTurn = 1;
        }
        catch (IOException e) {
            System.out.println(e);
        }
    }

    // read in Table.txt and store in theTable, zerosBlocks, onesBlocks
    public void updateHistory() {
        numPastRounds = 0;
        try {
            //System.out.println("loopDLoo");

            String file = "../SimulatedWorld/History.txt";

            BufferedReader reader = new BufferedReader(new FileReader(file));

            String buf;
            
            while ((buf = reader.readLine()) != null) {
                StringTokenizer st = new StringTokenizer(buf," ");

                if (st.hasMoreTokens()) {
                    for (int i = 0; i < 3; i++)
                        histActions[numPastRounds][i][0] = st.nextToken();
                    st.nextToken();
                    for (int i = 0; i < 3; i++)
                        histActions[numPastRounds][i][1] = st.nextToken();
                    st.nextToken();
                    double v1 = Double.parseDouble(st.nextToken());
                    double v2 = Double.parseDouble(st.nextToken());
                    histScores[numPastRounds][0] = (int)(v1 + 0.5);//Integer.parseInt(st.nextToken());
                    histScores[numPastRounds][1] = (int)(v2 + 0.5);//Integer.parseInt(st.nextToken());

                    numPastRounds ++;
                }
            }

            reader.close();

            // for (int i = 0; i < numPastRounds; i++) {
            //     System.out.println(histActions[i][0][0] + " " + histActions[i][1][0] + " " + histActions[i][2][0] + " | " + histActions[i][0][1] + " " + histActions[i][1][1] + " " + histActions[i][2][1] + " -> " + histScores[i][0] + " " + histScores[i][1]);
            // }
        }
        catch (IOException e) {
            // System.out.println(e);
        }
    }

    // read in Table.txt and store in theTable, zerosBlocks, onesBlocks
    public void readPayoffMatrix() {
        try {
            //System.out.println("loopDLoo");

            String file = "../SimulatedWorld/Games/" + elPartido + ".txt";

            BufferedReader reader = new BufferedReader(new FileReader(file));

            String buf;
            buf = reader.readLine();
            StringTokenizer st = new StringTokenizer(buf," ");
            M[0][0][0] = Integer.parseInt(st.nextToken());
            M[0][1][0] = Integer.parseInt(st.nextToken());

            buf = reader.readLine();
            st = new StringTokenizer(buf," ");
            M[1][0][0] = Integer.parseInt(st.nextToken());
            M[1][1][0] = Integer.parseInt(st.nextToken());

            buf = reader.readLine();
            
            buf = reader.readLine();
            st = new StringTokenizer(buf," ");
            M[0][0][1] = Integer.parseInt(st.nextToken());
            M[0][1][1] = Integer.parseInt(st.nextToken());

            buf = reader.readLine();
            st = new StringTokenizer(buf," ");
            M[1][0][1] = Integer.parseInt(st.nextToken());
            M[1][1][1] = Integer.parseInt(st.nextToken());

            reader.close();

            for (int i = 0; i < 2; i++) {
                for (int j = 0; j < 2; j++) {
                    System.out.print(M[i][j][0]);
                    System.out.print(", ");
                    System.out.print(M[i][j][1]);
                    System.out.print("   ");
                }
                System.out.println();
            }
            System.out.println();
        }
        catch (IOException e) {
            System.out.println(e);
        }
    }    

    public void updateGameOver() {
        try {
            //System.out.println("loopDLoo");

            String file = "../SimulatedWorld/gameOver.txt";

            BufferedReader reader = new BufferedReader(new FileReader(file));

            String buf = reader.readLine();

            if (buf.equals("true"))
                gameOver = true;
            else
                gameOver = false;

            reader.close();
        }
        catch (IOException e) {
            // System.out.println(e);
        }
    }

    public void readActionCommit() {
        try {
            String file = "../SimulatedWorld/actionCommit.txt";

            BufferedReader reader = new BufferedReader(new FileReader(file));

            String buf = reader.readLine();

            StringTokenizer st = new StringTokenizer(buf," ");

            action0Commit = Integer.parseInt(st.nextToken());
            action1Commit = Integer.parseInt(st.nextToken());

            reader.close();
        }
        catch (IOException e) {
            // System.out.println(e);
        }
    }

    public void initializeState() {
        int x, y;
        for (x = 0; x < 3; x++) {
            for (y = 0; y < 3; y++) {
                theTable[x][y] = false;
            }
        }

        num0sBlocks = num1sBlocks = 0;
    }

    public void registerBlock(String blck) {
        //System.out.println(blck);

        int x = -1, y = -1;
        switch (blck.charAt(0)) {
            case 'r': x = RED; break;
            case 'b': x = BLUE; break;
            case 'g': x = GREEN; break;
            default: return;
        }

        switch (blck.charAt(1)) {
            case 's': y = SQUARE; break;
            case 't': y = TRIANGLE; break;
            case 'c': y = CIRCLE; break;
            default: return;
        }

        //System.out.println(x + ", " + y);

        theTable[x][y] = true;
    }

    public void set0sBlock(String blck) {
        int x = -1, y = -1;
        switch (blck.charAt(0)) {
            case 'r': x = RED; break;
            case 'b': x = BLUE; break;
            case 'g': x = GREEN; break;
            default: return;
        }

        switch (blck.charAt(1)) {
            case 's': y = SQUARE; break;
            case 't': y = TRIANGLE; break;
            case 'c': y = CIRCLE; break;
            default: return;
        }

        //System.out.println(x + ", " + y);

        zerosBlocks[num0sBlocks][0] = x;
        zerosBlocks[num0sBlocks][1] = y;
        num0sBlocks ++;
    }

    public void register0sBlocks(String str) {
        //System.out.println(str.length());

        int i = 0;
        while ((i+1) < str.length()) {
            set0sBlock(str.substring(i, i+2));
            i += 3;
        }
    }

    public void set1sBlock(String blck) {
        int x = -1, y = -1;
        switch (blck.charAt(0)) {
            case 'r': x = RED; break;
            case 'b': x = BLUE; break;
            case 'g': x = GREEN; break;
            default: return;
        }

        switch (blck.charAt(1)) {
            case 's': y = SQUARE; break;
            case 't': y = TRIANGLE; break;
            case 'c': y = CIRCLE; break;
            default: return;
        }

        //System.out.println(x + ", " + y);

        onesBlocks[num1sBlocks][0] = x;
        onesBlocks[num1sBlocks][1] = y;
        num1sBlocks ++;
    }

    public void register1sBlocks(String str) {
        //System.out.println(str.length());

        int i = 0;
        while ((i+1) < str.length()) {
            set1sBlock(str.substring(i, i+2));
            i += 3;
        }
    }

    public void fillTriangle(Graphics g, int left, int top, int sx, int sy) {
        int xpoints[] = {left + sx/2, left + sx, left, left + sx/2};
        int ypoints[] = {top, top + sy, top + sy, top};
        int npoints = 4;

        g.fillPolygon(xpoints, ypoints, npoints);
    }

    public void drawTheBlock(Graphics g, int x, int y, int dx, int dy, boolean writeValue) {
        g.setColor(new Color(240, 240, 240));
        g.fillRect(dx-23, dy-23, 46, 46);

        int dim1 = 0, dim2 = 0;
        int offset = 0;

        switch (x) {
            case RED: 
                g.setColor(myRed);
                dim1 = 0;
                break;
            case BLUE: 
                g.setColor(myBlue);
                dim1 = 1;
                break;
            case GREEN: 
                g.setColor(myGreen);
                dim1 = 2;
                break;
        }

        switch (y) {
            case SQUARE:
                g.fillRect(dx - 20, dy - 20, 40, 40);
                dim2 = 0;
                break;
            case TRIANGLE:
                fillTriangle(g, dx - 20, dy - 20, 40, 40);
                dim2 = 1;
                offset = 6;
                break;
            case CIRCLE:
                g.fillOval(dx - 20, dy - 20, 40, 40);
                dim2 = 2;
                break;
        }

        if (writeValue) {
            String[][] blockValues = {{"75", "65", "60"},{"25", "15", "10"},{"15", "5", "0"}};

            g.setColor(new Color(230, 230, 230));
            g.setFont(new Font("Arial", Font.PLAIN, 18));
            if (blockValues[dim2][dim1].length() > 1)
                g.drawString(blockValues[dim2][dim1], dx - 10, dy+7+offset);
            else
                g.drawString(blockValues[dim2][dim1], dx - 5, dy+7+offset);
        }
    }

    public void drawSmallBlock(Graphics g, int x, int y, int dx, int dy) {
        g.setColor(new Color(240, 240, 240));
        g.fillRect(dx-13, dy-13, 26, 26);

        int dim1 = 0, dim2 = 0;
        int offset = 0;

        switch (x) {
            case RED: 
                g.setColor(myRed);
                dim1 = 0;
                break;
            case BLUE: 
                g.setColor(myBlue);
                dim1 = 1;
                break;
            case GREEN: 
                g.setColor(myGreen);
                dim1 = 2;
                break;
        }

        switch (y) {
            case SQUARE:
                g.fillRect(dx - 11, dy - 11, 22, 22);
                dim2 = 0;
                break;
            case TRIANGLE:
                fillTriangle(g, dx - 11, dy - 11, 22, 22);
                dim2 = 1;
                offset = 6;
                break;
            case CIRCLE:
                g.fillOval(dx - 11, dy - 11, 22, 22);
                dim2 = 2;
                break;
        }
    }

    public void draw0sBlocks(Graphics g) {
        if (currentTurn == 0) {
            g.setColor(new Color(0, 200, 0));
            g.fillRect(14, 10, 102, 20);
        }

        g.setColor(new Color(0, 0, 0));
        g.setFont(new Font("Arial", Font.PLAIN, 18));

        if (plyrNum == 0)
            g.drawString("Your Blocks", 17, 26);
        else
            g.drawString("Their Blocks", 15, 26);
        g.fillRect(10, 34, 110, 2);

        for (int i = 0; i < num0sBlocks; i++) {
            drawTheBlock(g, zerosBlocks[i][0], zerosBlocks[i][1], 65, 11 + (i+1) * 54, true);
        }
    }

    public void draw1sBlocks(Graphics g) {
        if (currentTurn == 1) {
            g.setColor(new Color(0, 200, 0));
            g.fillRect(screenWidth - 116, 10, 102, 20);
        }

        g.setColor(new Color(0, 0, 0));
        g.setFont(new Font("Arial", Font.PLAIN, 18));
        if (plyrNum == 1)
            g.drawString("Your Blocks", screenWidth - 113, 26);
        else
            g.drawString("Their Blocks", screenWidth - 115, 26);
        g.fillRect(screenWidth - 120, 34, 110, 2);

        // drawFace(g, hFace, screenWidth - 65, 30);

        for (int i = 0; i < num1sBlocks; i++) {
            drawTheBlock(g, onesBlocks[i][0], onesBlocks[i][1], screenWidth - 65, 11 + (i+1) * 54, true);
        }
    }

    public int getColor(String blck) {
        switch (blck.charAt(0)) {
            case 'r': return RED;
            case 'b': return BLUE;
            case 'g': return GREEN;
        }

        return -1;
    }

    public int getShape(String blck) {
        switch (blck.charAt(1)) {
            case 's': return SQUARE;
            case 't': return TRIANGLE;
            case 'c': return CIRCLE;
        }

        return -1;
    }

    public String getActionLabel(String a, int plyr) {
        if (plyr == 0) {
            if (a.equals("0"))
                return "A";
            else
                return "B";
        }
        else {
            if (a.equals("0"))
                return "X";
            else
                return "Y";
        }
    }

    public void drawHistory(Graphics g) {
        int col1x = 10, col2x = 105, col3x = 253, col4x = 411;

        g.setColor(new Color(230, 230, 230));

        g.setFont(new Font("Arial", Font.PLAIN, 16));
        g.drawString("Rnd", col1x, screenHeight + 15);
        if (plyrNum == 0) {
            g.drawString("Your actions", col2x, screenHeight + 15);
            g.drawString("Their actions", col3x, screenHeight + 15);
        }
        else {
            g.drawString("Their actions", col2x, screenHeight + 15);
            g.drawString("Your actions", col3x, screenHeight + 15);
        }
        g.drawString("Your Score", col4x, screenHeight + 15);

        g.fillRect(5, screenHeight + 20, screenWidth-10, 2);

        int incy = 32;
        int baseY = screenHeight + 20 + incy;
        int total = 0;
        for (int i = 0; i < numPastRounds; i++) {
            // the round
            if ((i+1) < 10)
                g.drawString("" + (i+1), col1x+11, baseY + (i*incy));
            else
                g.drawString("" + (i+1), col1x+6, baseY + (i*incy));

            // player actions
            if (elPartido.equals("blockDilemma")) {
                for (int j = 0; j < 3; j++) {
                    drawSmallBlock(g, getColor(histActions[i][j][0]), getShape(histActions[i][j][0]), col2x + 14 + 30*j, baseY + (i*incy) - 6);
                    drawSmallBlock(g, getColor(histActions[i][j][1]), getShape(histActions[i][j][1]), col3x + 16 + 30*j, baseY + (i*incy) - 6);
                }
            }
            else {
                // dealing with a matrix game
                g.setColor(new Color(0, 115, 255));
                g.drawString(getActionLabel(histActions[i][0][0], 0), col2x + 37, baseY+(i*incy));
                g.setColor(new Color(255, 115, 0));
                g.drawString(getActionLabel(histActions[i][0][1], 1), col3x + 37, baseY+(i*incy));
            }
            g.setColor(new Color(230, 230, 230));

            // the scores
            if ((histScores[i][plyrNum] >= 100) || (histScores[i][plyrNum] <= -10))
                g.drawString("" + histScores[i][plyrNum], col4x+26, baseY + (i*incy));
            else if ((histScores[i][plyrNum] < 10) && (histScores[i][plyrNum] >= 0))
                g.drawString("" + histScores[i][plyrNum], col4x+36, baseY + (i*incy));
            else
                g.drawString("" + histScores[i][plyrNum], col4x+31, baseY + (i*incy));

            total += histScores[i][plyrNum];
        }

        if (numPastRounds > 0) {
            g.fillRect(5, baseY + (numPastRounds * incy) - incy / 2, screenWidth-10, 2);
            g.drawString("Total", col3x+50, baseY + ((numPastRounds+1) * incy) - incy / 2);
            if (total >= 1000)
                g.drawString("" + total, col4x+21, baseY + ((numPastRounds+1) * incy) - incy / 2);
            else if (total >= 100)
                g.drawString("" + total, col4x+26, baseY + ((numPastRounds+1) * incy) - incy / 2);
            else
                g.drawString("" + total, col4x+31, baseY + ((numPastRounds+1) * incy) - incy / 2);

            int theAve = theAve = total / numPastRounds;
            g.drawString("Average", col3x+50, baseY + ((numPastRounds+2) * incy) - incy / 2);
            if (theAve >= 100)
                g.drawString("" + theAve, col4x+26, baseY + ((numPastRounds+2) * incy) - incy / 2);
            else
                g.drawString("" + theAve, col4x+31, baseY + ((numPastRounds+2) * incy) - incy / 2);
        }
    }

    public void paint(Graphics g) {
        g.setColor(new Color(0, 0, 0));
        g.fillRect(0, windowHeight, screenWidth, windowHeight);

        if (elPartido.equals("blockDilemma")) {
            g.setColor(new Color(210, 210, 230));
            g.fillRect(5, 5, 120, screenHeight-40);
            g.fillRect(130, 5, screenWidth-260, screenHeight-40);
            g.fillRect(screenWidth - 255 + 130, 5, 120, screenHeight-40);


            // draw all of the unclaimed shapes
            int leftSide = 140;
            int rightSide = screenWidth - 140;
            int incx = (rightSide - leftSide) / 3;
            int topSide = 10;
            int bottomSide = screenHeight - 40;
            int incy = (bottomSide - topSide) / 3;
            int x, y;
            for (x = 0; x < 3; x++) {
                for (y = 0; y < 3; y++) {
                    if (theTable[x][y]) {
                        drawTheBlock(g, x, y, leftSide + (incx * x) + (incx / 2), topSide + (incy * y) + (incy / 2), true);
                    }
                }
            }

            // draw player 1's blocks
            draw0sBlocks(g);

            // draw player 2's blocks
            draw1sBlocks(g);
        }
        else {
            int x1 = 130, x2 = (screenWidth + 85)/2, x3 = screenWidth - 45;
            int y1 = 60, y2 = (screenHeight + 15) / 2, y3 = screenHeight-45;

            // dealing with a matrix game
            g.setColor(new Color(210, 210, 230));
            g.fillRect(5, 5, screenWidth-10, screenHeight-40);

            g.setColor(new Color(0, 0, 0));
            g.fillRect(x1, y1, screenWidth-175, 2);
            g.fillRect(x1, y2, screenWidth-175, 2);
            g.fillRect(x1, y3, screenWidth-175, 2);

            g.fillRect(x1, y1, 2, screenHeight-103);
            g.fillRect(x2, y1, 2, screenHeight-103);
            g.fillRect(x3, y1, 2, screenHeight-103);

            if (plyrNum == 0) {
                if ((action0Commit == 0)) {
                    g.setColor(new Color(150, 150, 170));
                    g.fillRect(44, y1+11, 80, 46);
                    g.setColor(new Color(190, 190, 210));
                    g.fillRect(44, y2+11, 80, 46);
                }
                else if ((action0Commit == 1)) {
                    g.setColor(new Color(190, 190, 210));
                    g.fillRect(44, y1+11, 80, 46);
                    g.setColor(new Color(150, 150, 170));
                    g.fillRect(44, y2+11, 80, 46);
                }
                else {
                    g.setColor(new Color(190, 190, 210));
                    g.fillRect(44, y1+11, 80, 46);
                    g.setColor(new Color(190, 190, 210));
                    g.fillRect(44, y2+11, 80, 46);
                }

                g.setColor(new Color(70, 70, 70));
                g.drawRect(44, y1+11, 80, 46);
                g.drawRect(44, y2+11, 80, 46);
            }
            else {
                if ((action1Commit == 0)) {
                    g.setColor(new Color(150, 150, 170));
                    g.fillRect(x1+45, 11, 80, 44);
                    g.setColor(new Color(190, 190, 210));
                    g.fillRect(x2+45, 11, 80, 44);
                }
                else if ((action1Commit == 1)) {
                    g.setColor(new Color(190, 190, 210));
                    g.fillRect(x1+45, 11, 80, 44);
                    g.setColor(new Color(150, 150, 170));
                    g.fillRect(x2+45, 11, 80, 44);
                }
                else {
                    g.setColor(new Color(190, 190, 210));
                    g.fillRect(x1+45, 11, 80, 44);
                    g.setColor(new Color(190, 190, 210));
                    g.fillRect(x2+45, 11, 80, 44);
                }

                g.setColor(new Color(70, 70, 70));
                g.drawRect(x1+45, 11, 80, 44);
                g.drawRect(x2+45, 11, 80, 44);
            }

            int xadd = 15;
            int yadd = 48;
            g.setFont(new Font("Arial", Font.PLAIN, 34));
            g.setColor(new Color(0, 115, 255));
            g.drawString(""+M[0][0][0], x1+xadd, y1+yadd);
            g.drawString(""+M[0][1][0], x2+xadd, y1+yadd);
            g.drawString(""+M[1][0][0], x1+xadd, y2+yadd);
            g.drawString(""+M[1][1][0], x2+xadd, y2+yadd);
            g.drawString("A", 74, y1+yadd);
            g.drawString("B", 74, y2+yadd);

            int xmore = 75;
            g.setColor(new Color(255, 115, 0));
            g.drawString(""+M[0][0][1], x1+xadd+xmore, y1+yadd);
            g.drawString(""+M[0][1][1], x2+xadd+xmore, y1+yadd);
            g.drawString(""+M[1][0][1], x1+xadd+xmore, y2+yadd);
            g.drawString(""+M[1][1][1], x2+xadd+xmore, y2+yadd);
            g.drawString("X", x1+74, y1-14);
            g.drawString("Y", x2+74, y1-14);

            if ((action0Commit != -1) && (action1Commit != -1)) {
                g.setColor(new Color(0, 150, 0));
                g.drawRect(162 * action1Commit + x1+5, 67 * action0Commit + y1+5, 155, 60);
                g.drawRect(162 * action1Commit + x1+5+1, 67 * action0Commit + y1+5+1, 153, 58);
            }
        }

        drawHistory(g);

        if (gameOver) {
            g.setColor(new Color(0, 150, 0));
            g.setFont(new Font("Arial", Font.PLAIN, 30));

            g.drawString("Game Over", 171, (screenHeight / 2 - 10));
        }
    }
}

class humanPlyr extends JFrame implements MouseListener {
    myCanvas canvas;
    Color bkgroundColor = new Color(0, 0, 0);

    humanPlyr(int _screenWidth, int _screenHeight, int _plyrNum) {
        System.out.println("I am player: " + _plyrNum);
        setSize(_screenWidth, _screenHeight);
        getContentPane().setBackground(bkgroundColor);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(600, 200, _screenWidth, _screenHeight);
        canvas = new myCanvas(_screenWidth, _screenHeight, _plyrNum);
        getContentPane().add(canvas);
        setVisible(true);
        setTitle("Play the Block Dilemma");

        addMouseListener(this);
    }

    public void mousePressed(MouseEvent e) {
        // System.out.println("Mouse pressed; # of clicks: " + e.getClickCount());
        canvas.registerClick(e.getX(), e.getY() - 30);
    }

    public void mouseReleased(MouseEvent e) {
        // System.out.println("Mouse released; # of clicks: " + e.getClickCount());
    }

    public void mouseEntered(MouseEvent e) {
        // System.out.println("Mouse entered");
    }

    public void mouseExited(MouseEvent e) {
        // System.out.println("Mouse exited");
    }

    public void mouseClicked(MouseEvent e) {
        // System.out.println("Mouse clicked: " + e.getX() + ", " + e.getY());
        // canvas.registerClick(e.getX(), e.getY() - 30);
    }

    public static void main(String args[]) {
        if (args.length < 1) {
            System.out.println("Must specify the player number (0 or 1)");
        }
        else {
            new humanPlyr(500, 1020, Integer.parseInt(args[0]));
        }
    }
}