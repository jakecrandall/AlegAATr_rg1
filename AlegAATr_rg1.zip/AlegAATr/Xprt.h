#ifndef XPRT_H
#define XPRT_H

#include "defs.h"
#include "Player.h"
#include "MarkovGame.h"
#include "abbert.h"
#include "State.h"

class Xprt : public Player {
public:
	Xprt();
	Xprt(int _me, MarkovGame *_mg, char tipito[1024], bool allowSwitching = true);
	~Xprt();
	
	int Move(State *s);
    int moveUpdate(State *s, int actions[2]);
    int roundUpdate(bool wasUsed);

    void restoreFactorySettings();
	
	int me;
    int expertID;
    abbert *ab;
    
    State *lastState;
    bool lastValidActs[2][NUMACTIONS*2];
    
    double rPayout[2], previousPayoffs[2];
    
    int corA[2], corALow[2];

    // checkers stuff
    void doCheckerUpdates(bool wasUsed);
    void getHighLowCheckerPayouts();
    void getEgalVals();
    int getTheirLow();
    double doExpPayout();

    double chHighPayout, chLowPayout, chMyPayout;
    double chPayoffHist[MAX_ROUNDS][2], chEgal[2], chBulliedHim[2];
    int chRounds;
    // bool chConformedInRound;
    double chItShouldGet, chYoShouldGet;

    // int chHasConformedCount, chHasNotConformedCount, chConformedInRowCount;
    int chHasConformedCount_used, chHasNotConformedCount_used, chConformedInRowCount_used;

    int chTheirLow;
    bool chConformedCurrent[2], chConformed2TheirLow[2], chCouldProfitbyDeviatingFromCurrent, chPunishedLast;
    double chMyAve;
    int chUseCount;

    int myLastMoveRec;
    bool iWasHeard;
};


#endif