#include "Switcher.h"

Switcher::Switcher() {
    cout << "Incomplete Switcher constructor" << endl;
    exit(1);
}

Switcher::Switcher(int _plyrNum, MarkovGame *_mg, string _gen1, string _gen2, int _switchTime) {
    plyrNum = _plyrNum;
    mg = _mg;
    switchTime = _switchTime;
    computeMGThings();

    vector<string> genConfig;
    genConfig.push_back(_gen1);
    genConfig.push_back(_gen2);
    createGenerators(genConfig);

    t = 0;
    startGen = 0;
    nextGen = 1;
    currentGenerator = 0;
}

Switcher::~Switcher() {
    for (int i = 0; i < generators.size(); i++) {
        delete generators[i];
    }
}

int Switcher::makeMove(State *s) {

    vector<int> theMoves;
    for (int i = 0; i < generators.size(); i++) {
        theMoves.push_back(generators[i]->Move(s));
    }

    return theMoves[currentGenerator];
}

void Switcher::updateAfterMove(State *s, int actions[2]) {
    for (int i = 0; i < generators.size(); i++) {
        generators[i]->moveUpdate(s, actions);
    }
}

void Switcher::updateRound() {
    for (int i = 0; i < generators.size(); i++) {
        if (i == currentGenerator)
            generators[i]->roundUpdate(true);
        else
            generators[i]->roundUpdate(false);
    }

    t++;

    if (t == switchTime) {
        currentGenerator = nextGen;

        if ((currentGenerator != startGen) && strncmp(generators[currentGenerator]->nickname, "cfr", 3)) {
            ((Xprt *)generators[currentGenerator])->ab->xprts[0]->guilt = 0.0;
            ((Xprt *)generators[currentGenerator])->ab->xprts[0]->betrayed = false;
        }
    }
}

void Switcher::createGenerators(vector<string> genConfig) {
    char tipito[1024];

    for (int i = 0; i < genConfig.size(); i++) {
        cout << "Generator: " << genConfig[i] << endl;
        if (genConfig[i] == "cfr") {
            generators.push_back(new CFR(plyrNum, mg, 40, false));
        }
        else if (genConfig[i] == "maxmin") {
            strcpy(tipito, "maxmin");
            generators.push_back(new Xprt(plyrNum, mg, tipito));
        }
        else if (genConfig[i] == "coop") {
            strcpy(tipito, "coop");
            generators.push_back(new Xprt(plyrNum, mg, tipito));
        }
        else if (genConfig[i] == "coopp") {
            strcpy(tipito, "coopp");
            generators.push_back(new Xprt(plyrNum, mg, tipito));
        }
        else if (genConfig[i] == "bullyp") {
            strcpy(tipito, "bullyp");
            generators.push_back(new Xprt(plyrNum, mg, tipito));
        }
        else if (genConfig[i] == "bullied") {
            strcpy(tipito, "bullied");
            generators.push_back(new Xprt(plyrNum, mg, tipito));
        }
        else {
            cout << "generator " << genConfig[i] << " not found" << endl;
        }
    }
}
