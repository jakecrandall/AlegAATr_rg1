#ifndef HUMAN_H
#define HUMAN_H

#include "defs.h"
#include "AbstractAlegAATr.h"
#include "MarkovGame.h"
#include "State.h"
#include "CFR.h"
#include "Xprt.h"

using namespace std;

class Human : public AbstractAlegAATr {
public:
    Human();
    Human(int _plyrNum, string _partido);
    ~Human();

    int makeMove(State *s);
    void updateAfterMove(State *s, int actions[2]);
    void updateRound();

private:
    string partido;
};

#endif