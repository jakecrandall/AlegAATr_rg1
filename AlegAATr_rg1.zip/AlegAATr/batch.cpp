#include <iostream>
#include <string>
#include <fstream>

using namespace std;

string players[4] = {"eee", "bbl", "spp", "alegaatr"};


// batch [game] [numSamps];
int main(int argc, char *argv[]) {
    if (argc < 3) {
        cout << "Not enough parameters" << endl;
        exit(1);
    }

    string partido = argv[1];
    int numSamps = atoi(argv[2]);

    cout << "Playing " << partido << endl;

    string fnombre = "../Results/" + partido + ".csv";
    ofstream output(fnombre);
    output << "Player1,Player2,Value1,Value2" << endl;

    char cmd[1024];
    double v[2];
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            for (int k = 0; k < numSamps; k++) {
                cout << "    " << players[i] << " vs " << players[j] << endl;
                sprintf(cmd, "./play game %s 20 %s %s", argv[1], players[i].c_str(), players[j].c_str());
                system(cmd);

                ifstream input("../Train/outcome.txt");
                input >> v[0];
                input >> v[1];

                output << players[i] << "," << players[j] << "," << v[0] << "," << v[1] << endl;

                input.close();
            }
        }
    }

    output.close();

    return 0;
}