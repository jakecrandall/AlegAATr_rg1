#ifndef ABSTRACTALEGAATR_H
#define ABSTRACTALEGAATR_H

#include "defs.h"
#include "MarkovGame.h"
#include "State.h"
#include "CFR.h"
#include "Xprt.h"

using namespace std;

class AbstractAlegAATr {
public:
    AbstractAlegAATr() {}
    virtual ~AbstractAlegAATr() {}

    virtual int makeMove(State *s) = 0;
    virtual void updateAfterMove(State *s, int actions[2]) = 0;
    virtual void updateRound() = 0;

    bool withProb(double prob) {
        if (prob == 1.0)
            return true;

        double num = (double)rand() / RAND_MAX;

        if (num < prob)
            return true;

        return false;
    }

    void computeMGThings() {
        mg->solveZero(1-plyrNum);
        mg->solveZero(plyrNum);
        
        // reset qvals;
        int s, i, j;
        for (s = 0; s < mg->numStates; s++) {
            for (i = 0; i < mg->states[s]->numActions[0]; i++) {
                for (j = 0; j < mg->states[s]->numActions[1]; j++) {
                    mg->states[s]->qsets[0]->Qs[i][j] = 0.0;
                }
            }
            mg->states[s]->qsets[0]->V = 0.0;
        }

        mg->solveAttack(plyrNum);
        mg->solveAttack(1-plyrNum);
        
        double w[2];
        for (w[0] = mg->wvals[0]; w[0] < mg->wvals[1] + 0.000001; w[0] += mg->wvals[2]) {
            w[1] = 1.0 - w[0];
            mg->vIteration(w[0], w[1]);
        }
    }

    void createGenerators(vector<string> genConfig) {
        char tipito[1024];

        for (int i = 0; i < genConfig.size(); i++) {
            cout << "Generator: " << genConfig[i] << endl;
            if (genConfig[i] == "cfr") {
                generators.push_back(new CFR(plyrNum, mg, 40, false));
            }
            else if (genConfig[i] == "maxmin") {
                strcpy(tipito, "maxmin");
                generators.push_back(new Xprt(plyrNum, mg, tipito));
            }
            else if (genConfig[i] == "coop") {
                strcpy(tipito, "coop");
                generators.push_back(new Xprt(plyrNum, mg, tipito));
            }
            else if (genConfig[i] == "coopp") {
                strcpy(tipito, "coopp");
                generators.push_back(new Xprt(plyrNum, mg, tipito));
            }
            else if (genConfig[i] == "bullyp") {
                strcpy(tipito, "bullyp");
                generators.push_back(new Xprt(plyrNum, mg, tipito));
            }
            else if (genConfig[i] == "bullied") {
                strcpy(tipito, "bullied");
                generators.push_back(new Xprt(plyrNum, mg, tipito));
            }
            else {
                cout << "generator " << genConfig[i] << " not found" << endl;
            }
        }
    }

    vector<string> readGeneratorConfig() {
        vector<string> genConfig;

        stringstream ss;
        ss << "configGens";
        ss << plyrNum;
        ss << ".txt";
        ifstream input(ss.str());

        string line;
        while (!input.eof()) {
            getline(input, line);
            if (line.length() > 1)
                genConfig.push_back(line);
            else
                break;
        }

        input.close();

        return genConfig;
    }



    MarkovGame *mg;
    int plyrNum;

    vector<Player *> generators;
    int currentGenerator;
};

#endif