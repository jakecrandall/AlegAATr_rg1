#ifndef SWITCHER_H
#define SWITCHER_H

#include "defs.h"
#include "AbstractAlegAATr.h"
#include "MarkovGame.h"
#include "State.h"
#include "CFR.h"
#include "Xprt.h"

using namespace std;

class Switcher : public AbstractAlegAATr {
public:
    Switcher();
    Switcher(int _plyrNum, MarkovGame *_mg, string _gen1, string _gen2, int _switchTime);
    ~Switcher();

    int makeMove(State *s);
    void updateAfterMove(State *s, int actions[2]);
    void updateRound();

    // void configureTrainingRun(string _startGen, string _nextGen, int _changeFreq, AbstractAlegAATr *_trainer);
    // void configureMas(ofstream &logstream, int _id);
    void createGenerators(vector<string> genConfig);
    // vector<string> readGeneratorConfig();
    // void logStatus(ofstream &logstream, int _id);
    // void initializeCheckers();
    // bool assumptionsTrue(string myGen, string otherGen);

private:
    int startGen, nextGen, t, switchTime;
    // double payoffsSoFar, theirPayoffsSoFar;
    // string wasUsing, willUse;
    State *lastState;
};

#endif