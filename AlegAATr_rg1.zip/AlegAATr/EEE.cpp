#include "EEE.h"

EEE::EEE() {
    cout << "In incomplete EEE constructor" << endl;
    exit(1);
}

EEE::EEE(int _plyrNum, MarkovGame *_mg) {
    mg = _mg;
    plyrNum = _plyrNum;
    computeMGThings();

    vector<string> genConfig = readGeneratorConfig();
    createGenerators(genConfig);

    for (int i = 0; i < generators.size(); i++) {
        vals.push_back(0.0);
        counts.push_back(0);
    }

    t = 0;
    cycleCount = 0;
    rndsInCycle = 2;
    roundPayout = 0.0;

    currentGenerator = rand() % generators.size();
    // cout << "   randomly selected " << generators[currentGenerator]->nickname << endl;
}

EEE::~EEE() {
    for (int i = 0; i < generators.size(); i++) {
        delete generators[i];
    }
}

int EEE::makeMove(State *s) {
    lastState = s;

    vector<int> theMoves;
    for (int i = 0; i < generators.size(); i++) {
        theMoves.push_back(generators[i]->Move(s));
    }

    return theMoves[currentGenerator];
}

void EEE::updateAfterMove(State *s, int actions[2]) {
    for (int i = 0; i < generators.size(); i++) {
        generators[i]->moveUpdate(s, actions);
    }
    int jact = lastState->jointCode(actions);

    roundPayout += lastState->rewards[jact][0][plyrNum];
}

void EEE::updateRound() {
    for (int i = 0; i < generators.size(); i++) {
        if (i == currentGenerator)
            generators[i]->roundUpdate(true);
        else
            generators[i]->roundUpdate(false);
    }
    t++;
    cycleCount ++;

    counts[currentGenerator] ++;
    vals[currentGenerator] += roundPayout;

    roundPayout = 0.0;

    if (cycleCount == rndsInCycle) {
        int prevGenerator = currentGenerator;
        double num = rand() / (double)RAND_MAX;
        double prob = 1.0 / (1.0 + (t/3.0));
        if (num < prob) {
            currentGenerator = rand() % generators.size();
            // cout << "   randomly selected " << generators[currentGenerator]->nickname << endl;
        }
        else {
            currentGenerator = selectGeneratorGreedily();
            // cout << "   greedily selected " << generators[currentGenerator]->nickname << endl;
        }

        if ((prevGenerator != currentGenerator) && strncmp(generators[currentGenerator]->nickname, "cfr", 3)) {
            ((Xprt *)generators[currentGenerator])->ab->xprts[0]->guilt = 0.0;
            ((Xprt *)generators[currentGenerator])->ab->xprts[0]->betrayed = false;
        }
        cycleCount = 0;
    }
}

int EEE::selectGeneratorGreedily() {
    vector<double> utils;

    cout << fixed;
    cout << setprecision(1);

    // cout << "utils: ";
    for (int i = 0; i < generators.size(); i++) {
        if (counts[i] > 0)
            utils.push_back(vals[i] / counts[i]);
        else
            utils.push_back(0.0);
        // cout << utils[i] << " (" << vals[i] << "; " << counts[i] << ")    ";
    }
    // cout << endl;

    double mx = utils[0];
    int mxInd = 0;
    int numEquals = 0;
    for (int i = 1; i < utils.size(); i++) {
        if (utils[i] > mx) {
            mx = utils[i];
            mxInd = i;
            numEquals = 1;
        }
        else if (utils[i] == mx)
            numEquals ++;
    }

    if (numEquals > 1) {
        // cout << "*************breaking tie" << endl;
        int pick = rand() % numEquals;
        int cnt = 0;
        for (int i = 0; i < utils.size(); i++) {
            if (utils[i] == mx) {
                if (cnt == pick)
                    return i;
                cnt ++;
            }
        }
    }

    return mxInd;
}

