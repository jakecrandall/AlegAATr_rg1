#include "Human.h"

Human::Human() {
    cout << "Incomplete Human constructor" << endl;
    exit(1);
}

Human::Human(int _plyrNum, string _partido) {
    plyrNum = _plyrNum;
    partido = _partido;
}

Human::~Human() {}

int Human::makeMove(State *s) {
    if (s->numActions[plyrNum] == 1)
        return 0;

    bool mesa[9];
    if (partido == "blockDilemma") {
        // determine which blocks are already taken
        for (int i = 0; i < 9; i++) {
            mesa[i] = true;
        }
        for (int i = 0; i < 6; i++) {
            if (s->featureVector[i] >= 0.0)
                mesa[(int)s->featureVector[i]] = false;
        }
    }

    // tell the GUI program it is waiting for an action
    stringstream ss;
    ss << "../SimulatedWorld/action" << plyrNum << ".flow";
    string fnombre = ss.str();

    ofstream f(fnombre);
    f << "?" << endl;
    f.close();

    stringstream ss2;
    ss2 << "../SimulatedWorld/action" << plyrNum << ".txt";
    string fnombre2 = ss2.str();

    string theCmd = "mv " + fnombre + " " + fnombre2;
    const char *theCmd2 = theCmd.c_str();
    system(theCmd2);

    // read the action
    ifstream f2;
    int aprime = -1;
    while (true) {
        f2.open(fnombre2);    

        string actionStr;
        f2 >> actionStr;

        f2.close();

        if (actionStr != "?") {
            aprime = stoi(actionStr);
            break;
        }

        usleep(10000);
    }

    if (partido == "blockDilemma") {
        // convert the action
        int count = 0;
        for (int i = 0; i < 9; i++) {
            if (i == aprime)
                return count;
            else if (mesa[i])
                count++;
        }
    }

    return aprime;
}

void Human::updateAfterMove(State *s, int actions[2]) {}

void Human::updateRound() {}
