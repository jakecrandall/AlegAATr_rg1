#ifndef RUNGENERATOR_H
#define RUNGENERATOR_H

#include "defs.h"
#include "AbstractAlegAATr.h"
#include "MarkovGame.h"
#include "State.h"
#include "CFR.h"
#include "Xprt.h"
#include "DataSet.h"

using namespace std;

class runGenerator : public AbstractAlegAATr {
public:
    runGenerator();
    runGenerator(string _genStr, int _plyrNum, MarkovGame *_mg);
    ~runGenerator();

    int makeMove(State *s);
    void updateAfterMove(State *s, int actions[2]);
    void updateRound();

    void createGenerator(string _genStr);
};

#endif