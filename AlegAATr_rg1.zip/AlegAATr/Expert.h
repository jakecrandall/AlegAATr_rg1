#ifndef __Solver__Expert__
#define __Solver__Expert__

#include "defs.h"
#include "MarkovGame.h"
#include "State.h"

#define     FOLLOWER    0
#define     LEADER      1
#define     MINIMAX     2
#define     BResp       3
#define     LEADER2     6


class Expert {
public:
    Expert();
    Expert(int _tipo, int _strat1, int _strat2, int _cycleLen, double _lambda, bool _explorar, double _deltaMax, MarkovGame *_mg = NULL, int _me = -1);
    Expert(int _tipo, int _strat1, int _strat2, double _P1[2], double _P2[2], double _deltaMax, int _cycleLen, double _lambda, int _me, bool _canSwitch = true);
    ~Expert();
    
    int Move(State *s, double previousPayoffs[2], int _me);
    double simulate2End(State *s, int me, int aprime, int qset_me, int qset_notme_est);
    int generateAction(double *v, int numActs);
    
    void Update(double dollars[2], int _me, double _aspiration, bool _heldTrue, double aspiration);
    void updateMove(State *sprime, double rPayout[2], int me, int acts[2], double aspiration);
    
    void reset(double previousPayoffs[2], int _me);
    void getCurrentStep(double previousPayoffs[2], int _me, bool _heldTrue);
    void updateLastResultObtained(double dollars[2], int _me);
    bool highPayoffAchieved(double previous[2], double pattern[2], double epsilon);
    bool randomSwitch(int _timeElapsed);
    
    void printStrategy(double *v, int numActs);
    
    bool showedLeadership(int hacts[20], double payoffHistory[2][10], int _me);
    
    State *lastState;
    int followedCount[MAX_QSETS];

    int tipo, strat[2];
    double stratVals[2][2];
    double deltaMax;
    int cycleLen;
    
    double lambda;
    
    double vu, barR[2];
    int usage;
    
    int currentStep, lastResultObtained, lastResultObtainedTime;
    bool justConformed, gotExpectedPayout;
    double payoffSum[2];
    int t;
    
    double guilt, addedGuilt;
    bool culpable;
    
    bool explorar;
    
    // void currentStepMessage(int _me);
    //char currentMessage[1024];
    // int currentMessage;
    
    int description[10], descriptionLen;
    bool describeExpert;
    //char description[1024];
    
    //bool heldTrue;
    bool betrayed, favored;

    double reflectiveActionValues[10], reflectiveActionValuesOther[10];
    bool canSwitch;
};

#endif
