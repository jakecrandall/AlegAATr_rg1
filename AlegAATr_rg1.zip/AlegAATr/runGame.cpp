#include "defs.h"
#include "MarkovGame.h"
#include "State.h"
#include "AbstractAlegAATr.h"
#include "AlegAATr.h"
#include "TrainAlegAATr.h"
#include "TrainingAssociate.h"
#include "Switcher.h"
#include "runGenerator.h"
#include "Human.h"
#include "EEE.h"
#include "Spp.h"
#include "BBL.h"


using namespace std;


class aRound {
public:
    aRound() {}
    virtual ~aRound() {}
    virtual void playRound(MarkovGame *mg0, MarkovGame *mg1, AbstractAlegAATr *player0, AbstractAlegAATr *player1) = 0;
    virtual void logRound() = 0;

    int getPlayerAction(int plyr) {
        // Set the file read to get an action
        stringstream ss;
        ss << "../SimulatedWorld/action" << plyr << ".flow";
        string fnombre = ss.str();

        ofstream f(fnombre);
        f << "?" << endl;
        f.close();

        stringstream ss2;
        ss2 << "../SimulatedWorld/action" << plyr << ".txt";
        string fnombre2 = ss2.str();

        string theCmd = "mv " + fnombre + " " + fnombre2;
        const char *theCmd2 = theCmd.c_str();
        system(theCmd2);

        // read the action
        ifstream f2;
        while (true) {
            f2.open(fnombre2);    

            string actionStr;
            f2 >> actionStr;

            f2.close();

            if (actionStr != "?") {
                return stoi(actionStr);
            }

            usleep(10);
        }
    }

    double scores[2];
    bool hayHuman;
};

class rndBD : public aRound {
private:
    bool mesa[3][3];
    int plyrBlocks[2][3];

public:
    rndBD() {
        cout << "Not a valid constructor" << endl;
        exit(1);
    }

    rndBD(bool _hayHuman) {
        hayHuman = _hayHuman;

        scores[0] = scores[1] = 99999;
    }
    
    ~rndBD() {}

    void playRound(MarkovGame *mg0, MarkovGame *mg1, AbstractAlegAATr *player0, AbstractAlegAATr *player1) {
        // cout << "Play the next round" << endl;
        setUpTable();
        if (hayHuman)
            writeTable(mesa, plyrBlocks[0], plyrBlocks[1]);

        State *s0 = determineBDState(mg0, plyrBlocks[0], plyrBlocks[1]);
        State *s1 = determineBDState(mg1, plyrBlocks[0], plyrBlocks[1]);
        int a[2], aprime[2];
        for (int m = 0; m < 6; m++) {
            // cout << "numActions: " << s->numActions[0] << ", " << s->numActions[1] << endl;
            a[0] = player0->makeMove(s0);
            a[1] = player1->makeMove(s1);

            // cout << " mg actions: " << a[0] << ", " << a[1] << endl;

            int shp, clr;
            for (int i = 0; i < 2; i++) {
                if (s0->numActions[i] > 1) {
                    aprime[i] = translateBDAction(a[i], mesa);
                    shp = aprime[i] / 3;
                    clr = aprime[i] % 3;
                    mesa[clr][shp] = false;

                    int ind = 0;
                    while (plyrBlocks[i][ind] != -1)
                        ind ++;
                    plyrBlocks[i][ind] = aprime[i];
                }
                else {
                    aprime[i] = 0;
                }
            }

            if (hayHuman)
                writeTable(mesa, plyrBlocks[0], plyrBlocks[1]);

            s0 = determineBDState(mg0, plyrBlocks[0], plyrBlocks[1]);
            s1 = determineBDState(mg1, plyrBlocks[0], plyrBlocks[1]);
            player0->updateAfterMove(s0, a);
            player1->updateAfterMove(s1, a);
        }

        player0->updateRound();
        player1->updateRound();

        logRound();
    }

    void writeTable(bool tabl[3][3], int plyr0[3], int plyr1[3]) {
        ofstream ftab("../SimulatedWorld/Table.flow");

        ftab << "Table:" << endl;
        for (int s = 0; s < 3; s++) {
            for (int c = 0; c < 3; c++) {
                if (tabl[c][s])
                    ftab << blockString(c, s);
                else
                    ftab << "   ";
            }
            ftab << endl;
        }

        ftab << endl << "Zeros:" << endl;
        for (int i = 0; i < 3; i++) {
            if (plyr0[i] == -1)
                break;
            
            ftab << blockString(plyr0[i] % 3, plyr0[i] / 3);
        }

        ftab << endl << endl << "Ones:" << endl;
        for (int i = 0; i < 3; i++) {
            if (plyr1[i] == -1)
                break;
            
            ftab << blockString(plyr1[i] % 3, plyr1[i] / 3);
        }

        ftab << endl << endl << "$$" << endl;

        ftab.close();

        system("mv ../SimulatedWorld/Table.flow ../SimulatedWorld/Table.txt");

    }

    void logRound() {
        // score the round
        int values[9] = {75, 65, 60, 25, 15, 10, 15, 5, 0};
        scores[0] = scores[1] = 0.0;
        for (int i = 0; i < 3; i++) {
            scores[0] += values[plyrBlocks[0][i]];
            scores[1] += values[plyrBlocks[1][i]];
        }
        if (!isValidSet(plyrBlocks[0]))
            scores[0] = (-scores[0]) / 4.0;
        if (!isValidSet(plyrBlocks[1]))
            scores[1] = (-scores[1]) / 4.0;

        // cout << "Player 1's payoff: " << scores[0] << endl;
        // cout << "Player 2's payoff: " << scores[1] << endl;

        if (hayHuman) {
            // write the round results to a file (../SimulatedWorld/History.txt)
            ofstream fw("../SimulatedWorld/History.flow");
            ifstream fr("../SimulatedWorld/History.txt");
            
            if (fr.is_open()) {
                string line;
                while (!fr.eof()) {
                    getline(fr, line);
                    if (line.length() > 2)
                        fw << line << endl;
                }
                fr.close();
            }

            for (int i = 0; i < 3; i++) {
                fw << blockString(plyrBlocks[0][i] % 3, plyrBlocks[0][i] / 3);
            }
            fw << "| ";
            for (int i = 0; i < 3; i++) {
                fw << blockString(plyrBlocks[1][i] % 3, plyrBlocks[1][i] / 3);
            }
            fw << "-> " << scores[0] << " " << scores[1] << endl;

            fw.close();

            system("mv ../SimulatedWorld/History.flow ../SimulatedWorld/History.txt");
        }
    }

    void setUpTable() {
        if (hayHuman)
            system("cp ../SimulatedWorld/NewRound.txt ../SimulatedWorld/Table.txt");

        for (int sh = 0; sh < 3; sh++) {
            for (int cl = 0; cl < 3; cl++) {
                mesa[cl][sh] = true;
            }
        }

        for (int i = 0; i < 3; i++) {
            plyrBlocks[0][i] = plyrBlocks[1][i] = -1;
        }
    }

    bool isValidSet(int blocks[3]) {
        int cols[3], shps[3];

        for (int i = 0; i < 3; i++) {
            cols[i] = blocks[i] % 3;
            shps[i] = blocks[i] / 3;
        }

        if ((cols[0] == cols[1]) && (cols[1] == cols[2])) { // all the same color
            // cout << "All the same color" << endl;
            return true;
        }

        if ((shps[0] == shps[1]) && (shps[1] == shps[2])) { // all the same shape
            // cout << "All the same shape" << endl;
            return true;
        }

        if ((cols[0] != cols[1]) && (cols[1] != cols[2]) && (cols[0] != cols[2]) & (shps[0] != shps[1]) && (shps[1] != shps[2]) && (shps[0] != shps[2])) { // mixed set
            // cout << "mixed set" << endl;
            return true;
        }

        // cout << "Not a valid set" << endl;
        
        return false;
    }

    // void doAction(int plyr) {
    //     // readTable
    //     bool tabl[3][3];
    //     int plyr0[3], plyr1[3];
    //     readTable(tabl, plyr0, plyr1);
        
    //     // get action
    //     int a = getPlayerAction(plyr);
    //     while (!isValid(tabl, a)) {   // check to make sure the action is valid
    //         a = getPlayerAction(plyr);
    //     }
    //     // cout << "action: " << a << endl;

    //     // updateTable
    //     int c = a % 3;
    //     int s = a / 3;
    //     tabl[c][s] = false;
    //     int *plyrptr;
    //     if (plyr == 0)
    //         plyrptr = plyr0;
    //     else {
    //         plyrptr = plyr1;
    //     }
    //     for (int i = 0; i < 3; i++) {
    //         if (plyrptr[i] == -1) {
    //             plyrptr[i] = a;
    //             break;
    //         }
    //     }

    //     writeTableChange(tabl, plyr0, plyr1);
    // }

    // void readTable(bool tabl[3][3], int plyr0[3], int plyr1[3]) {
    //     ifstream ftab("../SimulatedWorld/Table.txt");

    //     string line;
    //     getline(ftab, line);
    //     for (int s = 0; s < 3; s++) {
    //         getline(ftab, line);
    //         for (int c = 0; c < 9; c+=3) {
    //             if (line[c] == ' ')
    //                 tabl[c/3][s] = false;
    //             else
    //                 tabl[c/3][s] = true;
    //         }
    //     }

    //     getline(ftab, line);
    //     getline(ftab, line);
    //     getline(ftab, line);
    //     decipherBlocks(line, plyr0);

    //     getline(ftab, line);
    //     getline(ftab, line);
    //     getline(ftab, line);
    //     decipherBlocks(line, plyr1);

    //     ftab.close();
    // }

    // void writeTableChange(bool tabl[3][3], int plyr0[3], int plyr1[3]) {
    //     ofstream ftab("../SimulatedWorld/Table.flow");

    //     ftab << "Table:" << endl;
    //     for (int s = 0; s < 3; s++) {
    //         for (int c = 0; c < 3; c++) {
    //             if (tabl[c][s])
    //                 ftab << blockString(c, s);
    //             else
    //                 ftab << "   ";
    //         }
    //         ftab << endl;
    //     }

    //     ftab << endl << "Zeros:" << endl;
    //     for (int i = 0; i < 3; i++) {
    //         if (plyr0[i] == -1)
    //             break;
            
    //         ftab << blockString(plyr0[i] % 3, plyr0[i] / 3);
    //     }

    //     ftab << endl << endl << "Ones:" << endl;
    //     for (int i = 0; i < 3; i++) {
    //         if (plyr1[i] == -1)
    //             break;
            
    //         ftab << blockString(plyr1[i] % 3, plyr1[i] / 3);
    //     }

    //     ftab << endl << endl << "$$" << endl;

    //     ftab.close();

    //     system("mv ../SimulatedWorld/Table.flow ../SimulatedWorld/Table.txt");

    // }

    string blockString(int c, int s) {
        if ((c == 0) && (s == 0))
            return "rs ";
        if ((c == 1) && (s == 0))
            return "bs ";
        if ((c == 2) && (s == 0))
            return "gs ";
        if ((c == 0) && (s == 1))
            return "rt ";
        if ((c == 1) && (s == 1))
            return "bt ";
        if ((c == 2) && (s == 1))
            return "gt ";
        if ((c == 0) && (s == 2))
            return "rc ";
        if ((c == 1) && (s == 2))
            return "bc ";
        if ((c == 2) && (s == 2))
            return "gc ";

        return "   ";        
    }

    // void decipherBlocks(string line, int plyr[3]) {
    //     for (int i = 0; i < 3; i++) {
    //         plyr[i] = -1;
    //     }

    //     int count = 0;
    //     for (int i = 0; i < line.length(); i += 3) {
    //         int c = -1, s = -1;
    //         switch (line[i]) { // color of the string
    //             case 'r': c = 0; break;
    //             case 'b': c = 1; break;
    //             case 'g': c = 2; break;
    //         }

    //         switch (line[i+1]) { // shape of the string
    //             case 's': s = 0; break;
    //             case 't': s = 1; break;
    //             case 'c': s = 2; break;
    //         }

    //         plyr[count] = s * 3 + c;
    //         count ++;
    //     }
    // }

    // bool isValid(bool tabl[3][3], int a) {
    //     int c = a % 3;
    //     int s = a / 3;

    //     if (tabl[c][s])
    //         return true;

    //     return false;
    // }

    State *determineBDState(MarkovGame *mg, int plyr0[3], int plyr1[3]) {
        int copy_plyr0[3], copy_plyr1[3];
        for (int i = 0; i < 3; i++) {
            copy_plyr0[i] = plyr0[i];
            copy_plyr1[i] = plyr1[i];
        }

        bubbleSort(copy_plyr0);
        bubbleSort(copy_plyr1);

        double featureVec[6];
        for (int i = 0; i < 3; i++) {
            featureVec[i] = copy_plyr0[i];
            featureVec[i+3] = copy_plyr1[i];
        }

        State *s = mg->stateDefined(featureVec);

        return s;
    }

    void bubbleSort(int plyr[3]) {
        if (plyr[1] >= 0) {
            if (plyr[0] > plyr[1]) {
                swap(plyr, 0, 1);
            }
            if (plyr[2] >= 0) {
                if (plyr[1] > plyr[2]) {
                    swap(plyr, 1, 2);
                    if (plyr[0] > plyr[1]) {
                        swap(plyr, 0, 1);
                    }
                }
            }
        }
    }

    void swap(int plyr[3], int i, int j) {
        int tmp = plyr[i];
        plyr[i] = plyr[j];
        plyr[j] = tmp;
    }

    int translateBDAction(int a, bool tabl[3][3]) {
        // cout << "translate " << a << endl;
        int count = 0, c, s;   
        for (int i = 0; i < 9; i++) {
            c = i % 3;
            s = i / 3;
            if (tabl[c][s]) {
                if (count == a)
                    return i;
                else
                    count ++;
            }
        }

        cout << "Shouldn't have gotten here" << endl;
        exit(1);

        return -1;
    }

};

class rndMG : public aRound {
public:
    rndMG() {
        cout << "Not a valid constructor" << endl;
        exit(1);
    }

    rndMG(int _M[2][2][2], bool _hayHuman) {
        hayHuman = _hayHuman;
        scores[0] = scores[1] = 99999;

        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < 2; j++) {
                M[i][j][0] = _M[i][j][0];
                M[i][j][1] = _M[i][j][1];
            }
        }
    }
    
    ~rndMG() {}

    void playRound(MarkovGame *mg0, MarkovGame *mg1, AbstractAlegAATr *player0, AbstractAlegAATr *player1) {
        if (hayHuman)
            system("cp ../SimulatedWorld/newMatrixRound.txt ../SimulatedWorld/actionCommit.txt");

        // doAction(0);
        int a[2];
        a0 = a[0] = player0->makeMove(mg0->states[0]);

        if (hayHuman) {
            ofstream output("../SimulatedWorld/actionCommit.flow");
            output << a0 << " -1" << endl;
            // cout << a0 << " -1" << endl;
            output.close();
            system("mv ../SimulatedWorld/actionCommit.flow ../SimulatedWorld/actionCommit.txt");
        }
        
        // doAction(1);
        a1 = a[1] = player1->makeMove(mg1->states[0]);

        if (hayHuman) {
            ofstream output2("../SimulatedWorld/actionCommit.flow");
            output2 << a0 << " " << a1 << endl;
            // cout << a0 << " " << a1 << endl;
            output2.close();
            system("mv ../SimulatedWorld/actionCommit.flow ../SimulatedWorld/actionCommit.txt");
        }

        player0->updateAfterMove(mg0->states[0], a);
        player1->updateAfterMove(mg1->states[0], a);

        // cout << "Actions: " << a[0] << ", " << a[1] << endl;

        player0->updateRound();
        player1->updateRound();

        logRound();

    }

    // void doAction(int plyr) {        
    //     // get action
    //     int a = getPlayerAction(plyr);
    //     while (!isValid(a)) {   // check to make sure the action is valid
    //         a = getPlayerAction(plyr);
    //     }

    //     if (plyr == 0)
    //         a0 = a;
    //     else
    //         a1 = a;
    // }

    // bool isValid(int a) {
    //     if ((a == 0) || (a == 1))
    //         return true;

    //     return false;
    // }

    void logRound() {
        // cout << "Log the last round" << endl;

        scores[0] = M[a0][a1][0];
        scores[1] = M[a0][a1][1];

        // cout << "Scores: " << scores[0] << ", " << scores[1] << endl;

        if (hayHuman) {
            // write the round results to a file (../SimulatedWorld/History.txt)
            ofstream fw("../SimulatedWorld/History.flow");
            ifstream fr("../SimulatedWorld/History.txt");
            
            if (fr.is_open()) {
                string line;
                while (!fr.eof()) {
                    getline(fr, line);
                    if (line.length() > 2)
                        fw << line << endl;
                }
                fr.close();
            }

            fw << a0 << " - - | " << a1 << " - - ";
            fw << "-> " << scores[0] << " " << scores[1] << endl;

            fw.close();

            system("mv ../SimulatedWorld/History.flow ../SimulatedWorld/History.txt");
        }
    }

    int M[2][2][2];
    int a0, a1;
};


void writeGameOverMessage(int rnd) {
    // write that the game is over
    ofstream output("../SimulatedWorld/gameover.flow");
    output << rnd << endl;
    output.close();

    system("mv ../SimulatedWorld/gameOver.flow ../SimulatedWorld/gameOver.txt");
}

void writeGame(string s) {
    // write that the game is over
    ofstream output("../SimulatedWorld/elPartido.flow");
    output << s << endl;
    output.close();

    system("mv ../SimulatedWorld/elPartido.flow ../SimulatedWorld/elPartido.txt");
}

void readPayoffMatrix(string elPartido, int M[2][2][2]) {
    string fnombre = "../SimulatedWorld/Games/" + elPartido + ".txt";
    ifstream input(fnombre);

    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            input >> M[i][j][0];
        }
    }

    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            input >> M[i][j][1];
        }
    }

    input.close();
    // for (int i = 0; i < 2; i++) {
    //     for (int j = 0; j < 2; j++) {
    //         cout << M[i][j][0] << ", " << M[i][j][1] << "   ";
    //     }
    //     cout << endl;
    // }
}

void logScores(double scores[2]) {
    ofstream output("../Train/temp.txt");
    output << scores[0] << "\n" << scores[1] << endl;
    output.close();

    system("mv ../Train/temp.txt ../Train/outcome.txt");
}


AbstractAlegAATr *createPlayer(MarkovGame *mg, string agnt, int plyrNum, string elPartido) {
    if (agnt == "alegaatr")
        return new AlegAATr(plyrNum, mg, elPartido, 20, SELF_MODE);
    else if (agnt == "alegaatr_friend")
        return new AlegAATr(plyrNum, mg, elPartido, 20, FRIEND_MODE);
    else if (agnt == "alegaatr_competitor")
        return new AlegAATr(plyrNum, mg, elPartido, 20, COMPETITOR_MODE);
    else if (agnt == "alegaatr_changer")
        return new AlegAATr(plyrNum, mg, elPartido, 20, CHANGER);
    else if (agnt == "train_alegaatr")
        return new TrainAlegAATr(plyrNum, mg, elPartido);
    else if (agnt == "training_associate")
        return new TrainingAssociate(plyrNum, mg);
    else if (agnt == "human")
        return new Human(plyrNum, elPartido);
    else if (agnt == "bullied")
        return new runGenerator("bullied", plyrNum, mg);
    else if (agnt == "coop")
        return new runGenerator("coop", plyrNum, mg);
    else if (agnt == "coopp")
        return new runGenerator("coopp", plyrNum, mg);
    else if (agnt == "cfr")
        return new runGenerator("cfr", plyrNum, mg);
    else if (agnt == "bullyp")
        return new runGenerator("bullyp", plyrNum, mg);
    else if (agnt == "maxmin")
        return new runGenerator("maxmin", plyrNum, mg);
    else if (agnt == "eee")
        return new EEE(plyrNum, mg);
    else if (agnt == "spp")
        return new Spp(plyrNum, mg);
    else if (agnt == "bbl")
        return new BBL(plyrNum, mg, elPartido, 20);
    else if (agnt.find("switcher") != string::npos) {
        string uno = agnt.substr(agnt.find("_")+1, agnt.length());
        string dos = uno.substr(uno.find("_")+1, uno.length());
        uno = uno.substr(0, uno.find("_"));
        return new Switcher(plyrNum, mg, uno, dos, 10);
    }
    else {
        cout << "agent " << agnt << " not found" << endl;
        exit(-1);
    }

    return NULL;
}

int getGenVsGenResults(AbstractAlegAATr *players[2], MarkovGame *mg[2], string partido, int plyrNum, int numRounds, double outcomes[10][10][2], int numSamps, int _id) {
    stringstream fnombre;
    fnombre << "Data_" << partido << "_" << plyrNum << ".txt";
    ofstream logstream;
    logstream.open(fnombre.str(), std::ios_base::app);
    logstream << fixed;
    string nme1, nme2;

    for (int i = 0; i < players[plyrNum]->generators.size(); i++) {
        for (int j = 0; j < players[plyrNum]->generators.size(); j++) {
            outcomes[i][j][0] = outcomes[i][j][1] = 0.0;

            for (int samps = 0; samps < numSamps; samps++) {
                int chRnd = numRounds+1;
                if (plyrNum == 0) {
                    ((TrainAlegAATr *)players[plyrNum])->configureTrainingRun(players[plyrNum]->generators[i]->nickname, players[plyrNum]->generators[i]->nickname, chRnd, players[1-plyrNum]);
                    ((TrainingAssociate *)players[1-plyrNum])->configureTrainingRun(players[plyrNum]->generators[j]->nickname, 0.0, STATIONARY, players[plyrNum]);
                }
                else {
                    ((TrainAlegAATr *)players[plyrNum])->configureTrainingRun(players[plyrNum]->generators[j]->nickname, players[plyrNum]->generators[i]->nickname, chRnd, players[1-plyrNum]);
                    ((TrainingAssociate *)players[1-plyrNum])->configureTrainingRun(players[plyrNum]->generators[i]->nickname, 0.0, STATIONARY, players[plyrNum]);
                }
                ((TrainAlegAATr *)players[plyrNum])->configureMas(logstream, _id);
                
                // play the game
                aRound **rounds = new aRound*[numRounds];
                // system("rm ../SimulatedWorld/History.txt");
                if (partido == "blockDilemma") {
                    for (int k = 0; k < numRounds; k++)
                        rounds[k] = new rndBD(false);
                }
                else {
                    int M[2][2][2];
                    readPayoffMatrix(partido, M);

                    for (int k = 0; k < numRounds; k++)
                        rounds[k] = new rndMG(M, false);
                }
                
                double aves[2] = {0.0, 0.0};
                // system("rm ../SimulatedWorld/History.txt");
                for (int k = 0; k < numRounds; k++) {
                    // cout << "\n\nRound: " << i << endl;
                    rounds[k]->playRound(mg[0], mg[1], players[0], players[1]);

                    ((TrainAlegAATr *)players[plyrNum])->logStatus(logstream, _id);

                    // cout << rounds[k]->scores[0] << ", " << rounds[k]->scores[1] << endl;

                    aves[0] += rounds[k]->scores[0];
                    aves[1] += rounds[k]->scores[1];
                }

                // cout << "outcome: " << (int)(aves[0]+0.5) << "  " << (int)(aves[1]+0.5) << endl;

                outcomes[i][j][0] += aves[0];
                outcomes[i][j][1] += aves[1];

                for (int k = 0; k < numRounds; k++) {
                    delete rounds[k];
                }
                delete[] rounds;

                _id++;
            }
        }
    }

    cout << "Gen vs Gen scores: " << endl << "\t";
    for (int i = 0; i < players[plyrNum]->generators.size(); i++)
        cout << players[plyrNum]->generators[i]->nickname << "\t\t";
    cout << endl;

    for (int p1 = 0; p1 < players[plyrNum]->generators.size(); p1++) {
        cout << players[plyrNum]->generators[p1]->nickname << "\t";
        for (int p2 = 0; p2 < players[plyrNum]->generators.size(); p2++) {
            outcomes[p1][p2][0] /= numSamps;
            outcomes[p1][p2][1] /= numSamps;
            cout << (int)(outcomes[p1][p2][0] + 0.5) << "  " << (int)(outcomes[p1][p2][1] + 0.5) << " |\t";
        }
        cout << endl;
    }

    logstream.close();

    return _id;
}

int getGenVsSwitcherResults(AbstractAlegAATr *players[2], MarkovGame *mg[2], string partido, int plyrNum, int numRounds, double changeRate, int tipo, int _id) {
    stringstream fnombre;
    fnombre << "Data_" << partido << "_" << plyrNum << ".txt";
    ofstream logstream;
    logstream.open(fnombre.str(), std::ios_base::app);
    logstream << fixed;

    for (int i = 0; i < players[plyrNum]->generators.size(); i++) {
        for (int j = 0; j < players[plyrNum]->generators.size(); j++) {
            for (int chRnd = 0; chRnd < numRounds; chRnd += 2) {
                // int chRnd = rand() % numRounds;
                int theStart = rand() % players[plyrNum]->generators.size();
                while (theStart == i)
                    theStart = rand() % players[plyrNum]->generators.size();

                // cout << "Start: " << players[plyrNum]->generators[theStart]->nickname << "; change to " << players[plyrNum]->generators[i]->nickname << " at " << chRnd << endl;

                if (plyrNum == 0) {
                    ((TrainAlegAATr *)players[plyrNum])->configureTrainingRun(players[plyrNum]->generators[theStart]->nickname, players[plyrNum]->generators[i]->nickname, chRnd, players[1-plyrNum]);
                    ((TrainingAssociate *)players[1-plyrNum])->configureTrainingRun(players[plyrNum]->generators[j]->nickname, changeRate, tipo, players[plyrNum]);
                }
                else {
                    ((TrainAlegAATr *)players[plyrNum])->configureTrainingRun(players[plyrNum]->generators[theStart]->nickname, players[plyrNum]->generators[j]->nickname, chRnd, players[1-plyrNum]);
                    ((TrainingAssociate *)players[1-plyrNum])->configureTrainingRun(players[plyrNum]->generators[i]->nickname, changeRate, tipo, players[plyrNum]);
                }
                ((TrainAlegAATr *)players[plyrNum])->configureMas(logstream, _id);
                // cout << endl;
                // if (plyrNum == 0) {
                //     ((TrainAlegAATr *)players[plyrNum])->configureTrainingRun(logstream, players[plyrNum]->generators[i]->nickname, numRounds+1, _id, players[1-plyrNum]);
                //     ((TrainingAssociate *)players[1-plyrNum])->configureTrainingRun(players[plyrNum]->generators[j]->nickname, changeRate, tipo, players[plyrNum]);
                // }
                // else {
                //     ((TrainAlegAATr *)players[plyrNum])->configureTrainingRun(logstream, players[plyrNum]->generators[j]->nickname, numRounds+1, _id, players[1-plyrNum]);
                //     ((TrainingAssociate *)players[1-plyrNum])->configureTrainingRun(players[plyrNum]->generators[i]->nickname, changeRate, tipo, players[plyrNum]);
                // }

                // play the game
                aRound **rounds = new aRound*[numRounds];
                if (partido == "blockDilemma") {
                    for (int k = 0; k < numRounds; k++)
                        rounds[k] = new rndBD(false);
                }
                else {
                    int M[2][2][2];
                    readPayoffMatrix(partido, M);

                    for (int k = 0; k < numRounds; k++)
                        rounds[k] = new rndMG(M, false);
                }
                
                for (int k = 0; k < numRounds; k++) {
                    rounds[k]->playRound(mg[0], mg[1], players[0], players[1]);
                    ((TrainAlegAATr *)players[plyrNum])->logStatus(logstream, _id);
                }

                for (int k = 0; k < numRounds; k++) {
                    delete rounds[k];
                }
                delete[] rounds;

                _id++;
            }
        }
    }

    logstream.close();

    return _id;
}

int getGenVsAlegAATrResults(AbstractAlegAATr *players[2], MarkovGame *mg[2], string partido, int plyrNum, int numRounds, int _id) {
    stringstream fnombre;
    fnombre << "Data_" << partido << "_" << plyrNum << ".txt";
    ofstream logstream;
    logstream.open(fnombre.str(), std::ios_base::app);
    logstream << fixed;

    for (int i = 0; i < players[plyrNum]->generators.size(); i++) {
        for (int chRnd = 0; chRnd < numRounds; chRnd += 2) {
            int theStart = rand() % players[plyrNum]->generators.size();

            ((TrainAlegAATr *)players[plyrNum])->configureTrainingRun(players[plyrNum]->generators[theStart]->nickname, players[plyrNum]->generators[i]->nickname, chRnd, players[1-plyrNum]);
            ((TrainAlegAATr *)players[plyrNum])->configureMas(logstream, _id);
            ((AlegAATr *)players[1-plyrNum])->configureTrainingRun();

            // play the game
            aRound **rounds = new aRound*[numRounds];
            if (partido == "blockDilemma") {
                for (int i = 0; i < numRounds; i++)
                    rounds[i] = new rndBD(false);
            }
            else {
                int M[2][2][2];
                readPayoffMatrix(partido, M);

                for (int k = 0; k < numRounds; k++)
                    rounds[k] = new rndMG(M, false);
            }
            
            for (int k = 0; k < numRounds; k++) {
                rounds[k]->playRound(mg[0], mg[1], players[0], players[1]);
                ((TrainAlegAATr *)players[plyrNum])->logStatus(logstream, _id);
            }

            for (int k = 0; k < numRounds; k++) {
                delete rounds[k];
            }
            delete[] rounds;

            _id++;
        }
    }

    logstream.close();

    return _id;
}

int determineNumDataSamples(string partido, int plyrNum) {
    stringstream fnombre;
    fnombre << "Data_" << partido << "_" << plyrNum << ".txt";
    ifstream input(fnombre.str());

    if (!input)
        return 0;
    
    string line;
    int id;
    while (!input.eof()) {
        getline(input, line);
        if (line.length() > 2) {
            int j = 0;
            while (line.at(j) != ',')
                j++;

            string sbstr = line.substr(0, j);
            // cout << sbstr << endl;
            id = stoi(sbstr);
        }
    }

    input.close();

    return id+1;
}

void recordMatrixOutcomes(AbstractAlegAATr *players[2], string partido, double outcomes[10][10][2], int index, int numRounds) {
    stringstream ff;
    ff << "../Train/payoffs_" << index << "_" << partido << "_" << numRounds << ".txt";
    string fnombre = ff.str();
    ofstream output(fnombre);

    for (int i = 0; i < players[0]->generators.size(); i++) {
        for (int j = 0; j < players[1]->generators.size(); j++) {
            output << outcomes[i][j][index] << endl;
        }
    }

    output.close();
}

void readMatrixOutcomes(AbstractAlegAATr *players[2], string partido, double outcomes[10][10][2], int index) {
    stringstream ff;
    ff << "../Train/payoffs_" << index << "_" << partido << ".txt";
    string fnombre = ff.str();
    ifstream input(fnombre);

    if (!input) {
        cout << "gengen payoffs not found" << endl;
        exit(1);
    }

    for (int i = 0; i < players[0]->generators.size(); i++) {
        for (int j = 0; j < players[1]->generators.size(); j++) {
            input >> outcomes[i][j][index];
        }
    }

    input.close();
}

// ********************************************************
//
// ./play train [game] [numRounds] [plyrNum]
// ./play game [game] [numRounds] [agent0] [agent1]
// 
// ********************************************************
int main(int argc, char *argv[]) {
    if (argc < 3) {
        cout << "Not enough parameters: " << argc << endl;
        return -1;
    }
    cout << fixed;
    long micros = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
    srand(micros);

    if (!strcmp(argv[1], "game")) {     // play a game
        if (argc != 6) {
            cout << "Wrong number of parameters to play a game: " << argc << endl;
            return -1;
        }

        string partido = argv[2];
        int numRounds = atoi(argv[3]);
        cout << "Play game " << partido << " for " << numRounds << " rounds" << endl;
        cout << "  Players: " << argv[4] << " and " << argv[5] << endl;
        bool hayHuman = false;
        if (!strcmp(argv[4], "human") || !strcmp(argv[5], "human")) {
            hayHuman = true;
            system("cp ../SimulatedWorld/actionBlank.txt ../SimulatedWorld/action0.txt");
            system("cp ../SimulatedWorld/actionBlank.txt ../SimulatedWorld/action1.txt");
            writeGame(partido);
        }

        MarkovGame *mg0 = new MarkovGame(partido.c_str());

        // cout << "a" << endl;
        string agnt = argv[4];
        AbstractAlegAATr *player0 = createPlayer(mg0, agnt, 0, partido);
        // cout << "b" << endl;

        MarkovGame *mg1 = new MarkovGame(partido.c_str());
        // cout << "c" << endl;
        agnt = argv[5];
        AbstractAlegAATr *player1 = createPlayer(mg1, agnt, 1, partido);
        // cout << "d" << endl;

        aRound **rounds = new aRound*[numRounds];
        if (partido == "blockDilemma") {
            for (int i = 0; i < numRounds; i++)
                rounds[i] = new rndBD(hayHuman);
        }
        else {
            int M[2][2][2];
            readPayoffMatrix(partido, M);

            for (int i = 0; i < numRounds; i++)
                rounds[i] = new rndMG(M, hayHuman);
        }

        // cout << "Players and rounds created" << endl;
        
        double aves[2] = {0.0, 0.0};
        system("rm ../SimulatedWorld/History.txt");
        for (int i = 0; i < numRounds; i++) {
            if (hayHuman)
                writeGameOverMessage(i);
            rounds[i]->playRound(mg0, mg1, player0, player1);

            cout << "Round " << i << ": " << rounds[i]->scores[0] << ", " << rounds[i]->scores[1] << endl;

            aves[0] += rounds[i]->scores[0];
            aves[1] += rounds[i]->scores[1];
            
            if (hayHuman)
                usleep(1500000);
        }

        cout << "Total: " << aves[0] << ", " << aves[1] << endl;

        if (hayHuman) {
            writeGameOverMessage(-99);
        }

        logScores(aves);

        // cout << "cleaning up" << endl;

        for (int i = 0; i < numRounds; i++) {
            delete rounds[i];
        }
        delete[] rounds;

        delete player0;
        delete player1;
    }
    else if (!strcmp(argv[1], "gengen")) {       // determine matrix of payoffs for generators vs generators
        if (argc != 5) {
            cout << "Wrong number of parameters to play a game: " << argc << endl;
            return -1;
        }

        string partido = argv[2];
        int numRounds = atoi(argv[3]);
        int plyrNum = atoi(argv[4]);
        bool hayHuman = false;

        cout << "Determining how generators do against each other" << endl;

        MarkovGame *mg[2];
        AbstractAlegAATr *players[2];

        mg[plyrNum] = new MarkovGame(partido.c_str());
        players[plyrNum] = createPlayer(mg[plyrNum], "train_alegaatr", plyrNum, partido);

        mg[1-plyrNum] = new MarkovGame(partido.c_str());
        players[1-plyrNum] = createPlayer(mg[1-plyrNum], "training_associate", 1-plyrNum, partido);

        cout << "generator vs generator numbers" << endl;
        double outcomes[10][10][2];
        // int id = 0;
        // int id = getGenVsGenResults(players, mg, partido, plyrNum, numRounds, outcomes, 30, 0);
        // recordMatrixOutcomes(players, partido, outcomes, 0);
        // recordMatrixOutcomes(players, partido, outcomes, 1);

        for (int i = 1; i <= numRounds; i++) {
            cout << "gengen " << i << endl;
            int id = getGenVsGenResults(players, mg, partido, plyrNum, i, outcomes, 30, 0);
            recordMatrixOutcomes(players, partido, outcomes, 0, i);
            recordMatrixOutcomes(players, partido, outcomes, 1, i);
        }

    }
    else if (!strcmp(argv[1], "train")) {     // gather training data for alegaatr to play a game for n rounds
        if (argc != 5) {
            cout << "Wrong number of parameters to play a game: " << argc << endl;
            return -1;
        }

        string partido = argv[2];
        int numRounds = atoi(argv[3]);
        int plyrNum = atoi(argv[4]);
        bool hayHuman = false;

        cout << "Gathering training data for the game " << partido << " (as player " << plyrNum << ")" << endl;

        // remove the previous training files
        stringstream fnombre0;
        fnombre0 << "rm Data_" << partido << "_" << plyrNum << ".txt";
        system(fnombre0.str().c_str());

        MarkovGame *mg[2];
        AbstractAlegAATr *players[2];

        mg[plyrNum] = new MarkovGame(partido.c_str());
        players[plyrNum] = createPlayer(mg[plyrNum], "train_alegaatr", plyrNum, partido);

        mg[1-plyrNum] = new MarkovGame(partido.c_str());
        players[1-plyrNum] = createPlayer(mg[1-plyrNum], "training_associate", 1-plyrNum, partido);

        cout << "generator vs generator numbers" << endl;
        double outcomes[10][10][2];
        int id = 0;
        // read in the outcomes
        readMatrixOutcomes(players, partido, outcomes, 0);
        readMatrixOutcomes(players, partido, outcomes, 1);

        // cout << "Gen vs Gen scores: " << endl << "\t";
        // for (int i = 0; i < players[0]->generators.size(); i++)
        //     cout << players[plyrNum]->generators[i]->nickname << "\t\t";
        // cout << endl;

        // for (int p1 = 0; p1 < players[0]->generators.size(); p1++) {
        //     cout << players[0]->generators[p1]->nickname << "\t";
        //     for (int p2 = 0; p2 < players[1]->generators.size(); p2++) {
        //         cout << (int)(outcomes[p1][p2][0] + 0.5) << "  " << (int)(outcomes[p1][p2][1] + 0.5) << " |\t";
        //     }
        //     cout << endl;
        // }

        ((TrainingAssociate *)players[1-plyrNum])->setGenVsGen(outcomes, numRounds);

        cout << "generator vs switching associates" << endl;
        // for (int i = 0; i < 4; i++) {
            double swProb = 0.4;//0.2 + ((double)rand() / RAND_MAX) / 3.3333;
            // cout << "swProb: " << swProb << endl;
            // id = getGenVsGenResults(players, mg, partido, plyrNum, numRounds, outcomes, 1, id, true);
            id = getGenVsSwitcherResults(players, mg, partido, plyrNum, numRounds, 0.0, STATIONARY, id);
            id = getGenVsSwitcherResults(players, mg, partido, plyrNum, numRounds, swProb, STATIONARY, id);
            id = getGenVsSwitcherResults(players, mg, partido, plyrNum, numRounds, swProb, COURNOT, id);
            id = getGenVsSwitcherResults(players, mg, partido, plyrNum, numRounds, swProb, FAIR, id);
            id = getGenVsSwitcherResults(players, mg, partido, plyrNum, numRounds, swProb, STACKELBERG, id);
        // }

        delete players[0];
        delete players[1];
    }
    else if (!strcmp(argv[1], "trainmas")) {
        for (int j = 0; j < 12; j++) {
            if (argc != 5) {
                cout << "Wrong number of parameters to play a game: " << argc << endl;
                return -1;
            }

            string partido = argv[2];
            int numRounds = atoi(argv[3]);
            int plyrNum = atoi(argv[4]);
            bool hayHuman = false;

            cout << "Gathering training data for the game " << partido << " (as player " << plyrNum << ")" << endl;

            MarkovGame *mg1[2], *mg2[2];
            AbstractAlegAATr *players1[2], *players2[2];

            cout << "generator vs AlegAATr" << endl;
            mg1[plyrNum] = new MarkovGame(partido.c_str());
            mg1[1-plyrNum] = new MarkovGame(partido.c_str());
            players1[plyrNum] = createPlayer(mg1[plyrNum], "train_alegaatr", plyrNum, partido);
            players1[1-plyrNum] = createPlayer(mg1[1-plyrNum], "alegaatr_changer", 1-plyrNum, partido);

            mg2[plyrNum] = new MarkovGame(partido.c_str());
            mg2[1-plyrNum] = new MarkovGame(partido.c_str());
            players2[1-plyrNum] = createPlayer(mg2[1-plyrNum], "train_alegaatr", 1-plyrNum, partido);
            players2[plyrNum] = createPlayer(mg2[plyrNum], "alegaatr_changer", plyrNum, partido);

            int id1 = determineNumDataSamples(partido, plyrNum);
            int id2 = determineNumDataSamples(partido, 1-plyrNum);
            
            // for (int i = 0; i < 6; i++) {
                cout << "iteration " << j << endl;
                id1 = getGenVsAlegAATrResults(players1, mg1, partido, plyrNum, numRounds, id1);
                id2 = getGenVsAlegAATrResults(players2, mg2, partido, 1-plyrNum, numRounds, id2);
            // }

            delete players1[0];
            delete players1[1];
            delete players2[0];
            delete players2[1];
        }
    }
    else if (!strcmp(argv[1], "self")) {
        if (argc != 4) {
            cout << "Wrong number of parameters to play a game: " << argc << endl;
            return -1;
        }

        string partido = argv[2];
        int numRounds = atoi(argv[3]);
        bool hayHuman = false;

        for (int g = 0; g < 50; g++) {
            MarkovGame *mg0 = new MarkovGame(partido.c_str());
            string agnt = "alegaatr";
            AbstractAlegAATr *player0 = createPlayer(mg0, agnt, 0, partido);

            MarkovGame *mg1 = new MarkovGame(partido.c_str());
            agnt = "alegaatr";
            AbstractAlegAATr *player1 = createPlayer(mg1, agnt, 1, partido);

            aRound **rounds = new aRound*[numRounds];
            if (partido == "blockDilemma") {
                for (int i = 0; i < numRounds; i++)
                    rounds[i] = new rndBD(hayHuman);
            }
            else {
                int M[2][2][2];
                readPayoffMatrix(partido, M);

                for (int i = 0; i < numRounds; i++)
                    rounds[i] = new rndMG(M, hayHuman);
            }

            // cout << "Players and rounds created" << endl;
            
            double aves[2] = {0.0, 0.0};
            system("rm ../SimulatedWorld/History.txt");
            for (int i = 0; i < numRounds; i++) {
                if (hayHuman)
                    writeGameOverMessage(i);
                rounds[i]->playRound(mg0, mg1, player0, player1);

                cout << "Round " << i << ": " << rounds[i]->scores[0] << ", " << rounds[i]->scores[1] << endl << endl;

                aves[0] += rounds[i]->scores[0];
                aves[1] += rounds[i]->scores[1];
                
                if (hayHuman)
                    usleep(1500000);
            }

            logScores(aves);

            for (int i = 0; i < numRounds; i++) {
                delete rounds[i];
            }
            delete[] rounds;

            delete player0;
            delete player1;
        }
    }
    else {
        cout << "Unknown purpose for the program" << endl;
    }

    return 0;
}