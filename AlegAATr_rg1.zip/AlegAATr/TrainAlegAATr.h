#ifndef TRAINALEGAATR_H
#define TRAINALEGAATR_H

#include "defs.h"
#include "AbstractAlegAATr.h"
#include "MarkovGame.h"
#include "State.h"
#include "CFR.h"
#include "Xprt.h"

using namespace std;

class TrainAlegAATr : public AbstractAlegAATr {
public:
    TrainAlegAATr();
    TrainAlegAATr(int _plyrNum, MarkovGame *_mg, string _partido);
    ~TrainAlegAATr();

    int makeMove(State *s);
    void updateAfterMove(State *s, int actions[2]);
    void updateRound();

    void configureTrainingRun(string _startGen, string _nextGen, int _changeFreq, AbstractAlegAATr *_trainer);
    void configureMas(ofstream &logstream, int _id);
    // void createGenerators(vector<string> genConfig);
    // vector<string> readGeneratorConfig();
    void logStatus(ofstream &logstream, int _id);
    void initializeCheckers();
    bool assumptionsTrue(string myGen, string otherGen);

private:
    AbstractAlegAATr *trainer;
    int startGen, nextGen, t, changeFreq;
    double payoffsSoFar, theirPayoffsSoFar;
    string wasUsing, willUse;
    State *lastState;
};

#endif