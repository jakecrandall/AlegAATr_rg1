#ifndef __Solver__Qset__
#define __Solver__Qset__

#include "defs.h"

class Qset {
public:
    Qset();
    Qset(double _w, int _numActions[2]);
    ~Qset();
    
    int highestAction(int _me, double *probs);
    int highestAction2(int _me, double *probs, double reflectiveActionValues[10]);
    double maxVal();
    double maxM(int index);
    double correctM(int index);
    int correctA(int index);
    void printQs();
    
    double getConformance(int ind, int act);
    
    double w;
    int numActions[2];
    double **Qs, V;
    double ***M;
};

#endif
