#ifndef CHECKER_H
#define CHECKER_H

#include "defs.h"

using namespace std;

class Checker {
public:
    Checker() {
        nombre = "none";
        val = 0.0;
        timesUpdated = 0;
    }

    Checker(string _nombre, double _val) {
        nombre = _nombre;
        val = resetVal = _val;
        timesUpdated = 0;
    }

    ~Checker() {}

    void update(double o, double lambda) {
        // cout << "update " << nombre << " with " << o << endl;
        val = val * lambda + o * (1 - lambda);
        timesUpdated ++;
    }

    void reset() {
        val = resetVal;
    }

    void print() {
        cout << "   " << nombre << ": " << val << "  (" << timesUpdated << ")" << endl;
    }

    void print2File(ofstream &output) {
        output << val << ",";
    }

    string nombre;
    double val, resetVal;
    int timesUpdated;
};

#endif