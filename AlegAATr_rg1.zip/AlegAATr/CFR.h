#ifndef CFR_H
#define CFR_H

#include "defs.h"
#include "Player.h"
#include "MarkovGame.h"
#include "Node.h"

#define MAX_NODES       50000
#define MAX_DEPTH       40

class CFR : public Player {
public:
    CFR();
    CFR(int _me, MarkovGame *_mg, int _maxDepth, bool _update);
    ~CFR();
    
    int Move(State *s);
    int moveUpdate(State *s, int actions[2]);
    int roundUpdate(bool wasUsed);
    int generateAction(double *v, int numActs);

    void restoreFactorySettings();
    
    void buildGameTree();
    void printGameTree(char gameName[1024]);
    void readGameTree(char gameName[1024]);
    int findNode(State *s, int nivel);
    bool isGoalState(int s);
    int alreadyExists(State *s, int strt, int nd);
    int alreadyExists(State *s);
    int alreadyExists(int s);
    void initAlready();
    void computeNE();
    
    void reset();
    void initCounts();
    void updateMe();
    void computeUtilities(int index);
    void computeReachability(int index);
    void updateRegret(int index);
    void updatePolicy(int index, int T);
    
    int me;
    MarkovGame *mg;
    int maxDepth, actualDepth;
    
    Node *gameTree[MAX_NODES*MAX_DEPTH];
    int numNodes;
    int levelCounter[MAX_DEPTH+1];
    
    Node *cNode;
    bool lastValidActs[2][NUMACTIONS*2];
    
    bool update;
    
    int numMovemientos, t;

    // checker-related variables
    double chHighPayout, chLowPayout, chMyPayout;
    int numRoundMoves, numSupportedMoves;
    double chMyAve;
    int chUseCount;
};

#endif
