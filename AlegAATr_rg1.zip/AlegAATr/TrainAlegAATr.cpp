#include "TrainAlegAATr.h"

TrainAlegAATr::TrainAlegAATr() {
    cout << "Incomplete TrainAlegAATr constructor" << endl;
    exit(1);
}

TrainAlegAATr::TrainAlegAATr(int _plyrNum, MarkovGame *_mg, string _partido) {
    plyrNum = _plyrNum;
    mg = _mg;
    computeMGThings();

    vector<string> genConfig = readGeneratorConfig();

    // cout << "creating TrainAlegAATr generators: " << _mg->states[0] << endl;
    createGenerators(genConfig);

    startGen = -1;
    currentGenerator = -1;
    changeFreq = 50;
    payoffsSoFar = 0.0;
    theirPayoffsSoFar = 0.0;
}

TrainAlegAATr::~TrainAlegAATr() {
    for (int i = 0; i < generators.size(); i++) {
        delete generators[i];
    }
}

void TrainAlegAATr::configureTrainingRun(string _startGen, string _nextGen, int _changeFreq, AbstractAlegAATr *_trainer) {
    changeFreq = _changeFreq;
    trainer = _trainer;

    // set up the generator schedule
    for (int i = 0; i < generators.size(); i++) {
        if (generators[i]->nickname == _startGen)
            startGen = i;
    }
    if (startGen == -1) {
        cout << "tenemos un problema: <" << _startGen << ">" << endl;
        exit(1);
    }
    currentGenerator = startGen;

    for (int i = 0; i < generators.size(); i++) {
        if (generators[i]->nickname == _nextGen)
            nextGen = i;
    }
    if (nextGen == -1) {
        cout << "tenemos un problema: <" << _startGen << ">" << endl;
        exit(1);
    }

    if (_changeFreq == 0)
        startGen = currentGenerator = nextGen;

    // cout << "starting with generator " << generators[currentGenerator]->nickname << " (until round " << changeFreq << "); then " << generators[nextGen]->nickname << endl;

    // start the logging
    t = 0;
    payoffsSoFar = 0.0;
    theirPayoffsSoFar = 0.0;
    wasUsing = "----";
    willUse = generators[currentGenerator]->nickname;

    // reset the generators
    for (int i = 0; i < generators.size(); i++)
        generators[i]->restoreFactorySettings();
}

void TrainAlegAATr::configureMas(ofstream &logstream, int _id) {
    // initializeCheckers();
    logStatus(logstream, _id);
}

int TrainAlegAATr::makeMove(State *s) {
    lastState = s;

    // cout << "TrainAlegAATr to make move: " << generators[currentGenerator]->nickname << endl;
    // cout << "   " << s << endl;

    vector<int> theMoves;
    for (int i = 0; i < generators.size(); i++) {
        theMoves.push_back(generators[i]->Move(s));
    }

    return theMoves[currentGenerator];
}

void TrainAlegAATr::updateAfterMove(State *s, int actions[2]) {
    for (int i = 0; i < generators.size(); i++) {
        generators[i]->moveUpdate(s, actions);
    }

    int jact = lastState->jointCode(actions);
    payoffsSoFar += lastState->rewards[jact][0][plyrNum];
    theirPayoffsSoFar += lastState->rewards[jact][0][1-plyrNum];
}

void TrainAlegAATr::updateRound() {
    for (int i = 0; i < generators.size(); i++) {
        if (i == currentGenerator)
            generators[i]->roundUpdate(true);
        else
            generators[i]->roundUpdate(false);
    }

    wasUsing = generators[currentGenerator]->nickname;
    if (t == (changeFreq-1)) {
        int previousGenerator = currentGenerator;
        currentGenerator = nextGen;
        // currentGenerator = rand() % generators.size();
        // while (currentGenerator == previousGenerator)
        //     currentGenerator = rand() % generators.size();

        if ((previousGenerator != currentGenerator) && strncmp(generators[currentGenerator]->nickname, "cfr", 3)) {
            ((Xprt *)generators[currentGenerator])->ab->xprts[0]->guilt = 0.0;
            ((Xprt *)generators[currentGenerator])->ab->xprts[0]->betrayed = false;
        }
    }
    t++;
    willUse = generators[currentGenerator]->nickname;
}

// void TrainAlegAATr::createGenerators(vector<string> genConfig) {
//     char tipito[1024];

//     for (int i = 0; i < genConfig.size(); i++) {
//         cout << "Generator: " << genConfig[i] << endl;
//         if (genConfig[i] == "cfr") {
//             generators.push_back(new CFR(plyrNum, mg, 40, false));
//         }
//         else if (genConfig[i] == "maxmin") {
//             strcpy(tipito, "maxmin");
//             generators.push_back(new Xprt(plyrNum, mg, tipito));
//         }
//         else if (genConfig[i] == "coop") {
//             strcpy(tipito, "coop");
//             generators.push_back(new Xprt(plyrNum, mg, tipito));
//         }
//         else if (genConfig[i] == "coopp") {
//             strcpy(tipito, "coopp");
//             generators.push_back(new Xprt(plyrNum, mg, tipito));
//         }
//         else if (genConfig[i] == "bullyp") {
//             strcpy(tipito, "bullyp");
//             generators.push_back(new Xprt(plyrNum, mg, tipito));
//         }
//         else if (genConfig[i] == "bullied") {
//             strcpy(tipito, "bullied");
//             generators.push_back(new Xprt(plyrNum, mg, tipito));
//         }
//         else {
//             cout << "generator " << genConfig[i] << " not found" << endl;
//         }
//     }
// }

// vector<string> TrainAlegAATr::readGeneratorConfig() {
//     vector<string> genConfig;

//     ifstream input("allGens.txt");

//     string line;
//     while (!input.eof()) {
//         getline(input, line);
//         if (line.length() > 1)
//             genConfig.push_back(line);
//         else
//             break;

//     }

//     input.close();

//     return genConfig;
// }

void TrainAlegAATr::logStatus(ofstream &logstream, int _id) {
    logstream << _id << ",";
    logstream << t << ",";
    logstream << wasUsing << ",";
    // logstream << willUse << ",";
    logstream << payoffsSoFar << ",";
    double expectedPayoffs2Go = (EXPECTED_ROUNDS - t) * generators[currentGenerator]->chExpectedPayout;
    logstream << theirPayoffsSoFar << ",";
    logstream << expectedPayoffs2Go << ",";
    for (int i = 0; i < generators.size(); i++) {
        for (int j = 0; j < generators[i]->checkers.size(); j++) {
            generators[i]->checkers[j]->print2File(logstream);
        }
    }
    logstream << endl;
}

void TrainAlegAATr::initializeCheckers() {
    double valueNot;
    for (int i = 0; i < generators.size(); i++) {
        if (assumptionsTrue(generators[i]->nickname, trainer->generators[trainer->currentGenerator]->nickname))
            valueNot = 0.5 + (((double)rand() / RAND_MAX) / 2.0);
        else
            valueNot = (((double)rand() / RAND_MAX) / 2.0);

        for (int j = 0; j < generators[i]->checkers.size()-1; j++) {
            generators[i]->checkers[j]->val = valueNot;
        }
    }
}

bool TrainAlegAATr::assumptionsTrue(string myGen, string otherGen) {
    if (myGen == "maxmin") {
        if ((otherGen == "coop") || (otherGen == "coopp") || (otherGen == "bullied"))
            return true;
        else
            return false;
    }
    else if (myGen == "bullied") {
        if (otherGen == "maxmin")
            return false;
        else
            return true;        
    }
    else if (myGen == "bullyp") {
        if (otherGen == "bullied")
            return true;
        else
            return false;
    }
    else if (myGen == "coopp") {
        if ((otherGen == "coop") || (otherGen == "coopp") || (otherGen == "bullied"))
            return true;
        else
            return false;
    }
    else if (myGen == "coop") {
        if ((otherGen == "coop") || (otherGen == "coopp") || (otherGen == "bullied"))
            return true;
        else
            return false;
    }
    else if (myGen == "cfr") {
        if (otherGen == "cfr")
            return true;
        else
            return false;
    }

    return true;
}


