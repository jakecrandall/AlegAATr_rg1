#include "Xprt.h"

Xprt::Xprt() {
    printf("incomplete Xprt constructor\n");
}

Xprt::Xprt(int _me, MarkovGame *_mg, char tipito[1024], bool allowSwitching) {
    me = _me;

    strcpy(nickname, tipito);
    
    expertID = 0;
    ab = new abbert(_mg, me, allowSwitching);
    if (!strcmp(tipito, "maxmin")) {
        ab->computeMaxminExpert(0.99);

        chExpectedPayout = _mg->states[0]->mm[me]->mv;
        chMyAve = chExpectedPayout;

        checkers.push_back(new Checker("MAXMIN_harms_me", 1.0));
        checkers.push_back(new Checker("MAXMIN_payoffs_expected", 0.5));
    }
    else if (!strcmp(tipito, "coop")) {
        ab->computeFolkEgalExpert(0.99, false);

        chExpectedPayout = ab->xprts[0]->barR[me];
        chUseCount = 0;
        chMyAve = chExpectedPayout;
        chTheirLow = getTheirLow();
        // std::cout << "theirLow: " << ab->xprts[0]->stratVals[chTheirLow][1-me] << std::endl;

        checkers.push_back(new Checker("COOP_wants_cooperation", 1.0));
        checkers.push_back(new Checker("COOP_mirrors_cooperation", 1.0));
        checkers.push_back(new Checker("COOP_doesnt_exploit", 1.0));
        checkers.push_back(new Checker("COOP_payoffs_expected", 0.5));
    }
    else if (!strcmp(tipito, "coopp")) {
        ab->computeFolkEgalExpert(0.99, true);

        chExpectedPayout = ab->xprts[0]->barR[me];
        chUseCount = 0;
        chMyAve = chExpectedPayout;
        chTheirLow = getTheirLow();
        chPunishedLast = false;
        getEgalVals();
        // std::cout << "theirLow: " << ab->xprts[0]->stratVals[chTheirLow][1-me] << std::endl;

        checkers.push_back(new Checker("COOPP_coopAfterPunishment", 1.0));
        checkers.push_back(new Checker("COOPP_mirrors_cooperation", 1.0));
        // checkers.push_back(new Checker("COOPP_FairShare", 1.0));
        checkers.push_back(new Checker("COOPP_payoffs_expected", 0.5));
    }
    else if (!strcmp(tipito, "bullied")) {
        ab->computeBullyExpert(0.99, false, false);

        chExpectedPayout = ab->xprts[0]->barR[me];
        chTheirLow = getTheirLow();
        chMyAve = chExpectedPayout;

        checkers.push_back(new Checker("BULLIED_harmsnot_ifi", 1.0));
        checkers.push_back(new Checker("BULLIED_other_unfair", 1.0));
        checkers.push_back(new Checker("BULLIED_payoffs_expected", 0.5));
    }
    else if (!strcmp(tipito, "bullyp")) {
        ab->computeBullyExpert(0.99, true, true);

        chExpectedPayout = ab->xprts[0]->barR[me];
        // chHasConformedCount = chHasNotConformedCount = chConformedInRowCount = 0;
        chHasConformedCount_used = chHasNotConformedCount_used = chConformedInRowCount_used = 0;
        // std::cout << "chExpectedPayout: " << chExpectedPayout << std::endl;
        getEgalVals();
        chPunishedLast = false;
        chTheirLow = getTheirLow();
        chMyAve = chExpectedPayout;
        // std::cout << "chEgalVals: " << chEgal[0] << ", " << chEgal[1] << std::endl;

        // checkers.push_back(new Checker("BULLYP_notFairShare", 1.0));
        checkers.push_back(new Checker("BULLYP_givesIn", 1.0));
        checkers.push_back(new Checker("BULLYP_givesInAfterPunishment", 1.0));
        checkers.push_back(new Checker("BULLYP_conforms", 1.0));
        checkers.push_back(new Checker("BULLYP_payoffs_expected", 0.5));
    }
    else {
        printf("expert NOT found\n");
        exit(1);
    }

    lock = false;
    lockCount = 0;

    chItShouldGet = -99999;
    chYoShouldGet = -99999;
    chCouldProfitbyDeviatingFromCurrent = false;
    chRounds = 0;
    chConformedCurrent[0] = chConformedCurrent[1] = true;
    chConformed2TheirLow[0] = chConformed2TheirLow[1] = true;
    getHighLowCheckerPayouts();

    ab->determineHighLevelActions();
    
    lastState = NULL;
    rPayout[0] = rPayout[1] = 0.0;
    previousPayoffs[0] = previousPayoffs[1] = -99999;
    
    ab->xprts[expertID]->reset(previousPayoffs, me);

    iWasHeard = true;
    asExpected = false;
}

Xprt::~Xprt() {
    delete ab;
    // delete comms;
}

void Xprt::restoreFactorySettings() {
    chItShouldGet = -99999;
    chYoShouldGet = -99999;
    chCouldProfitbyDeviatingFromCurrent = false;
    chRounds = 0;
    chPunishedLast = false;
    chConformedCurrent[0] = chConformedCurrent[1] = true;
    chConformed2TheirLow[0] = chConformed2TheirLow[1] = true;
    getHighLowCheckerPayouts();
    ab->determineHighLevelActions();
    lastState = NULL;
    rPayout[0] = rPayout[1] = 0.0;
    previousPayoffs[0] = previousPayoffs[1] = 0.0;
    ab->xprts[expertID]->reset(previousPayoffs, me);
    iWasHeard = true;
    ab->reset();
    for (int i = 0; i < checkers.size(); i++)
        checkers[i]->reset();

    lock = false;
    lockCount = 0;
}

int Xprt::Move(State *s) {//bool validActions[NUMACTIONS], bool _onGoal, bool _verbose) {
    lastState = s;

    // std::cout << nickname << std::endl;
    int a = ab->xprts[expertID]->Move(lastState, previousPayoffs, me);

    if (ab->xprts[expertID]->tipo == MINIMAX) {
        // return generateAction(s->mm[_me]->ms, s->numActions[_me]);
        for (int i = 0; i < s->numActions[me]; i++) {
            actionConsiderations[i] = s->mm[me]->ms[i];
        }        
    }
    else if (ab->xprts[expertID]->tipo == LEADER2) {
        if ((ab->xprts[expertID]->guilt > 0.00001) || ab->xprts[expertID]->betrayed) {
            for (int i = 0; i < s->numActions[me]; i++) {
                actionConsiderations[i] = s->attack[me]->ms[i];
            }        
            // if (me == 1)
            //     cout << "   LEADER Punish: think " << nickname << " would play " << a << endl;
        }
        else {
            // if (me == 1)
            //     cout << "   LEADER Give: think " << nickname << " would play " << a << endl;
            for (int i = 0; i < s->numActions[me]; i++) {
                if (((Expert *)(ab->xprts[expertID]))->reflectiveActionValues[i] >= (((Expert *)(ab->xprts[expertID]))->reflectiveActionValues[a] - 0.01))
                    actionConsiderations[i] = 1.0;
                else
                    actionConsiderations[i] = 0.0;               
            }        
        }
    }
    else {
        // if (me == 1)
        //     cout << "   Follower: think " << nickname << " would play " << a << endl;

        // if (!strcmp(nickname, "coop"))
        //     std::cout << "other (" << ((Expert *)(ab->xprts[expertID]))->reflectiveActionValuesOther[a] << "): ";
        for (int i = 0; i < s->numActions[me]; i++) {
            // if (!strcmp(nickname, "coop"))
            //     std::cout << ((Expert *)(ab->xprts[expertID]))->reflectiveActionValuesOther[i] << " ";
            if (((Expert *)(ab->xprts[expertID]))->reflectiveActionValues[i] >= (((Expert *)(ab->xprts[expertID]))->reflectiveActionValues[a] - 0.01))
                actionConsiderations[i] = 1.0;
            else if (((Expert *)(ab->xprts[expertID]))->reflectiveActionValuesOther[i] >= (((Expert *)(ab->xprts[expertID]))->reflectiveActionValuesOther[a] - 0.01))
                actionConsiderations[i] = 0.10;
            else
                actionConsiderations[i] = 0.0;
        }
        // if (!strcmp(nickname, "coop"))
        //     std::cout << std::endl;
    }

    // cout << "action " << a << endl;

    corA[0] = corA[1] = -1;
    corALow[0] = corALow[1] = -1;
    if ((ab->xprts[expertID]->tipo == FOLLOWER) || (ab->xprts[expertID]->tipo == LEADER) || (ab->xprts[expertID]->tipo == LEADER2)) {
        // if (ab->xprts[expertID]->currentStep < 0) {
        //     std::cout << "caught it" << std::endl;
        //     double P[2] = {0.0, 0.0};
        //     ab->xprts[expertID]->getCurrentStep(P, me, false);
        // }
        // std::cout << "qset: " << ab->xprts[expertID]->strat[ab->xprts[expertID]->currentStep] << std::endl;
        corA[1-me] = lastState->qsets[ab->xprts[expertID]->strat[ab->xprts[expertID]->currentStep]]->correctA(1-me);
        // std::cout << "c" << std::endl;
        corA[me] = lastState->qsets[ab->xprts[expertID]->strat[ab->xprts[expertID]->currentStep]]->correctA(me);
        // std::cout << "chTheirLow: " << chTheirLow << std::endl;
        corALow[1-me] = lastState->qsets[ab->xprts[expertID]->strat[chTheirLow]]->correctA(1-me);
        corALow[me] = lastState->qsets[ab->xprts[expertID]->strat[chTheirLow]]->correctA(me);
        // std::cout << "corALow: " << corALow[0] << ", " << corALow[1] << std::endl;

        int jact;
        if (me == 0)
            jact = s->jointCode(a, corA[1]);
        else
            jact = s->jointCode(corA[0], a);

        // std::cout << "d" << std::endl;        

        //chItShouldGet += s->rewards[jact][0][1-me];
        if (chItShouldGet == -99999) {
            chItShouldGet = lastState->qsets[ab->xprts[expertID]->strat[ab->xprts[expertID]->currentStep]]->correctM(1-me);
            chYoShouldGet = lastState->qsets[ab->xprts[expertID]->strat[ab->xprts[expertID]->currentStep]]->correctM(me);
        }

        for (int i = 0; i < s->numActions[1-me]; i++) {
            if (i == corA[1-me])
                continue;

            if (me == 0) {
                if (lastState->qsets[ab->xprts[expertID]->strat[ab->xprts[expertID]->currentStep]]->M[a][i][1-me] > lastState->qsets[ab->xprts[expertID]->strat[ab->xprts[expertID]->currentStep]]->correctM(1-me))
                    chCouldProfitbyDeviatingFromCurrent = true;
            }
            else {
                if (lastState->qsets[ab->xprts[expertID]->strat[ab->xprts[expertID]->currentStep]]->M[i][a][1-me] > lastState->qsets[ab->xprts[expertID]->strat[ab->xprts[expertID]->currentStep]]->correctM(1-me))
                    chCouldProfitbyDeviatingFromCurrent = true;
            }
        }

    }

    //printf("cA%i ... ", corA);
    myLastMoveRec = a;
    
    return a;
}

int Xprt::moveUpdate(State *s, int actions[2]) {
    int jact = lastState->jointCode(actions);
    rPayout[0] += lastState->rewards[jact][0][0];
    rPayout[1] += lastState->rewards[jact][0][1];

    ab->moveUpdate(lastState, s, actions, expertID, rPayout, ab->xprts[expertID]->barR[me], corA[1-me]);

    if (!strcmp(nickname, "coop") || !strcmp(nickname, "coopp")) {
        // std::cout << "currentStrat: " << ab->xprts[expertID]->currentStep << "; theirLowStrat: " << chTheirLow << std::endl;

        // check to see if the two players conformed with the current strategy
        double maxVal = lastState->qsets[ab->xprts[expertID]->strat[ab->xprts[expertID]->currentStep]]->Qs[corA[0]][corA[1]]; //maxVal();
        double actVal[2];
        actVal[0] = lastState->qsets[ab->xprts[expertID]->strat[ab->xprts[expertID]->currentStep]]->Qs[actions[0]][corA[1]];
        actVal[1] = lastState->qsets[ab->xprts[expertID]->strat[ab->xprts[expertID]->currentStep]]->Qs[corA[0]][actions[1]];
        bool theyBeenAConformin = chConformedCurrent[1-me];
        bool iBeenAConformin = chConformedCurrent[me];
        if ((actVal[1-me] != maxVal) && (actions[1-me] != corA[1-me]) && iBeenAConformin)
            chConformedCurrent[1-me] = false;
        if ((actVal[me] != maxVal) && (actions[me] != corA[me]) && theyBeenAConformin)
            chConformedCurrent[me] = false;

        // check to see if the two players conformed with the partner's low strategy
        maxVal = lastState->qsets[ab->xprts[expertID]->strat[chTheirLow]]->Qs[corALow[0]][corALow[1]];//maxVal();
        actVal[0] = lastState->qsets[ab->xprts[expertID]->strat[chTheirLow]]->Qs[actions[0]][corALow[1]];
        actVal[1] = lastState->qsets[ab->xprts[expertID]->strat[chTheirLow]]->Qs[corALow[0]][actions[1]];
        // printf("maxVal: %lf; lowActVals: %lf, %lf\n", maxVal, actVal[0], actVal[1]);
        theyBeenAConformin = chConformed2TheirLow[1-me];
        iBeenAConformin = chConformed2TheirLow[me];
        // if (iBeenAConformin)
        //     printf("iBeenAConformin: (+ %i vs %i)\n", actions[1-me], corALow[1-me]);
        if ((actVal[1-me] < (maxVal-1.0)) && (actions[1-me] != corALow[1-me]) && iBeenAConformin) {
            // std::cout << "they violated low" << std::endl;
            chConformed2TheirLow[1-me] = false;
        }
        if ((actVal[me] < (maxVal-1.0)) && (actions[me] != corALow[me]) && theyBeenAConformin) {
            // std::cout << "i violated low" << std::endl;
            chConformed2TheirLow[me] = false;
        }
    }

    else if (!strcmp(nickname, "bullyp")) {
        double maxVal = lastState->qsets[ab->xprts[expertID]->strat[ab->xprts[expertID]->currentStep]]->maxVal();
        double actVal = lastState->qsets[ab->xprts[expertID]->strat[ab->xprts[expertID]->currentStep]]->Qs[actions[0]][actions[1]];

        if ((actVal < (maxVal - 1.0)) && (actions[1-me] != corA[1-me])) {
            // cout << "actVal: " << actVal << "; maxVal: " << maxVal << endl;
            // cout << "**************** didn't conform with bullyp" << endl;
            chConformedCurrent[1-me] = false;
        }
        else {
            // cout << "**************** conformed with bully" << endl;
        }
    }

    if (myLastMoveRec != actions[me]) // agent didn't follow my recommendation
        iWasHeard = false;

    return 0;
}

int Xprt::roundUpdate(bool wasUsed) {
    //printf("updating the round\n"); fflush(stdout);
    ab->roundUpdate(rPayout);

    // cout << "shoulda got " << ab->xprts[0]->stratVals[ab->xprts[0]->currentStep][me] << " (vs " << rPayout[me] << ")" << endl;
    if ((ab->xprts[expertID]->tipo == FOLLOWER) || (ab->xprts[expertID]->tipo == LEADER2)) {
        if (rPayout[me] >= ab->xprts[0]->stratVals[ab->xprts[0]->currentStep][me])
            asExpected = true;
        else
            asExpected = false;
    }
    else if (ab->xprts[expertID]->tipo == MINIMAX) {
        if (rPayout[me] >= chExpectedPayout)
            asExpected = true;
        else
            asExpected = false;
    }
    
    //printf("Rresult (%i): %.2lf, %.2lf\n", me, rPayout[0], rPayout[1]);
    if ((ab->xprts[expertID]->tipo == FOLLOWER) || (ab->xprts[expertID]->tipo == LEADER)) {
        bool heldTrue = false;
        if ((ab->xprts[expertID]->tipo == FOLLOWER) || (ab->xprts[expertID]->tipo == LEADER)) {
            if (ab->lastActions[1-me][ab->xprts[expertID]->strat[ab->xprts[expertID]->currentStep]+2] == 1) {
                //printf("held true\n");
                heldTrue = true;
            }
        }
    }
    
    //printf("Xprt: do I need to update the aspiration level????\n");
    //printf("Xprt: i need to at least update the `heldTrue' value I think\n");
    
    bool heldTrue = false;
    if ((ab->xprts[expertID]->tipo == FOLLOWER) || (ab->xprts[expertID]->tipo == LEADER) || (ab->xprts[expertID]->tipo == LEADER2)) {
        if (ab->lastActions[1-me][ab->xprts[expertID]->strat[ab->xprts[expertID]->currentStep]+2] == 1) {
            //printf("held true\n");
            heldTrue = true;
        }
    }
    double asp = ab->xprts[expertID]->barR[me];
    ab->xprts[expertID]->Update(rPayout, me, 100.0, heldTrue, asp);

    doCheckerUpdates(wasUsed);
    
    previousPayoffs[0] = rPayout[0];
    previousPayoffs[1] = rPayout[1];
    rPayout[0] = rPayout[1] = 0.0;

    chConformedCurrent[0] = chConformedCurrent[1] = true;
    chConformed2TheirLow[0] = chConformed2TheirLow[1] = true;
    chItShouldGet = -99999;
    chYoShouldGet = -99999;
    chCouldProfitbyDeviatingFromCurrent = false;

    if (previousPayoffs[1-me] <= ab->mg->states[0]->mm[1-me]->mv)
        chPunishedLast = true;
    else
        chPunishedLast = false;

    if (!iWasHeard) {
        // std::cout << "I was not followed -- zero'ing their guilt" << std::endl;
        ab->xprts[0]->guilt = 0;  // zero out the other player's guilt
    }
    iWasHeard = true;

    if ((ab->xprts[expertID]->guilt > 0.0) && (ab->xprts[expertID]->tipo == LEADER2) && (lockCount < 2)) {
        lock = true;
        lockCount ++;
    }
    else {
        lock = false;
        lockCount = 0;
    }

    return 0;
}

void Xprt::doCheckerUpdates(bool wasUsed) {
    // std::cout << "updating " << nickname << std::endl;
    chPayoffHist[chRounds][0] = rPayout[0];
    chPayoffHist[chRounds][1] = rPayout[1];
    chRounds ++;

    if (!strcmp(nickname, "maxmin")) {
        if (rPayout[me] <= chExpectedPayout)
            updateChecker("MAXMIN_harms_me", 1.0, 0.8);
        else
            updateChecker("MAXMIN_harms_me", 0.0, 0.8);

        if (wasUsed) {
            setChecker("MAXMIN_payoffs_expected", doExpPayout());
        }
    }
    else if (!strcmp(nickname, "coop")) {
        if (chConformed2TheirLow[1-me] && (ab->xprts[0]->stratVals[chTheirLow][1-me] >= rPayout[1-me])) {
            updateChecker("COOP_wants_cooperation", 1.0, 0.2);
        }
        else if (chConformedCurrent[1-me]) {
            updateChecker("COOP_wants_cooperation", 1.0, 0.9);
        }
        else if (!chConformedCurrent[1-me]) {
            updateChecker("COOP_wants_cooperation", 0.0, 0.8);
        }

        if (wasUsed) {
            // std::cout << "chItShouldGet: " << chItShouldGet << std::endl;
            if (chConformedCurrent[1-me])
                updateChecker("COOP_mirrors_cooperation", 1.0, 0.7);
            else
                updateChecker("COOP_mirrors_cooperation", 0.0, 0.7);

            if (rPayout[1-me] > chItShouldGet)
                updateChecker("COOP_doesnt_exploit", 0.0, 0.7);
            else
                updateChecker("COOP_doesnt_exploit", 1.0, 0.8);

            setChecker("COOP_payoffs_expected", doExpPayout());
        }
    }
    else if (!strcmp(nickname, "coopp")) {
        // int rndEvidence = 7;
        // int cuentaRec = 0;
        // double chPayoffRecentSums[2] = {0.0, 0.0};
        // for (int i = chRounds - 1; i >= 0; i--) {
        //     chPayoffRecentSums[0] += chPayoffHist[i][0];
        //     chPayoffRecentSums[1] += chPayoffHist[i][1];
        //     cuentaRec ++;

        //     if (cuentaRec == rndEvidence)
        //         break;
        // }

        // if (chPayoffRecentSums[0] < (ab->mg->states[0]->mm[0]->mv * chRounds))
        //     chPayoffRecentSums[0] = 0.0;
        // if (chPayoffRecentSums[1] < (ab->mg->states[0]->mm[1]->mv * chRounds))
        //     chPayoffRecentSums[1] = 0.0;        

        // double egalRatio, bulliedRatio, actualRatio = -99999;
        // egalRatio = chEgal[1-me] / chEgal[me];
        // bulliedRatio = chBulliedHim[1-me] / chBulliedHim[me];
        // if (chPayoffRecentSums[me] > 0) {
        //     actualRatio = chPayoffRecentSums[1-me] / chPayoffRecentSums[me];
        // }
        // else {
        //     actualRatio = egalRatio;
        // }

        // // cout << "actualRatio: " << actualRatio << endl;
        // // cout << "bulliedRatio: " << bulliedRatio << endl;
        // // cout << "egalRatio: " << egalRatio << endl;

        // if (bulliedRatio < egalRatio) {
        //     double rat;
        //     if (actualRatio <= bulliedRatio)
        //         rat = 0.0;
        //     else if (actualRatio >= egalRatio)
        //         rat = 1.0;
        //     else
        //         rat = 1.0 - ((egalRatio - actualRatio) / (egalRatio - bulliedRatio));

        //     updateChecker("COOPP_FairShare", rat, 0.2);
        // }
        // else {
        //     updateChecker("COOPP_FairShare", 1.0, 0.2);
        // }

        // std::cout << "coop wasUsed? " << (int)wasUsed << std::endl;

        if (chPunishedLast) {
            if (chConformedCurrent[1-me] && (rPayout[me] >= chExpectedPayout))
                updateChecker("COOPP_coopAfterPunishment", 1.0, 0.5);
            else if (!chConformedCurrent[1-me])
                updateChecker("COOPP_coopAfterPunishment", 0.0, 0.5);
        }

        if (wasUsed) {
            if (chConformedCurrent[1-me] && chConformedCurrent[me])
                updateChecker("COOPP_mirrors_cooperation", 1.0, 0.7);
            else if (chConformedCurrent[me])
                updateChecker("COOPP_mirrors_cooperation", 0.0, 0.7);
            setChecker("COOPP_payoffs_expected", doExpPayout());
        }
    }
    else if (!strcmp(nickname, "bullyp")) {
        // int rndEvidence = 7;
        // int cuentaRec = 0;
        // double chPayoffRecentSums[2] = {0.0, 0.0};
        // for (int i = chRounds - 1; i >= 0; i--) {
        //     chPayoffRecentSums[0] += chPayoffHist[i][0];
        //     chPayoffRecentSums[1] += chPayoffHist[i][1];
        //     cuentaRec ++;

        //     if (cuentaRec == rndEvidence)
        //         break;
        // }

        // if (chPayoffRecentSums[0] < (ab->mg->states[0]->mm[0]->mv * chRounds))
        //     chPayoffRecentSums[0] = 0.0;
        // if (chPayoffRecentSums[1] < (ab->mg->states[0]->mm[1]->mv * chRounds))
        //     chPayoffRecentSums[1] = 0.0;        

        // double egalRatio, bullyRatio, actualRatio = -99999;
        // egalRatio = chEgal[me] / chEgal[1-me];
        // bullyRatio = chExpectedPayout / ab->xprts[0]->barR[1-me];
        // if ((chPayoffRecentSums[1-me] > 0) && (chPayoffRecentSums[me] > 0)) {
        //     actualRatio = chPayoffRecentSums[me] / chPayoffRecentSums[1-me];
        // }
        // else if (chPayoffRecentSums[me] > 0.0) {
        //     actualRatio = bullyRatio;
        // }

        // // std::cout << "chPayoffRecentSums[me] = " << chPayoffRecentSums[me] << std::endl;
        // // std::cout << "Threshold = " << (chExpectedPayout * chRounds / 4.0) << std::endl;

        // if ((actualRatio != -99999) && (bullyRatio > egalRatio)) {// && (chPayoffRecentSums[me] > (chExpectedPayout * chRounds / 4.0))) {
        //     double rat;
        //     if (actualRatio <= egalRatio)
        //         rat = 0.0;
        //     else if (actualRatio >= bullyRatio)
        //         rat = 1.0;
        //     else
        //         rat = (actualRatio - egalRatio) / (bullyRatio - egalRatio);

        //     updateChecker("BULLYP_notFairShare", rat, 0.2);
        // }
        // else {
        //     updateChecker("BULLYP_notFairShare", 0.0, 0.2);
        // }

        // std::cout << "Conformed to bully? " << chConformedCurrent[1-me] << std::endl;
        // std::cout << "Punished last time? " << chPunishedLast << std::endl;

        if (chPunishedLast) {
            // cout << "*************** updating BULLYP_givesInAfterPunishment" << endl;
            if (chConformedCurrent[1-me] && (rPayout[me] >= chExpectedPayout))
                updateChecker("BULLYP_givesInAfterPunishment", 1.0, 0.5);
            else if (!chConformedCurrent[1-me])
                updateChecker("BULLYP_givesInAfterPunishment", 0.0, 0.5);
        }

        if (wasUsed) {
            // if (chConformedCurrent[1-me]) {
            //     chHasConformedCount_used ++;
            //     chConformedInRowCount_used ++;
            // }
            // else {
            //     chHasNotConformedCount_used ++;
            //     chConformedInRowCount_used = 0;
            // }
            // double val = pow(0.7, (double)chHasNotConformedCount_used); // patience parameter
            // double inc = (1.0 - val) / 4.0;
            // val += inc * chConformedInRowCount_used;
            // if (val > 1.0)
            //     val = 1.0;
            // setChecker("BULLYP_willGiveIn", val);      

            setChecker("BULLYP_payoffs_expected", doExpPayout());

            if (chConformedCurrent[1-me] && (rPayout[me] >= chExpectedPayout))
                updateChecker("BULLYP_givesIn", 1.0, 0.7);
            else
                updateChecker("BULLYP_givesIn", 0.0, 0.7);

        }

        if ((chConformedCurrent[1-me]) && (rPayout[me] >= chExpectedPayout))
            updateChecker("BULLYP_conforms", 1.0, 0.7);
        else if (!chConformedCurrent[1-me])
            updateChecker("BULLYP_conforms", 0.0, 0.3);
    }
    else if (!strcmp(nickname, "bullied")) {
        int rndEvidence = 7;
        int cuentaRec = 0;
        double chPayoffRecentSums[2] = {0.0, 0.0};
        for (int i = chRounds - 1; i >= 0; i--) {
            chPayoffRecentSums[0] += chPayoffHist[i][0];
            chPayoffRecentSums[1] += chPayoffHist[i][1];
            cuentaRec ++;

            if (cuentaRec == rndEvidence)
                break;
        }
        
        // std::cout << "chExpectedPayout: " << chExpectedPayout << std::endl;
        // std::cout << "Ave: " << (chPayoffRecentSums[me] / cuentaRec) << std::endl;
        if ((chPayoffRecentSums[me] / cuentaRec) <= chExpectedPayout)
            updateChecker("BULLIED_other_unfair", 1.0, 0.8);
        else
            updateChecker("BULLIED_other_unfair", 0.0, 0.8);


        if (wasUsed) {
            if (rPayout[me] < chYoShouldGet)
                updateChecker("BULLIED_harmsnot_ifi", 0.0, 0.7);
            else
                updateChecker("BULLIED_harmsnot_ifi", 1.0, 0.8);
            setChecker("BULLIED_payoffs_expected", doExpPayout());
        }
    }
}

void Xprt::getHighLowCheckerPayouts() {
    int jact;
    chHighPayout = -99999;
    chLowPayout = 99999;
    for (int s = 0; s < ab->mg->numStates; s++) {
        for (int n = 0; n < ab->mg->states[s]->numActions[0]; n++) {
            for (int m = 0; m < ab->mg->states[s]->numActions[1]; m++) {
                jact = ab->mg->states[s]->jointCode(n, m);
                if (ab->mg->states[s]->rewards[jact][0][me] < chLowPayout)
                    chLowPayout = ab->mg->states[s]->rewards[jact][0][me];
                if (ab->mg->states[s]->rewards[jact][0][me] > chHighPayout)
                    chHighPayout = ab->mg->states[s]->rewards[jact][0][me];
            }
        }
    }

    // std::cout << "chLowPayout: " << chLowPayout << std::endl;
    // std::cout << "chHighPayout: " << chHighPayout << std::endl;
}

void Xprt::getEgalVals() {
    double mx = -99999, mn;
    int ind = -1;
    for (int i = 0; i < ab->numSolss; i++) {
        if ((ab->sols[i]->payouts[0] <= ab->mg->states[0]->mm[0]->mv) || (ab->sols[i]->payouts[1] <= ab->mg->states[0]->mm[1]->mv))
            continue;
        
        if (ab->sols[i]->payouts[1] < ab->sols[i]->payouts[0])
            mn = ab->sols[i]->payouts[1];
        else
            mn = ab->sols[i]->payouts[0];
        
        if (mn > mx) {
            mx = mn;
            ind = i;
        }
    }

    chEgal[0] = ab->sols[ind]->payouts[0];
    chEgal[1] = ab->sols[ind]->payouts[1];

    mx = -99999;
    ind = -1;
    for (int i = 0; i < ab->numSolss; i++) {
        if ((ab->sols[i]->payouts[0] <= ab->mg->states[0]->mm[0]->mv) || (ab->sols[i]->payouts[1] <= ab->mg->states[0]->mm[1]->mv))
            continue;
        
        double diff = ab->sols[i]->payouts[me] - ab->sols[i]->payouts[1-me];
        if (diff > mx) {
            mx = diff;
            ind = i;
        }
    }

    chBulliedHim[0] = ab->sols[ind]->payouts[0];
    chBulliedHim[1] = ab->sols[ind]->payouts[1];
}

int Xprt::getTheirLow() {
    if (ab->xprts[0]->stratVals[0][1-me] < ab->xprts[0]->stratVals[1][1-me])
        return 0;
    
    return 1;
}

double Xprt::doExpPayout() {
    chUseCount ++;
    double lmbda = 1.0 / chUseCount;
    if (lmbda < 0.2)
        lmbda = 0.2;
    if (lmbda > 0.5)
        lmbda = 0.5;
    chMyAve = chMyAve * (1-lmbda) + rPayout[me] * lmbda;
    double v;
    if ((chExpectedPayout == chMyAve) || (ab->xprts[0]->gotExpectedPayout))
        v = 0.5;
    else if (chExpectedPayout < chMyAve)
        v = 0.5 + (0.5 * (chMyAve - chExpectedPayout)) / (chHighPayout - chExpectedPayout);
    else
        v = 0.5 * (chMyAve - chLowPayout) / (chExpectedPayout - chLowPayout);

    return v;
}