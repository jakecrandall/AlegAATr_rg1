#include "TrainingAssociate.h"

TrainingAssociate::TrainingAssociate() {
    cout << "Incomplete TrainingAssociate constructor" << endl;
    exit(1);
}

TrainingAssociate::TrainingAssociate(int _plyrNum, MarkovGame *_mg) {
    plyrNum = _plyrNum;
    mg = _mg;
    computeMGThings();
    trainee = NULL;

    vector<string> genConfig = readGeneratorConfig();

    // cout << "creating TrainingAssociate generators: " << _mg->states[0] << endl;
    createGenerators(genConfig);

    theGenStart = -1;
    currentGenerator = -1;
    switchProb = 0.0;
    tipo = STATIONARY;
}

TrainingAssociate::~TrainingAssociate() {
    for (int i = 0; i < generators.size(); i++) {
        delete generators[i];
    }
}

void TrainingAssociate::configureTrainingRun(string _genStart, double _switchProb, int _tipo, AbstractAlegAATr *_trainee) {
    switchProb = _switchProb;
    tipo = _tipo;
    trainee = _trainee;
    prevTraineeGen = curTraineeGen = -1;
    lastTraineeGenChange = lastSelfGenChange = 0;

    // cout << plyrNum << " is " << tipo << endl;

    for (int i = 0; i < generators.size(); i++) {
        if (generators[i]->nickname == _genStart)
           theGenStart = i;
    }

    if (theGenStart == -1) {
        cout << "tenemos un problema: <" << theGenStart << ">" << endl;
        exit(1);
    }

    currentGenerator = theGenStart;
    t = 0;

    // reset the generators
    for (int i = 0; i < generators.size(); i++)
        generators[i]->restoreFactorySettings();
}

void TrainingAssociate::setGenVsGen(double _genM[10][10][2], int _numRounds) {
    numRounds = _numRounds;

    // compute attacked value
    myAttackedVal = mg->states[0]->mm[plyrNum]->mv * numRounds;

    // save outcome and set myCFRVal
    myCFRVal = myAttackedVal;
    hisCFRVal = mg->states[0]->mm[1-plyrNum]->mv * numRounds;
    for (int i = 0; i < generators.size(); i++) {
        for (int j = 0; j < generators.size(); j++) {
            genM[i][j][0] = _genM[i][j][0];
            genM[i][j][1] = _genM[i][j][1];

            if (!strcmp(generators[i]->nickname, "cfr") && !strcmp(generators[j]->nickname, "cfr")) {
                myCFRVal = genM[i][j][plyrNum];
                hisCFRVal = genM[i][j][1-plyrNum];
            }
        }
    }

    // cout << "myCFRVal: " << myCFRVal << endl;
    // cout << "hisCFRVal: " << hisCFRVal << endl;

    // compute stackelberg value
    int mxInd = -1, br;
    double mxVal[2] = {-99999, -99999};
    for (int i = 0; i < generators.size(); i++) {
        br = getBestResponse(1-plyrNum, i);
        if (plyrNum == 1) {
            if (genM[i][br][1-plyrNum] > mxVal[1-plyrNum]) {
                mxInd = i;
                mxVal[0] = genM[i][br][0];
                mxVal[1] = genM[i][br][1];
            }
        }
        else {
            if (genM[br][i][1-plyrNum] > mxVal[1-plyrNum]) {
                mxInd = i;
                mxVal[0] = genM[br][i][0];
                mxVal[1] = genM[br][i][1];
            }
        }
    }

    // cout << "Stackelberg value: " << mxVal[0] << ", " << mxVal[1] << endl;
    myStackelberguedVal = mxVal[plyrNum];
    // cout << "myStackelberguedVal: " << myStackelberguedVal << endl;
}

// determine the best response to quien's behavior (action a)
int TrainingAssociate::getBestResponse(int quien, int a) {
    int mxInd = -1;
    double mxVal = -99999;
    if (quien == 0) {
        for (int i = 0; i < generators.size(); i++) {
            if (genM[a][i][1-quien] > mxVal) {
                mxInd = i;
                mxVal = genM[a][i][1-quien];
            }
        }
    }
    else {
        for (int i = 0; i < generators.size(); i++) {
            if (genM[i][a][1-quien] > mxVal) {
                mxInd = i;
                mxVal = genM[i][a][1-quien];
            }
        }
    }

    return mxInd;
}

int TrainingAssociate::makeMove(State *s) {
    if (curTraineeGen == -1) {
        // if (tipo != STATIONARY) {
        //     cout << "\ntrainee starting with generator " << trainee->currentGenerator << endl;
        //     cout << "associate starting with generator " << currentGenerator << endl;
        // }
        curTraineeGen = trainee->currentGenerator;
        lastTraineeGenChange = t;
    }
    else if (curTraineeGen != trainee->currentGenerator) {
        // cout << "trainee changed generators from " << curTraineeGen << " to " << trainee->currentGenerator << endl;
        prevTraineeGen = curTraineeGen;
        curTraineeGen = trainee->currentGenerator;
        lastTraineeGenChange = t;
    }

    // cout << "TrainingAssociate to make move: " << generators[currentGenerator]->nickname << endl;
    // cout << "   " << s << endl;

    vector<int> theMoves;
    for (int i = 0; i < generators.size(); i++) {
        theMoves.push_back(generators[i]->Move(s));
    }

    return theMoves[currentGenerator];
}

void TrainingAssociate::updateAfterMove(State *s, int actions[2]) {
    for (int i = 0; i < generators.size(); i++) {
        generators[i]->moveUpdate(s, actions);
    }
}

void TrainingAssociate::updateRound() {
    for (int i = 0; i < generators.size(); i++) {
        if (i == currentGenerator)
            generators[i]->roundUpdate(true);
        else
            generators[i]->roundUpdate(false);
    }

    // with probability switchProb, change to another generator based on tipo
    if (withProb(switchProb)) {
        // cout << "could change" << endl;
        int was = currentGenerator;
        currentGenerator = switchGenerator(curTraineeGen);

        if ((currentGenerator != was) && strncmp(generators[currentGenerator]->nickname, "cfr", 3)) {
            ((Xprt *)generators[currentGenerator])->ab->xprts[0]->guilt = 0.0;
            ((Xprt *)generators[currentGenerator])->ab->xprts[0]->betrayed = false;
        }
        // if (currentGenerator != was) {
        //     cout << "changed from " << was << " to " << currentGenerator << endl;
        // }
    }

    t++;
}

// pick the best generator given alegaatr's assumed reaction
int TrainingAssociate::switchGenerator(int alegaatr) {
    int trainingassociate = currentGenerator;
    double currentVals[2];
    if (plyrNum == 0) {
        currentVals[0] = genM[trainingassociate][alegaatr][0];
        currentVals[1] = genM[trainingassociate][alegaatr][1];
    }
    else {
        currentVals[0] = genM[alegaatr][trainingassociate][0];
        currentVals[1] = genM[alegaatr][trainingassociate][1];
    }

    // cout << "  currently set to get " << currentVals[0] << ", " << currentVals[1] << endl;

    double mxVal = currentVals[plyrNum];
    int mxInd = trainingassociate;
    if (tipo == STATIONARY) {
        // cout << "  STATIONARY" << endl;
        for (int i = 0; i < generators.size(); i++) {
            if (i == trainingassociate)
                continue;

            if (plyrNum == 1) {
                if (genM[alegaatr][i][plyrNum] > mxVal) {   // if it helps the associate
                    mxVal = genM[alegaatr][i][plyrNum];
                    mxInd = i;
                }
            }
            else {
                if (genM[i][alegaatr][plyrNum] > mxVal) {   // if it helps the associate
                    mxVal = genM[i][alegaatr][plyrNum];
                    mxInd = i;
                }
            }
        }
    }
    else if (tipo == COURNOT) {
        for (int i = 0; i < generators.size(); i++) {
            int br = getBestResponse(plyrNum, i);
            if (plyrNum == 1) {
                if (genM[br][i][plyrNum] > mxVal) {
                    mxVal = genM[br][i][plyrNum];
                    mxInd = i;
                }
            }
            else {
                if (genM[i][br][plyrNum] > mxVal) {
                    mxVal = genM[i][br][plyrNum];
                    mxInd = i;
                }
            }
        }
    }
    else if (tipo == FAIR) {
        double val;
        mxVal = -99999;
        mxInd = -1;
        for (int i = 0; i < generators.size(); i++) {
            if (plyrNum == 1) {
                val = genM[alegaatr][i][plyrNum];
                if (genM[alegaatr][i][1-plyrNum] < hisCFRVal)
                    val = 0.95 * myCFRVal + 0.05 * genM[alegaatr][i][plyrNum];

                if (val > mxVal) {
                    mxVal = val;
                    mxInd = i;
                }
            }
            else {
                val = genM[i][alegaatr][plyrNum];
                if (genM[i][alegaatr][1-plyrNum] < myCFRVal)
                    val = 0.95 * myCFRVal + 0.05 * genM[i][alegaatr][plyrNum];

                if (val > mxVal) {
                    mxVal = val;
                    mxInd = i;
                }
            }
        }
    }
    else if (tipo == STACKELBERG) {
        for (int i = 0; i < generators.size(); i++) {
            if (i == trainingassociate)
                continue;

            if (plyrNum == 1) {
                if (genM[alegaatr][i][plyrNum] > mxVal) {   // if it potentially helps the associate
                    if (genM[alegaatr][i][1-plyrNum] < currentVals[1-plyrNum]) {  // if it hurts aleegatr
                        if (myStackelberguedVal > mxVal) {
                            mxVal = myStackelberguedVal;
                            mxInd = i;
                        }
                    }
                    else {
                        mxVal = genM[alegaatr][i][plyrNum];
                        mxInd = i;
                    }
                }
            }
            else {
                if (genM[i][alegaatr][plyrNum] > mxVal) {   // if it potentially helps the associate
                    if (genM[i][alegaatr][1-plyrNum] < currentVals[1-plyrNum]) {  // if it hurts aleegatr
                        if (myStackelberguedVal > mxVal) {
                            mxVal = myStackelberguedVal;
                            mxInd = i;
                        }
                    }
                    else {
                        mxVal = genM[i][alegaatr][plyrNum];
                        mxInd = i;
                    }
                }
            }
        }
    }
    else {
        cout << "unknown tipo: " << tipo << endl;
        exit(1);
    }

    // cout << "  Picked generator " << mxInd << " for " << mxVal << endl;

    return mxInd;
}

// void TrainingAssociate::createGenerators(vector<string> genConfig) {
//     char tipito[1024];

//     for (int i = 0; i < genConfig.size(); i++) {
//         cout << "Generator: " << genConfig[i] << endl;
//         if (genConfig[i] == "cfr") {
//             generators.push_back(new CFR(plyrNum, mg, 40, false));
//         }
//         else if (genConfig[i] == "maxmin") {
//             strcpy(tipito, "maxmin");
//             generators.push_back(new Xprt(plyrNum, mg, tipito));
//         }
//         else if (genConfig[i] == "coop") {
//             strcpy(tipito, "coop");
//             generators.push_back(new Xprt(plyrNum, mg, tipito));
//         }
//         else if (genConfig[i] == "coopp") {
//             strcpy(tipito, "coopp");
//             generators.push_back(new Xprt(plyrNum, mg, tipito));
//         }
//         else if (genConfig[i] == "bullyp") {
//             strcpy(tipito, "bullyp");
//             generators.push_back(new Xprt(plyrNum, mg, tipito));
//         }
//         else if (genConfig[i] == "bullied") {
//             strcpy(tipito, "bullied");
//             generators.push_back(new Xprt(plyrNum, mg, tipito));
//         }
//         else {
//             cout << "generator " << genConfig[i] << " not found" << endl;
//         }
//     }
// }

// vector<string> TrainingAssociate::readGeneratorConfig() {
//     vector<string> genConfig;

//     ifstream input("allGens.txt");

//     string line;
//     while (!input.eof()) {
//         getline(input, line);
//         if (line.length() > 1)
//             genConfig.push_back(line);
//         else
//             break;

//     }

//     input.close();

//     return genConfig;
// }


