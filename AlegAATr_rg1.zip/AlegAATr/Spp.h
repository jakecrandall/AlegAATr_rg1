#ifndef SPP_H
#define SPP_H

#include "defs.h"
#include "AbstractAlegAATr.h"
#include "MarkovGame.h"
#include "State.h"
#include "CFR.h"
#include "Xprt.h"

using namespace std;

class Spp : public AbstractAlegAATr {
public:
    Spp();
    Spp(int _plyrNum, MarkovGame *_mg);
    ~Spp();

    int makeMove(State *s);
    void updateAfterMove(State *s, int actions[2]);
    void updateRound();

    void selectTheGenerator();
    int determineOutcome(double roundPayouts[2]);
    bool brBest();
    bool cycled(int outcome);
    void setAspirationLevel(string genStr);

private:
    int t;
    State *lastState;

    double aspiration, lambda;
    double roundPayouts[2], totalPayouts[2], cyclePayout, rho;
    int cycleCount, brIndex, mmIndex;
    set<int> outcomeHistory;
    double nbsVal[2];

    vector<double> xphi;
    vector<int> kappa;
};

#endif