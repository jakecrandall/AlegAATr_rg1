#include "Expert.h"

//extern void addMessage(char msg[1024], int _origin, int _lineHeight);

Expert::Expert() {
    printf("incomplete Expert constructor\n");
    exit(1);
}

Expert::Expert(int _tipo, int _strat1, int _strat2, int _cycleLen, double _lambda, bool _explorar, double _deltaMax, MarkovGame *_mg, int _me) {
    tipo = _tipo;
    strat[0] = _strat1;
    strat[1] = _strat2;
    stratVals[0][0] = stratVals[0][1] = -99999;
    stratVals[1][0] = stratVals[1][1] = -99999;
    deltaMax = _deltaMax;
    canSwitch = true;
    
    currentStep = -1;
    
    // printf("Expert of type %i: %i %i\n", tipo, strat[0], strat[1]);
    
    guilt = 0.0;
    usage = 0;
    barR[0] = barR[1] = 0.0;
    
    cycleLen = _cycleLen;
    
    lambda = _lambda;
    
    culpable = false;
    explorar = _explorar;
    
    // if (tipo == PREVENT) {
    //     // preventer = new Preventer(_me, _mg, 0.5, false);
    //     std::cout << "We ain't doing preventers" << std::endl;
    // }
    
    // currentMessage = -1;
    
    if (tipo == MINIMAX) {
        description[0] = 32;
        descriptionLen = 1;
    }
    else if (tipo == BResp) {
        description[0] = 31;
        descriptionLen = 1;
    }
    else {
        description[0] = 1;
        descriptionLen = 1;
    }
    
    describeExpert = false;

    for (int i = 0; i < MAX_QSETS; i++)
        followedCount[i] = 0;

    lastResultObtained = -1;
    lastResultObtainedTime = -99999;
    justConformed = false;
    payoffSum[0] = payoffSum[1] = 0.0;
    t = 0;
}


Expert::Expert(int _tipo, int _strat1, int _strat2, double _P1[2], double _P2[2], double _deltaMax, int _cycleLen, double _lambda, int _me, bool _canSwitch) {
    canSwitch = _canSwitch;
    if (!canSwitch) {
        std::cout << "this expert can't switch" << std::endl;
    }
    tipo = _tipo;
    strat[0] = _strat1;
    strat[1] = _strat2;
    stratVals[0][0] = _P1[0];    stratVals[0][1] = _P1[1];
    stratVals[1][0] = _P2[0];    stratVals[1][1] = _P2[1];
    deltaMax = _deltaMax;
    barR[0] = (stratVals[0][0] + stratVals[1][0]) / 2.0;
    barR[1] = (stratVals[0][1] + stratVals[1][1]) / 2.0;
    
    currentStep = -1;
    
    // printf("Expert of type %i: %i %i designed to produce (%.2lf, %.2lf)\n", tipo, strat[0], strat[1], barR[0], barR[1]);
    
    guilt = 0.0;
    usage = 0;
    
    cycleLen = _cycleLen;
    
    lambda = _lambda;
    
    culpable = false;
    
    explorar = false;
    
    //strcpy(currentMessage, "");
    // currentMessage = -1;
    
    if ((tipo == LEADER) || (tipo == LEADER2)) {
        if (fabs(barR[0] - barR[1]) < deltaMax) {
            description[0] = 2;
            descriptionLen = 1;
            //strcpy(description, "Here's the deal:  Let's cooperate with each other.|");
            if ((fabs(stratVals[0][0] - stratVals[1][0]) > deltaMax) || (fabs(stratVals[0][1] - stratVals[1][1]) > deltaMax)) {
                description[1] = 3;
                descriptionLen++;
                //strcat(description, "We can do this by taking turns receiving|the higher payout.|");
            }
            description[descriptionLen] = 4;
            descriptionLen++;
            //strcat(description, "If you don't do your part, I'll make you pay.|");
        }
        else {
            if ((fabs(stratVals[0][0] - stratVals[1][0]) > deltaMax) || (fabs(stratVals[0][1] - stratVals[1][1]) > deltaMax)) {
                //strcpy(description, "Let's take turns.|");
                description[0] = 5;
                descriptionLen = 1;
            }
            else {
                //sprintf(description, "Let me have %.0lf points each round.|", stratVals[0][_me]);
                description[0] = 6;
                descriptionLen = 1;
            }
            if (tipo == LEADER) {
                //strcat(description, "Otherwise, I'll make you pay in future rounds.|");
                description[descriptionLen] = 7;
                descriptionLen++;
            }
            else if (tipo == LEADER2) {
                //strcat(description, "Otherwise, I'll make you pay in future moves.|");
                description[descriptionLen] = 8;
                descriptionLen++;
            }
        }
    }
    else {
        if (fabs(barR[0] - barR[1]) < deltaMax) {
            //sprintf(description, "Let's cooperative with each other.|");
            description[0] = 9;
            descriptionLen = 1;
            if ((fabs(stratVals[0][0] - stratVals[1][0]) > deltaMax) || (fabs(stratVals[0][1] - stratVals[1][1]) > deltaMax)) {
                //strcat(description, "We can do this by taking turns receiving|the higher payout.|");
                description[1] = 3;
                descriptionLen = 2;
            }
        }
        else {
            if ((fabs(stratVals[0][0] - stratVals[1][0]) > deltaMax) || (fabs(stratVals[0][1] - stratVals[1][1]) > deltaMax)) {
                description[0] = 5;
                descriptionLen = 1;
            }
            else {
                description[0] = 6;
                descriptionLen = 1;
            }
        }
    }
    
    describeExpert = false;

    for (int i = 0; i < MAX_QSETS; i++)
        followedCount[i] = 0;

    lastResultObtained = -1;
    lastResultObtainedTime = -99999;
    justConformed = false;
    payoffSum[0] = payoffSum[1] = 0.0;
    t = 0;
}

Expert::~Expert() {
    // if (tipo == PREVENT)
    //     delete preventer;
}

int Expert::Move(State *s, double previousPayoffs[2], int _me) {
    lastState = s;

    if (tipo == MINIMAX) {
        // std::cout << _me << ": tipo is minimax" << std::endl;
        return generateAction(s->mm[_me]->ms, s->numActions[_me]);
    }

    // if (_me == 1) {
    //     std::cout << _me << ": barR: " << barR[0] << ", " << barR[1] << "; guilt: " << guilt << std::endl;
    // }
    // std::cout << _me << ": tipo is NOT minimax" << std::endl;

    if (tipo == BResp) {
        int i, j;

        int bInd = 0;
        for (i = 1; i < s->numActions[_me]; i++) {
            if (s->Qbr[i] > s->Qbr[bInd])
                bInd = i;
            else if ((s->Qbr[i] == s->Qbr[bInd]) && (rand() % 2))
                bInd = i;
        }

        if (explorar) {
            // add random exploration
            double num = rand() / (double)RAND_MAX;
            double sum = 0.0;
            for (i = 0; i < s->numActions[0]; i++) {
                for (j = 0; j < s->numActions[1]; j++) {
                    sum += s->cuentas[i][j];
                }
            }
            double xplor = 1.0 / (10.0 + sum/10.0);
            if (xplor < 0.05)
                xplor = 0.05;
            if (num <= xplor) {
                bInd = rand() % s->numActions[_me];
            }
        }
        
        return bInd;
    }
    else if (tipo == FOLLOWER) {
        if (currentStep < 0) {
            getCurrentStep(previousPayoffs, _me, false);
        }

        int highInd = 0;
        if ((s->numActions[0] == 1) || (s->numActions[1] == 1)) {   // blockDilemma under my assumptions
            // if (_me == 1)
            //     std::cout << "followedCount (" << strat[0] << "-" << strat[1] << "): ";
            for (int i = 1; i < s->numQsets; i++) {
                // if (_me == 1)
                //     std::cout << followedCount[i] << " ";
                if (followedCount[i] > followedCount[highInd])
                    highInd = i;
                else if (followedCount[i] == followedCount[highInd]) {
                    if (i == strat[currentStep])
                        highInd = i;
                    else if ((highInd != strat[currentStep]) && (i == strat[1-currentStep]))
                        highInd = i;
                    else if ((highInd != strat[currentStep]) && (highInd != strat[1-currentStep]) && (rand() % 2))
                        highInd = i;
                }
            }

            // if (_me == 1) {
            //     std::cout << "  Likely to take action: " << s->qsets[highInd]->correctA(1-_me) << std::endl;
            //     std::cout << std::endl;
            // }
            // if ((strat[0] == 0) && (strat[1] == 6)) {
            //     std::cout << "highInd: " << highInd << std::endl;
            //     std::cout << "currentStep: " << currentStep << std::endl;
            //     std::cout << "strats: " << strat[0] << " " << strat[1] << std::endl;
            if (highInd == strat[1-currentStep]) {
                // std::cout << "  ****************** maybe I should play the other part" << std::endl;
                // std::cout << "            " << stratVals[1-currentStep][0] << ", " << stratVals[1-currentStep][1] << std::endl;
                // std::cout << "       instead of " << stratVals[currentStep][0] << ", " << stratVals[currentStep][1] << std::endl;
                if (stratVals[1-currentStep][_me] > stratVals[currentStep][_me]) {
                    // std::cout << "he's doing the other thing and it is better for me, so switch" << std::endl;
                    currentStep = 1-currentStep;
                }
                else if (randomSwitch(t - lastResultObtainedTime)) {
                    currentStep = 1-currentStep;
                }
            }
        }
        else {
            highInd = strat[currentStep];
        }
        
        // std::cout << "\nFollowing " << highInd << " vs " << strat[currentStep] << std::endl;
        // std::cout << "tipo: " << tipo << std::endl;
        // std::cout << "barR: " << barR[0] << ", " << barR[1] << std::endl;

        int aprime = -1;
        double mx = -99999;
        // if (_me == 0)
        //     std::cout << "vals: " << std::endl;
        for (int i = 0; i < s->numActions[_me]; i++) {
            // std::cout << "  Outcome " << i << ": " << simulate2End(s, _me, i, strat[currentStep], highInd) << std::endl;
            double val = simulate2End(s, _me, i, strat[currentStep], highInd);
            reflectiveActionValues[i] = val;

            double val2 = simulate2End(s, _me, i, strat[1-currentStep], highInd);
            reflectiveActionValuesOther[i] = val2;

            if ((i == s->qsets[highInd]->correctA(_me)) && (s->qsets[strat[currentStep]]->correctM(_me) != s->qsets[highInd]->correctM(_me))) {
                // std::cout << "drop down" << std::endl;
                val -= 0.01;
            }

            // if (_me == 0)
            //     std::cout << "  " << val << std::endl;
            // if ((val > mx) || ((val == mx) && (rand() % 2))) {
            if (val > mx) {
                aprime = i;
                mx = val;
            }
        }
        // if (_me == 0)
        //     std::cout << std::endl;
        // if (currentStep < 0) {
        //     //printf("move current step called\n");
        //     getCurrentStep(previousPayoffs, _me, false);
        // }
        
        // double probs[2*NUMACTIONS];
        // s->getProbs_regular(probs, _me);
        // return s->qsets[strat[currentStep]]->highestAction(_me, probs);

        // if (_me == 0)
        //     std::cout << "chose action: " << aprime << std::endl << std::endl;

        return aprime;
    }
    else if (tipo == LEADER) {
        if (guilt > 0.00001) {// if guilt, punish him
            // std::cout << "guilty1: " << guilt << std::endl;
            return generateAction(s->attack[_me]->ms, s->numActions[_me]);
        }
        
        if (currentStep < 0) {
            //printf("move current step called\n");
            getCurrentStep(previousPayoffs, _me, false);
        }

        double probs[2*NUMACTIONS];
        s->getProbs_regular(probs, _me);
        int a = s->qsets[strat[currentStep]]->highestAction(_me, probs);
        //printf("%i: picked %i\n", _me, a); fflush(stdout);
        
        return a;
        // return aprime;
    }
    else if (tipo == LEADER2) {
        // printf("@%.1lf@", guilt);
        // if (_me == 1)
        //     printf("s->ID: %i\n", s->ID);
        
        if ((guilt > 0.00001) || betrayed) {// if guilt, punish him
            // if (_me == 1)
            //     std::cout << "guilty2: " << guilt << std::endl;
            return generateAction(s->attack[_me]->ms, s->numActions[_me]);
        }
        // if (_me == 1)
        //     std::cout << "not guilty" << std::endl;
        
        if (currentStep < 0) {
            // if (_me == 1)
            //     printf("move current step called\n");
            getCurrentStep(previousPayoffs, _me, false);
        }

        // if (_me == 1)
        //     printf("currentStep: %i\n", currentStep);

        double probs[2*NUMACTIONS];
        s->getProbs_regular(probs, _me);
        int a = s->qsets[strat[currentStep]]->highestAction2(_me, probs, reflectiveActionValues);
        
        return a;
        // return aprime;
    }
    
    return 0;
}

double Expert::simulate2End(State *s, int me, int aprime, int qset_me, int qset_notme_est) {
    double rs[2] = {0.0, 0.0};
    int a, b, jact;

    // std::cout << " Actions: " << std::endl;
    b = s->qsets[qset_notme_est]->correctA(1-me);
    if (me == 0)
        jact = s->jointCode(aprime, b);
    else
        jact = s->jointCode(b, aprime);
    rs[0] += s->rewards[jact][0][0];
    rs[1] += s->rewards[jact][0][1];
    // std::cout << "   " << aprime << ", " << b << " -> " << rs[0] << ", " << rs[1] << std::endl;
    State *sprime = s->nextState[jact][0];
    while ((sprime->numActions[0] > 3) || (sprime->numActions[1] > 3)) { // finds goals states in the block dilemma
        a = sprime->qsets[qset_me]->correctA(me);
        b = sprime->qsets[qset_notme_est]->correctA(1-me);
        if (me == 0)
            jact = sprime->jointCode(a, b);
        else
            jact = sprime->jointCode(b, a);
        rs[0] += sprime->rewards[jact][0][0];
        rs[1] += sprime->rewards[jact][0][1];
        // std::cout << "   " << a << ", " << b << " -> " << rs[0] << ", " << rs[1] << std::endl;
        sprime = sprime->nextState[jact][0];
    }

    // if (me == 1)
    //     std::cout << rs[0] << ", " << rs[1] << " with " << s->qsets[qset_me]->w << std::endl;
    return s->qsets[qset_me]->w * rs[0] + (1-s->qsets[qset_me]->w) * rs[1];
}

int Expert::generateAction(double *v, int numActs) {
    int i;

    // printf("minimax: ");
    // for (i = 0; i < numActs; i++)
    //     printf("%lf ", v[i]);
    // printf("\n");
    
    double num = rand() / (double)RAND_MAX;
    double sum = 0.0;
    for (i = 0; i < numActs; i++) {
        sum += v[i];
        if (num <= sum)
            return i;
    }
    
    printStrategy(v, numActs);
    
    printf("Expert: generate action failed: %lf\n", num);
    
    return numActs-1;
}

void Expert::printStrategy(double *v, int numActs) {
    int i;
    
    for (i = 0; i < numActs; i++) {
        printf("%.2lf ", v[i]); fflush(stdout);
    }
    printf("\n");
}

void Expert::Update(double dollars[2], int _me, double _aspiration, bool _heldTrue, double aspiration) {
    updateLastResultObtained(dollars, _me);

    describeExpert = false;
    
    // update observed performance
    usage++;
    double betita = 1.0 / usage;
    double lambda = 0.9;
    if (betita <= (2.0 * (1.0 - lambda)))
        betita = 2.0 * (1.0 - lambda);
    if (betita > 0.1)
        betita = 0.1;
    vu = betita * dollars[_me] + (1.0 - betita) * vu;
    
    if (tipo == FOLLOWER) {        
        getCurrentStep(dollars, _me, _heldTrue);
    }
    
    if ((tipo == LEADER) || (tipo == LEADER2)) {
        double epsilon = 0.01;

        double diff = stratVals[currentStep][_me] - dollars[_me];
        if (diff < 0)
            diff = 0.0;
        double value = (dollars[_me] + (stratVals[1-currentStep][_me] - diff)) / 2.0;
        if ((guilt < 0.00001) && _heldTrue) {
            guilt = 0.0;
        }
        else if ((guilt < 0.00001) && (value >= aspiration)) {
            guilt = 0.0;
        }
        else {
            double delta = 0.0;
            bool starting = false;
            double vexpected = stratVals[currentStep][1-_me];
            double guiltUp = guilt + dollars[1-_me] - vexpected + deltaMax;
            if (guilt < 0.00001) {
                if (guiltUp > 0) {
                    starting = true;
                    delta = deltaMax;
                }
                else {
                }
            }
            else {
            }
            guilt += dollars[1-_me] - vexpected + delta;
            // if (_me == 1)
            //     std::cout << "guilt here: " << guilt << std::endl;
            
            if (guilt < 0.000001) {
                if (!starting) {
                    describeExpert = true;
                }
                else if (tipo != LEADER2) {
                }
                guilt = 0.0;
            }
        }
        
        if (guilt < 0.00001)
            getCurrentStep(dollars, _me, _heldTrue);
    }
    
    betrayed = false;
    favored = false;

    for (int i = 0; i < MAX_QSETS; i++)
        followedCount[i] = 0;
}

void Expert::updateMove(State *sprime, double rPayout[2], int me, int acts[2], double aspiration) {
    // count which qsets suggested acts[1-me]
    for (int i = 0; i < lastState->numQsets; i++) {
        if ((lastState->qsets[i]->correctA(1 - me) == acts[1-me]) || (lastState->qsets[i]->maxVal() == lastState->qsets[i]->Qs[acts[0]][acts[1]])) {
            followedCount[i] ++;
        }
    }

    if ((tipo == FOLLOWER) || ((tipo == LEADER) && (guilt < 0.00001))) {
        double gettin = rPayout[me] + sprime->qsets[strat[currentStep]]->correctM(me);
        double shoulda = stratVals[currentStep][me];
        // if (me == 1)
        //     std::cout << "     Update follower: " << std::endl;

        double diff = stratVals[currentStep][me] - gettin;
        if (diff < 0)
            diff = 0.0;
        double value = (gettin + (stratVals[1-currentStep][me] - diff)) / 2.0;
        
        if ((((gettin+0.00001) < shoulda) && (value < aspiration)) && !betrayed) {
            betrayed = true;
        }
        else if (((gettin - 0.1) > shoulda) && !favored) {
            favored = true;
        }
    }
    else if ((tipo == LEADER2) && (guilt < 0.00001)) {
        //printf("t"); fflush(stdout);        
        double gettin = rPayout[me] + sprime->qsets[strat[currentStep]]->correctM(me);
        double shoulda = stratVals[currentStep][me];
        // if (me == 1) {
        //     std::cout << "     Update leader; should = " << shoulda << "; getting = " << gettin << std::endl;
        // }

        //printf("&%.0lf,%.0lf&", gettin, shoulda); fflush(stdout);
        
        double diff = stratVals[currentStep][me] - gettin;
        if (diff < 0)
            diff = 0.0;
        double value = (gettin + (stratVals[1-currentStep][me] - diff)) / 2.0;

        if ((((gettin+0.00001) < shoulda) && (value < aspiration)) && !betrayed) {
            double gettin2 = rPayout[1-me] + sprime->qsets[strat[currentStep]]->correctM(1-me);
            double shoulda2 = stratVals[currentStep][1-me];
            
            if (shoulda2 < (gettin2+deltaMax)) {
                // std::cout << "          betrayed" << std::endl;
                betrayed = true;
            }
        }
        else if (betrayed) {
            double gettin2;
            if (me == 0)
                gettin2 = rPayout[1-me] + sprime->qsets[0]->correctM(1-me);
            else
                gettin2 = rPayout[1-me] + sprime->qsets[sprime->numQsets-1]->correctM(1-me);
            
            double shoulda2 = stratVals[currentStep][1-me];
            if (gettin2 < (shoulda2 - deltaMax)) {
                betrayed = false;
            }
        }
    }
    else if ((tipo == LEADER2) && (guilt > 0.00001)) {
        double gettin2;
        if (me == 0)
            gettin2 = rPayout[1-me] + sprime->qsets[0]->correctM(1-me);
        else
            gettin2 = rPayout[1-me] + sprime->qsets[sprime->numQsets-1]->correctM(1-me);
        
        double shoulda2 = stratVals[currentStep][1-me];
    }
}

void Expert::reset(double previousPayoffs[2], int _me) {
    guilt = 0.0;
    culpable = false;
    betrayed = false;
    favored = false;
    
    currentStep = rand() % 2;
    // getCurrentStep(previousPayoffs, _me, false);

    for (int i = 0; i < MAX_QSETS; i++)
        followedCount[i] = 0;
}

void Expert::getCurrentStep(double previousPayoffs[2], int _me, bool _heldTrue) {
    double epsilon = 3.0;
    int i;

    // std::cout << "Considering: " << barR[0] << ", " << barR[1] << std::endl;
    
    if ((justConformed) && (lastResultObtained == currentStep)) {
        currentStep = 1-currentStep;
        // std::cout << ">>>>>>>>>>>>>>> held true update" << std::endl;
        return;
    }

    // std::cout << "  Considering: " << barR[0] << ", " << barR[1] << std::endl;
    
    currentStep = -1;
    for (i = 0; i < 2; i++) {
        if (highPayoffAchieved(previousPayoffs, stratVals[i], epsilon)) {
            // std::cout << ">>>>>>>>>>>>>>> high payoff achieved update" << std::endl;
            currentStep = 1-i;
            return;
        }
    }

    // std::cout << "    Considering: " << barR[0] << ", " << barR[1] << std::endl;

    if (lastResultObtained >= 0) {
        // if ((rand() % 2) == 0)
        currentStep = 1-lastResultObtained;
        // std::cout << "******updating currentStep with 1-lastResultObtained: " << currentStep << " (" << stratVals[currentStep][0] << ", " << stratVals[currentStep][1] << ")" << std::endl;
        // std::cout << "         " << currentStep << " (" << stratVals[0][0] << ", " << stratVals[0][1] << ")" << " -- (" << stratVals[1][0] << ", " << stratVals[1][1] << ")"<< std::endl;

        return;
    }
    else if (t > 0) {
        // see which point we're closer too
        double p[2];
        p[0] = payoffSum[0] / t;
        p[1] = payoffSum[1] / t;

        double dist0 = ((p[0] - stratVals[0][0]) * (p[0] - stratVals[0][0])) + ((p[1] - stratVals[0][1]) * (p[0] - stratVals[0][1]));
        double dist1 = ((p[0] - stratVals[1][0]) * (p[0] - stratVals[1][0])) + ((p[1] - stratVals[1][1]) * (p[0] - stratVals[1][1]));

        // std::cout << "      Considering ... " << std::endl;

        if (!randomSwitch(t - lastResultObtainedTime)) {
            if (dist0 < dist1) {
                currentStep = 1;
                return;
            }
            else if (dist1 < dist0) {
                currentStep = 0;
                return;
            }
        }
    }

    // std::cout << "        Picking randomly: " << barR[0] << ", " << barR[1] << std::endl;

    currentStep = rand() % 2;

    // std::cout << "          " << currentStep << std::endl;
}

void Expert::updateLastResultObtained(double dollars[2], int _me) {
    if ((dollars[0] == stratVals[0][0]) && (dollars[1] == stratVals[0][1])) {
        lastResultObtained = 0;
        lastResultObtainedTime = t;
        justConformed = true;
    }
    else if ((dollars[0] == stratVals[1][0]) && (dollars[1] == stratVals[1][1])) {
        lastResultObtained = 1;
        lastResultObtainedTime = t;
        justConformed = true;
    }
    else if (dollars[_me] == stratVals[0][_me]) {
        lastResultObtained = 0;
        lastResultObtainedTime = t;
        justConformed = true;
    }
    else if (dollars[_me] == stratVals[1][_me]) {
        lastResultObtained = 1;
        lastResultObtainedTime = t;
        justConformed = true;
    }
    else {
        justConformed = false;
    }

    if ((justConformed) && (lastResultObtained == currentStep))
        gotExpectedPayout = true;
    else
        gotExpectedPayout = false;

    // std::cout << "lastResultObtained: " << lastResultObtained << " (" << stratVals[lastResultObtained][_me] << ")" << std::endl;

    payoffSum[0] += dollars[0];
    payoffSum[1] += dollars[1];
    t++;
}

bool Expert::randomSwitch(int _timeElapsed) {
    if (!canSwitch)
        return false;

    double probStay = 1 - (_timeElapsed / 10.0);
    if (probStay < 0.3)
        probStay = 0.3;

    double num = rand() / (double)RAND_MAX;
    if (num > probStay)
        return true;

    return false;
}

bool Expert::highPayoffAchieved(double previous[2], double pattern[2], double epsilon) {
    int high = 0;
    if (pattern[1] > pattern[0])
        high = 1;
    
    if ((previous[high] <= (pattern[high] + epsilon)) && (previous[high] >= (pattern[high] - epsilon)))
        return true;
    
    return false;
}

// I need to add to this; if he isn't playing according to the plan, but I had guilt, then he could be teaching me
bool Expert::showedLeadership(int hacts[20], double payoffHistory[2][10], int _me) {
    //return true;
    
    //printf("<%i, %i: %i and %i> ", strat[0], strat[1], hacts[strat[0]+2], hacts[strat[1]+2]);
    if ((hacts[strat[0]+2] == 1) || (hacts[strat[1]+2] == 1))
        return true;

    // check if i had guilt (in the last 1, 2, or 3 rounds, I did better than I should have); if so, set to true
    //printf("<p2 = %.2lf; p1 = %.2lf>", payoffHistory[_me][1] + payoffHistory[_me][2], payoffHistory[_me][1]);
    if (((payoffHistory[_me][1] + payoffHistory[_me][2]) > (2 * (barR[_me] - deltaMax))) || (payoffHistory[_me][1] > (barR[_me] - deltaMax))) {
        // i did better than I should have; he could have decided to punish me
        return true;
    }
/*
    // maybe we are just eating up each other
    if (((payoffHistory[1-_me][1] + payoffHistory[1-_me][2]) > (2 * (barR[1-_me] - deltaMax))) || (payoffHistory[1-_me][1] > (barR[1-_me] - deltaMax))) {
        // i did better than I should have; he could have decided to punish me
        return true;
    }
*/    
    
    return false;
}
