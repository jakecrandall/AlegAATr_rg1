#include "defs.h"
#include "MarkovGame.h"
#include "State.h"
#include "AbstractAlegAATr.h"
#include "AlegAATr.h"
#include "TrainAlegAATr.h"
#include "TrainingAssociate.h"

using namespace std;

#define theDelay    100

struct History {
    int actions[MAX_ROUNDS][3][2];
    double scores[MAX_ROUNDS][2];
    int numPastRounds;
};

void playGame(int plyrNum, MarkovGame *mg, string elPartido, string agnt, string gen1 = "", string gen2 = "");
string readGame();
void playRound(AbstractAlegAATr *alegaatr, MarkovGame *mg, int plyrNum, string elPartido, int rndNum);
int observeRGAction(int plyrNum, int rnd);
int observeBDAction(int plyrNum, int ind, int rndNum, State *&sprime, MarkovGame *mg);
int takeRGAction(AbstractAlegAATr *alegaatr, MarkovGame *mg, int plyrNum);
int takeBDAction(AbstractAlegAATr *alegaatr, MarkovGame *mg, int plyrNum, int rndNum, State *&sprime);
void writeAction(int a, int plyrNum);
int translateBDAction(int a, bool tabl[3][3]);
State *determineBDState(MarkovGame *mg, int plyr0[3], int plyr1[3]);
void readTable(bool tabl[3][3], int plyr0[3], int plyr1[3], bool sortEm);
void decipherBlocks(string line, int plyr[3], bool sortEm);
void bubbleSort(int plyr[3]);
void swap(int plyr[3], int i, int j);
bool tableSet(bool tabl[3][3]);
int meToca(int plyrNum, int rndNum);
void readTheHistory(History &hist);
bool isGameOver(int rnd);

// ******************************************************************
//  (1) To run an AlegAATr agent:
//        ./alegaatr alegaatr [plyrNum]
//
//  (2) To run an AlegAATr agent in training:      
//        ./alegaatr train_alegaatr [plyrNum] [gen1] [gen2]
//
//  (3) To run an associate of an AlegAATr agent in training:
//        ./alegaatr training_associate [plyrNum] [gen1] [gen2]
//
//  Note: gameFlow should be started before this program is started
//
// ******************************************************************
int main(int argc, char *argv[]) {
    if (argc < 3) {
        cout << "Not enough parameters" << endl;
        return -1;
    }
    long micros = std::chrono::duration_cast<std::chrono::microseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
    srand(micros);
    
    string agnt(argv[1]);
    int plyrNum = atoi(argv[2]);
    string elPartido = readGame();
    MarkovGame *mg = new MarkovGame(elPartido.c_str(), plyrNum);

    if (!strcmp(argv[1], "alegaatr")) {
        cout << "running AlegAATr" << endl;

        playGame(plyrNum, mg, elPartido, argv[1]);
    }
    else if (!strcmp(argv[1], "train_alegaatr")) {
        if (argc < 5) {
            cout << "Not enough parameters" << endl;
            return -1;
        }

        cout << "training AlegAATr: " << argv[3] << " and " << argv[4] << " in the game " << elPartido << endl;

        string gen1 = argv[3];
        string gen2 = argv[4];
        playGame(plyrNum, mg, elPartido, agnt, gen1, gen2);
    }
    else if (!strcmp(argv[1], "training_associate")) {
        if (argc < 5) {
            cout << "Not enough parameters" << endl;
            return -1;
        }

        cout << "associate for training AlegAATr: " << argv[3] << " and " << argv[4] << endl;

        string gen1 = argv[3];
        string gen2 = argv[4];
        playGame(plyrNum, mg, elPartido, agnt, gen1, gen2);
    }
    else {
        cout << "alegaatr doesn't know what to do: " << argv[1] << endl;
    }

    delete mg;

    return 0;
}

void playGame(int plyrNum, MarkovGame *mg, string elPartido, string agnt, string gen1, string gen2) {
    History theHistory;
    AbstractAlegAATr *alegaatr;
    
    if (agnt == "alegaatr")
        alegaatr = new AlegAATr(plyrNum, mg);
    else if (agnt == "train_alegaatr")
        alegaatr = new TrainAlegAATr(plyrNum, mg, gen1, gen2, elPartido);
    else if (agnt == "training_associate")
        alegaatr = new TrainingAssociate(plyrNum, mg, gen1, gen2);
    
    int rndNum = 0;
    while (!isGameOver(rndNum)) {
        // cout << "\n\n*************************\nRound: " << (rndNum+1) << endl;
        playRound(alegaatr, mg, plyrNum, elPartido, rndNum);

        readTheHistory(theHistory);
        while (theHistory.numPastRounds == rndNum) {
            usleep(theDelay);
            readTheHistory(theHistory);
        }
        // cout << theHistory.scores[rndNum][0] << ", " << theHistory.scores[rndNum][1] << endl;
        // cout << theHistory.scores[0][0] << ", " << theHistory.scores[0][1] << endl;
        cout << "Round: " << (rndNum+1) << " -> " << theHistory.scores[rndNum][0] << ", " << theHistory.scores[rndNum][1] << endl;

        rndNum ++;
    }


    delete alegaatr;
}

void playRound(AbstractAlegAATr *alegaatr, MarkovGame *mg, int plyrNum, string elPartido, int rndNum) {
    // cout << "Start round" << endl;

    if (elPartido == "blockDilemma") {
        State *sprime;

        if (plyrNum == 0) {
            int a[2];
            a[plyrNum] = takeBDAction(alegaatr, mg, plyrNum, rndNum, sprime);
            a[1-plyrNum] = 0;
            alegaatr->updateAfterMove(sprime, a);

            // cout << "Actions: " << a[0] << ", " << a[1] << endl;

            a[plyrNum] = alegaatr->makeMove(sprime);
            a[1-plyrNum] = observeBDAction(plyrNum, 0, rndNum, sprime, mg);
            alegaatr->updateAfterMove(sprime, a);

            // cout << "Actions: " << a[0] << ", " << a[1] << endl;

            a[plyrNum] = takeBDAction(alegaatr, mg, plyrNum, rndNum, sprime);
            a[1-plyrNum] = 0;
            alegaatr->updateAfterMove(sprime, a);

            // cout << "Actions: " << a[0] << ", " << a[1] << endl;

            a[plyrNum] = alegaatr->makeMove(sprime);
            a[1-plyrNum] = observeBDAction(plyrNum, 1, rndNum, sprime, mg);
            alegaatr->updateAfterMove(sprime, a);

            // cout << "Actions: " << a[0] << ", " << a[1] << endl;

            a[plyrNum] = takeBDAction(alegaatr, mg, plyrNum, rndNum, sprime);
            a[1-plyrNum] = 0;
            alegaatr->updateAfterMove(sprime, a);

            // cout << "Actions: " << a[0] << ", " << a[1] << endl;

            a[plyrNum] = alegaatr->makeMove(sprime);
            a[1-plyrNum] = observeBDAction(plyrNum, 2, rndNum, sprime, mg);
            alegaatr->updateAfterMove(sprime, a);

            // cout << "Actions: " << a[0] << ", " << a[1] << endl;
        }
        else {
            if (meToca(plyrNum, rndNum) == -1)
                return;

            int a[2];
            a[plyrNum] = alegaatr->makeMove(mg->states[0]);
            a[1-plyrNum] = observeBDAction(plyrNum, 0, rndNum, sprime, mg);
            alegaatr->updateAfterMove(sprime, a);

            a[plyrNum] = takeBDAction(alegaatr, mg, plyrNum, rndNum, sprime);
            a[1-plyrNum] = 0;
            alegaatr->updateAfterMove(sprime, a);

            a[plyrNum] = alegaatr->makeMove(sprime);
            a[1-plyrNum] = observeBDAction(plyrNum, 1, rndNum, sprime, mg);
            alegaatr->updateAfterMove(sprime, a);

            a[plyrNum] = takeBDAction(alegaatr, mg, plyrNum, rndNum, sprime);
            a[1-plyrNum] = 0;
            alegaatr->updateAfterMove(sprime, a);

            a[plyrNum] = alegaatr->makeMove(sprime);
            a[1-plyrNum] = observeBDAction(plyrNum, 2, rndNum, sprime, mg);
            alegaatr->updateAfterMove(sprime, a);

            a[plyrNum] = takeBDAction(alegaatr, mg, plyrNum, rndNum, sprime);
            a[1-plyrNum] = 0;
            alegaatr->updateAfterMove(sprime, a);
        }

        alegaatr->updateRound();
    }
    else {
        if (meToca(plyrNum, rndNum) == -1)
            return;

        // History theHistory;
        // readTheHistory(theHistory);
        // cout << "Round: " << theHistory.numPastRounds << endl;

        int a[2];
        a[plyrNum] = takeRGAction(alegaatr, mg, plyrNum);
        if (a[plyrNum] < 0)
            return;
        a[1-plyrNum] = observeRGAction(plyrNum, rndNum);

        alegaatr->updateAfterMove(mg->states[0], a);

        // cout << "Actions: " << a[0] << ", " << a[1] << endl;

        alegaatr->updateRound();
    }

    // cout << "round over" << endl;
}

int observeRGAction(int plyrNum, int rnd) {
    History theHistory;
    readTheHistory(theHistory);

    while (rnd == theHistory.numPastRounds) {
        usleep(theDelay);
        readTheHistory(theHistory);
        // cout << "numPastRounds: " << theHistory.numPastRounds << endl;
    }

    // cout << theHistory.numPastRounds << endl;

    return theHistory.actions[rnd][0][1-plyrNum];
}

int observeBDAction(int plyrNum, int ind, int rndNum, State *&sprime, MarkovGame *mg) {
    bool tabl[3][3];
    int plyr[2][3];
    
    readTable(tabl, plyr[0], plyr[1], false);
    while (plyr[1-plyrNum][ind] == -1) {

        History theHistory;
        readTheHistory(theHistory);
        // cout << "hist length: " << theHistory.numPastRounds << " vs " << " round num: " << rndNum << endl;
        if (theHistory.numPastRounds > rndNum) {
            plyr[1-plyrNum][ind] = theHistory.actions[rndNum][ind][1-plyrNum];
            break;
        }
        else {
            usleep(theDelay);
            readTable(tabl, plyr[0], plyr[1], false);
        }
    }

    // cout << "Their picks: ";
    // for (int i = 0; i < 3; i++)
    //     cout << plyr[1-plyrNum][i] << " ";
    // cout << endl;

    // convert it
    int aprime = 0, c, s;
    for (int i = 0; i < plyr[1-plyrNum][ind]; i++) {
        c = i % 3;
        s = i / 3;
        if (tabl[c][s])
            aprime ++;
    }

    // plyr[plyrNum][ind] = aprime;

    sprime = determineBDState(mg, plyr[0], plyr[1]);

    return aprime;
}

// bool tableSet(bool tabl[3][3]) {
//     for (int i = 0; i < 3; i++) {
//         for (int j = 0; j < 3; j++) {
//             if (!tabl[i][j])
//                 return false;
//         }
//     }
//     return true;
// }

int takeRGAction(AbstractAlegAATr *alegaatr, MarkovGame *mg, int plyrNum) {
    int a = alegaatr->makeMove(mg->states[0]);

    writeAction(a, plyrNum);

    return a;
}

int takeBDAction(AbstractAlegAATr *alegaatr, MarkovGame *mg, int plyrNum, int rndNum, State *&sprime) {
    int gameStatus = meToca(plyrNum, rndNum);

    if (gameStatus == -1)
        return -1;

    bool tabl[3][3];
    int plyr0[3], plyr1[3];
    readTable(tabl, plyr0, plyr1, true);

    // cout << "read the table" << endl;

    // time to select an action
    State *s = determineBDState(mg, plyr0, plyr1);
    // cout << "State: " << s->ID << endl;
    
    int a = alegaatr->makeMove(s);

    // translate the action into hard actions
    int aprime = translateBDAction(a, tabl);
    // cout << "chose action " << aprime << endl;

    writeAction(aprime, plyrNum);

    if (plyrNum == 0) {
        int ind = 0;
        while (plyr0[ind] != -1)
            ind ++;
        plyr0[ind] = aprime;
        // plyr1[ind] = 0;
    }
    else {
        int ind = 0;
        while (plyr1[ind] != -1)
            ind ++;
        plyr1[ind] = aprime;
        // plyr0[ind] = 0;
    }

    sprime = determineBDState(mg, plyr0, plyr1);

    return a;
}

void writeAction(int a, int plyrNum) {
    stringstream ss;
    ss << "../SimulatedWorld/action" << plyrNum << ".alegaatr";
    string fnombre = ss.str();
    ofstream output(fnombre);
    output << a << endl;
    output.close();

    char cmd[1024];
    sprintf(cmd, "mv %s ../SimulatedWorld/action%i.txt", fnombre.c_str(), plyrNum);
    system(cmd);
}

int translateBDAction(int a, bool tabl[3][3]) {
    // cout << "translate " << a << endl;
    int count = 0, c, s;   
    for (int i = 0; i < 9; i++) {
        c = i % 3;
        s = i / 3;
        if (tabl[c][s]) {
            if (count == a)
                return i;
            else
                count ++;
        }
    }

    cout << "Shouldn't have gotten here" << endl;
    exit(1);

    return -1;
}

State *determineBDState(MarkovGame *mg, int plyr0[3], int plyr1[3]) {
    bubbleSort(plyr0);
    bubbleSort(plyr1);

    double featureVec[6];
    for (int i = 0; i < 3; i++) {
        featureVec[i] = plyr0[i];
        featureVec[i+3] = plyr1[i];
    }

    // cout << "featureVec: ";
    // for (int i = 0; i < 6; i++) {
    //     cout << featureVec[i] << " ";
    // }
    // cout << endl;

    State *s = mg->stateDefined(featureVec);

    // cout << "State ID: " << s->ID << endl;

    return s;
}

void readTable(bool tabl[3][3], int plyr0[3], int plyr1[3], bool sortEm) {
    ifstream ftab("../SimulatedWorld/Table.txt");

    string line;
    getline(ftab, line);
    for (int s = 0; s < 3; s++) {
        getline(ftab, line);
        for (int c = 0; c < 9; c+=3) {
            if (line[c] == ' ')
                tabl[c/3][s] = false;
            else
                tabl[c/3][s] = true;
        }
    }

    getline(ftab, line);
    getline(ftab, line);
    getline(ftab, line);
    decipherBlocks(line, plyr0, sortEm);

    getline(ftab, line);
    getline(ftab, line);
    getline(ftab, line);
    decipherBlocks(line, plyr1, sortEm);

    ftab.close();
}

void decipherBlocks(string line, int plyr[3], bool sortEm) {
    for (int i = 0; i < 3; i++) {
        plyr[i] = -1;
    }

    int count = 0;
    for (int i = 0; i < line.length(); i += 3) {
        int c = -1, s = -1;
        switch (line[i]) { // color of the string
            case 'r': c = 0; break;
            case 'b': c = 1; break;
            case 'g': c = 2; break;
        }

        switch (line[i+1]) { // shape of the string
            case 's': s = 0; break;
            case 't': s = 1; break;
            case 'c': s = 2; break;
        }

        plyr[count] = s * 3 + c;
        count ++;
    }

    if (sortEm) {
        bubbleSort(plyr);
    }
}

void bubbleSort(int plyr[3]) {
    if (plyr[1] >= 0) {
        if (plyr[0] > plyr[1]) {
            swap(plyr, 0, 1);
        }
        if (plyr[2] >= 0) {
            if (plyr[1] > plyr[2]) {
                swap(plyr, 1, 2);
                if (plyr[0] > plyr[1]) {
                    swap(plyr, 0, 1);
                }
            }
        }
    }
}

void swap(int plyr[3], int i, int j) {
    int tmp = plyr[i];
    plyr[i] = plyr[j];
    plyr[j] = tmp;
}

int meToca(int plyrNum, int rndNum) {
    string s;
    while (true) {
        if (isGameOver(rndNum))
            return -1;

        stringstream ss;
        ss << "../SimulatedWorld/action" << plyrNum << ".txt";
        string fnombre = ss.str();
        ifstream input(fnombre);
        input >> s;
        input.close();

        if (s == "?")
            return 1;

        usleep(theDelay);
    }

    return 0;
}

void readTheHistory(History &hist) {
    ifstream input("../SimulatedWorld/History.txt");

    if (input.is_open()) {
        string s, line;
        hist.numPastRounds = 0;
        while (!input.eof()) {
            getline(input, line);
            if (line.length() < 2)
                return;

            stringstream ss(line);

            if ((line[0] == 'r') || (line[0] == 'b') || (line[0] == 'g')) {
                for (int i = 0; i < 8; i++)
                    ss >> s;
                
            }
            else {
                ss >> hist.actions[hist.numPastRounds][0][0];
                hist.actions[hist.numPastRounds][1][0] = hist.actions[hist.numPastRounds][2][0] = -1;
                for (int i = 0; i < 3; i++) {
                    ss >> s;
                    // cout << s << endl;
                }
                ss >> hist.actions[hist.numPastRounds][0][1];
                hist.actions[hist.numPastRounds][1][1] = hist.actions[hist.numPastRounds][2][1] = -1;
                for (int i = 0; i < 3; i++) {
                    ss >> s;    
                    // cout << s << endl;
                }
            }

            ss >> hist.scores[hist.numPastRounds][0];
            ss >> hist.scores[hist.numPastRounds][1];

            // cout << hist.scores[hist.numPastRounds][0] << ", " << hist.scores[hist.numPastRounds][1] << endl;

            hist.numPastRounds ++;
        }
        // cout << "****" << hist.numPastRounds << endl;

        input.close();
    }
    else {
        hist.numPastRounds = 0;
    }
}

bool isGameOver(int rnd) {
    int readRnd = -1;

    while (true) {
        ifstream input("../SimulatedWorld/gameOver.txt");
        input >> readRnd;
        input.close();

        // cout << "gameOver status: " << s << endl;
        if (readRnd == -99)
            return true;
        else if (readRnd == rnd)
            return false;

        usleep(theDelay);
    }

    return false;
}

string readGame() {
    string s;
    ifstream input("../SimulatedWorld/elPartido.txt");
    input >> s;
    input.close();

    return s;
}