#ifndef PLAYER_H
#define PLAYER_H

#include "defs.h"
#include "State.h"
#include "Checker.h"

class Player {
public:
	Player();
	virtual ~Player();

	virtual void Reset();
	virtual void restoreFactorySettings();
	virtual int Move(State *s);
	virtual int moveUpdate(State *s, int actions[2]);
    virtual int roundUpdate(bool wasUsed);
	virtual void print(int config, int x1, int y1, int x2, int y2);

	void updateChecker(string _nombre, double value, double rate);
	void setChecker(string _nombre, double value);
    
    char nickname[1024];

	vector<Checker *> checkers;
	vector<double>checkerMask;

	double chExpectedPayout;
	bool asExpected;

	bool lock;
	int lockCount;

	map<int, double> actionConsiderations;
};

#endif