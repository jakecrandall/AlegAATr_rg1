#include <iostream>
#include <string>
#include <vector>
#include <fstream>

using namespace std;

string players[4] = {"eee", "bbl", "spp", "alegaatr"};

vector<string> split(string line) {
    vector<string> words;
    int indx;
    string left = line;

    while ((indx = left.find(",")) != string::npos) {
        words.push_back(left.substr(0, indx));
        left = left.substr(indx+1, left.length());
    }
    words.push_back(left);

    return words;
}

int getIndex(string plyr) {
    for (int i = 0; i < 4; i++) {
        if (players[i] == plyr)
            return i;
    }

    cout << "player " << plyr << " not found" << endl;
    exit(1);

    return -1;
}


// ./summary [results_file]
int main(int argc, char *argv[]) {
    if (argc < 2) {
        cout << "Not enough parameters" << endl;
        return -1;
    }

    string partido = argv[1];
    string fnombre = "../Results/" + partido + ".csv";
    string line;

    ifstream input(fnombre);
    if (!input) {
        cout << "file " << fnombre << " not found" << endl;
        return -1;
    }

    getline(input, line);

    double outcomes[4][4];
    for (int i = 0; i < 4; i++) {
        for (int j = 0; j < 4; j++) {
            outcomes[i][j] = 0.0;
        }
    }

    int ind1, ind2;
    while (!input.eof()) {
        getline(input, line);
        vector<string> words = split(line);

        if (words.size() < 4) {
            break;
        }

        ind1 = getIndex(words[0]);
        ind2 = getIndex(words[1]);

        outcomes[ind1][ind2] += stoi(words[2]);
        outcomes[ind2][ind1] += stoi(words[3]);
    }

    input.close();

    cout << endl;
    cout << "\t\teee\tbbl\tspp\talegaatr\t\tave" << endl;
    for (int i = 0; i < 4; i++) {
        if (i == 3)
            cout << players[i] << "\t";
        else
            cout << players[i] << "\t\t";
        
        double sum = 0.0;
        for (int j = 0; j < 4; j++) {
            cout << (outcomes[i][j] / 60.0) << "\t";
            sum += outcomes[i][j] / 60.0;
        }
        cout << "\t\t" << (sum/4.0) << endl;
    }
    cout << endl;

    return 0;
}