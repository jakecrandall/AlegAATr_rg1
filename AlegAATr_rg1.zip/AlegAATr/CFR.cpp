#include "CFR.h"

extern char partido[1024];

CFR::CFR() {
    printf("incomplete CFR constructor\n");
    exit(1);
}

CFR::CFR(int _me, MarkovGame *_mg, int _maxDepth, bool _update) {
    // std::cout << "initializing cfr" << std::endl;
    me = _me;
    mg = _mg;
    maxDepth = _maxDepth;
    update = _update;
    
    if (update)
        strcpy(nickname, "cfr");
    else
        strcpy(nickname, "cfr");
    
    buildGameTree();
    
    computeNE();
    
    cNode = gameTree[0];
    
    numMovemientos = t = 0;

    checkers.push_back(new Checker("CFR_myopicBR_gen", 1.0));               // always updates
    checkers.push_back(new Checker("CFR_myopicBR_spec", 1.0));              // doesn't update if CFR is used
    checkers.push_back(new Checker("CFR_payoffs_expected", 0.5));           // per-round payoffs are as expected (expected -> 0.5; 0.0 -> low; 1.0 -> high)
    // checkers.push_back(new Checker("CFR_myopicBR_gen", 0.0));               // always updates
    // checkers.push_back(new Checker("CFR_myopicBR_spec", 0.0));              // doesn't update if CFR is used
    // checkers.push_back(new Checker("CFR_payoffs_expected", 0.0));           // per-round payoffs are as expected (expected -> 0.5; 0.0 -> low; 1.0 -> high)

    chMyAve = 0.0;
    chUseCount = 0;

    // std::cout << "cfr ready" << std::endl;
    asExpected = false;

    lock = false;
}

CFR::~CFR() {
    int i;
    for (i = 0; i < numNodes; i++)
        delete gameTree[i];
}

void CFR::restoreFactorySettings() {
    numMovemientos = 0;
    chMyAve = 0.0;
    chUseCount = 0;
    for (int i = 0; i < checkers.size(); i++)
        checkers[i]->reset();
}

void CFR::buildGameTree() {
    // printf("starting to build the tree\n"); fflush(stdout);
    
    gameTree[0] = new Node(0, me, mg->states[0], 0, false);
    numNodes = 1;
    
    levelCounter[0] = 0;
    
    int d=maxDepth, l;
    int i, j, k, jact, noder, noder2;
    int c;
    for (l = 1; l < d; l++) {
        levelCounter[l] = numNodes;
        
        initAlready();
        
        for (i = levelCounter[l-1]; i < levelCounter[l]; i++) {
            if (isGoalState(gameTree[i]->s->ID))
                continue;
            
            for (j = 0; j < gameTree[i]->s->numActions[0]; j++) {
                for (k = 0; k < gameTree[i]->s->numActions[1]; k++) {
                    jact = gameTree[i]->s->jointCode(j, k);
                    noder = alreadyExists(gameTree[i]->s->nextState[jact][0]->ID);
                    if (noder < 0) {                        
                        gameTree[numNodes] = new Node(numNodes, me, gameTree[i]->s->nextState[jact][0], 1, isGoalState(gameTree[i]->s->nextState[jact][0]->ID));
                        gameTree[i]->next[jact] = gameTree[numNodes];
                        gameTree[i]->s->nextState[jact][0]->added = numNodes;
                        numNodes++;
                    }
                    else {
                        gameTree[noder]->duplo ++;
                        gameTree[i]->next[jact] = gameTree[noder];
                    }
                }
            }
        }
        c = levelCounter[l] - levelCounter[l-1];
        if (c == 0) {
            //l--;
            break;
        }
    }
    if (l == d)
        actualDepth = l;
    else
        actualDepth = l-1;
    
    levelCounter[l] = numNodes;
    
    // printf("numNodes = %i\n", numNodes);
    // printf("gameDepth = %i\n", actualDepth);
}

int CFR::findNode(State *s, int nivel) {
    int i;
    
    for (i = levelCounter[nivel]; i < levelCounter[nivel+1]; i++) {
        if (gameTree[i]->s->ID == s->ID)
            return i;
    }
    
    printf("got something wrong (findNode)\n");
    exit(1);
    
    return -1;
}

bool CFR::isGoalState(int s) {
    int i;
    for (i = 0; i < mg->numGoalStates; i++) {
        if (s == mg->goalStates[i]->ID)
            return true;
    }
    
    return false;
}

int CFR::alreadyExists(State *s, int strt, int nd) {
    int i;
    
    for (i = strt; i < nd; i++) {
        if (s->ID == gameTree[i]->s->ID)
            return i;
    }
    
    return -1;
}

int CFR::alreadyExists(State *s) {
    int i;
    
    for (i = 0; i < numNodes; i++) {
        if (s->ID == gameTree[i]->s->ID)
            return i;
    }
    
    return -1;
}

int CFR::alreadyExists(int s) {
    return mg->states[s]->added;
}

void CFR::initAlready() {
    int i;
    
    for (i = 0; i < mg->numStates; i++)
        mg->states[i]->added = -1;
}

void CFR::computeNE() {
    int Tmax = 30;
    int T;
    
    for (T = 1; T < Tmax; T++) {
        reset();
        computeUtilities(0);
        computeUtilities(1);
        // printf("utility: %lf, %lf\n", gameTree[0]->utility[0], gameTree[0]->utility[1]); fflush(stdout);
        
        computeReachability(0);
        computeReachability(1);
        
        updateRegret(0);
        updateRegret(1);
        
        updatePolicy(0, T);
        updatePolicy(1, T);
    }

    chExpectedPayout = gameTree[0]->utility[me];

    // record the best response
    // for (int i = 0; i < numNodes; i++) {
    //     for (int j = 0; j < gameTree[i]->s->numActions[0]; j++) {
    //         gameTree[i]->sigma_br[0][j] = gameTree[i]->sigma_t[0][j];
    //     }
    //     for (int j = 0; j < gameTree[i]->s->numActions[1]; j++) {
    //         gameTree[i]->sigma_br[1][j] = gameTree[i]->sigma_t[1][j];
    //     }
    // }
    
    if (update)
        initCounts();
}

void CFR::updateMe() {
    computeUtilities(me);
    computeReachability(me);
    updateRegret(me);
    updatePolicy(me, 1);
}

void CFR::initCounts() {
    int i;
    
    for (i = 0; i < numNodes; i++)
        gameTree[i]->initCounts();
}

void CFR::reset() {
    int i;
    
    for (i = 0; i < numNodes; i++) {
        gameTree[i]->reachability[0] = gameTree[i]->reachability[1] = 1.0;
        gameTree[i]->visited[0] = gameTree[i]->visited[1] = false;
    }

    chMyPayout = 0.0;
    numRoundMoves = numSupportedMoves = 0;
}

void CFR::computeUtilities(int index) {
    int nivel, j;

    if (index == me) {
        chLowPayout = 99999;
        chHighPayout = -99999;
    }
    
    for (nivel = actualDepth-1; nivel >= 0; nivel--) {
        for (j = levelCounter[nivel]; j < levelCounter[nivel+1]; j++) {
            if (isGoalState(gameTree[j]->s->ID) || (nivel == actualDepth-1)) {
                gameTree[j]->utility[index] = 0.0;
                continue;
            }
            
            gameTree[j]->computeUtility(index);

            // update high and low payoff values
            
            if (index == me) {
                int jact;
                for (int n = 0; n < gameTree[j]->s->numActions[0]; n++) {
                    for (int m = 0; m < gameTree[j]->s->numActions[1]; m++) {
                        jact = gameTree[j]->s->jointCode(n, m);
                        if (gameTree[j]->s->rewards[jact][0][me] < chLowPayout)
                            chLowPayout = gameTree[j]->s->rewards[jact][0][me];
                        if (gameTree[j]->s->rewards[jact][0][me] > chHighPayout)
                            chHighPayout = gameTree[j]->s->rewards[jact][0][me];
                    }
                }
            }
        }
    }
}

void CFR::computeReachability(int index) {
    int nivel, i, j, k;
    int jact;
    double pi;
    
    gameTree[0]->reachability[index] = 1.0;
    for (nivel = 0; nivel < (actualDepth-1); nivel++) {
        for (i = levelCounter[nivel]; i < levelCounter[nivel+1]; i++) {
            if (isGoalState(gameTree[i]->s->ID))
                continue;
            
            for (j = 0; j < gameTree[i]->s->numActions[0]; j++) {
                for (k = 0; k < gameTree[i]->s->numActions[1]; k++) {
                    jact = gameTree[i]->s->jointCode(j, k);
                    if (index == 0)
                        pi = gameTree[i]->sigma_t[1][k];
                    else
                        pi = gameTree[i]->sigma_t[0][j];
                    
                    if ((gameTree[i]->reachability[index] * pi) > gameTree[i]->next[jact]->reachability[index]) {
                        gameTree[i]->next[jact]->reachability[index] = gameTree[i]->reachability[index] * pi;
                    }
                }
            }
        }
    }
}

void CFR::updateRegret(int index) {
    int i;
    
    for (i = 0; i < levelCounter[actualDepth-1]; i++) {
        gameTree[i]->updateRegret(index);
    }
}

void CFR::updatePolicy(int index, int T) {
    int i;
    for (i = 0; i < levelCounter[actualDepth-1]; i++) {
        gameTree[i]->updatePolicy(index, T);
    }
}

int CFR::Move(State *s) {
    if (cNode->s->ID != s->ID) {
        printf("que pasa? %i vs %i!\n", cNode->s->ID, s->ID); fflush(stdout);
        exit(1);
    }
    
    int a = generateAction(cNode->sigma_t[me], cNode->s->numActions[me]);


    for (int i = 0; i < cNode->s->numActions[me]; i++) {
        actionConsiderations[i] = cNode->sigma_t[me][i];
    }
    
    return a;
}

int CFR::moveUpdate(State *s, int actions[2]) {
    int jact = cNode->s->jointCode(actions);
    
    if (update)
        cNode->cuentita[actions[1-me]] += 1.0;

    chMyPayout += cNode->s->rewards[jact][0][me];

    // did player 1-me play a best response (or supported by a best response
    if (cNode->s->numActions[1-me] > 1) {
        numRoundMoves++;
        // if (cNode->s->numActions[me] == 1) {
        //     std::cout << "cNode->sigma_br: " << cNode->sigma_br[1-me][actions[1-me]] << std::endl;
        //     std::cout << "   ";
        //     for (int i = 0; i < cNode->s->numActions[1-me]; i++) 
        //         std::cout << cNode->sigma_br[1-me][i] << " ";
        //     std::cout << std::endl;
        //     if (cNode->sigma_br[1-me][actions[1-me]] > 0.1)
        //         numSupportedMoves++;
        // }
        // else {
        double mx = -99999, util;
        int ja;
        // std::cout << "rewards: ";
        for (int i = 0; i < cNode->s->numActions[1-me]; i++) {
            if (me == 0)
                ja = cNode->s->jointCode(actions[0], i);
            else
                ja = cNode->s->jointCode(i, actions[1]);

            util = cNode->s->rewards[ja][0][1-me] + cNode->next[ja]->utility[1-me];

            // std::cout << util << " ";

            if (util > mx)
                mx = util;
        }
        // std::cout << std::endl;
        if ((cNode->s->rewards[jact][0][1-me] + cNode->next[jact]->utility[1-me]) >= (mx - 0.1)) {
            // std::cout << "  -> supported move" << std::endl;
            numSupportedMoves++;
        }
        // }
    }

    cNode = cNode->next[jact];
    
    numMovemientos++;
    
    return 0;
}

int CFR::roundUpdate(bool wasUsed) {
    cNode = gameTree[0];
    
    if (update && wasUsed) {
        int i;
        
        for (i = 0; i < numNodes; i++) {
            gameTree[i]->updateSigmaNot();
        }
        
        updateMe();
    }
    
    numMovemientos = 0;
    t++;

    // update all of the checkers
    double wasSupported = 1.0;
    // std:cout << "numRoundMoves: " << numRoundMoves << "; numSupportedMoves: " << numSupportedMoves << std::endl;
    if (numSupportedMoves < numRoundMoves)
        wasSupported = 0.0;
    // checkers[0]->update(wasSupported, 0.8);
    updateChecker("CFR_myopicBR_gen", wasSupported, 0.8);
    if (wasUsed) {
        updateChecker("CFR_myopicBR_spec", wasSupported, 0.8);

        chUseCount ++;
        double lmbda = 1.0 / chUseCount;
        if (lmbda < 0.2)
            lmbda = 0.2;
        // std::cout << " lmbda: " << lmbda << std::endl;
        // std::cout << " chMyAve: " << chMyPayout << std::endl;
        chMyAve = chMyAve * (1-lmbda) + chMyPayout * lmbda;
        double v;
        if (chExpectedPayout == chMyAve)
            v = 0.5;
        else if (chExpectedPayout < chMyAve)
            v = 0.5 + (0.5 * (chMyAve - chExpectedPayout)) / (chHighPayout - chExpectedPayout);
        else
            v = 0.5 * (chMyAve - chLowPayout) / (chExpectedPayout - chLowPayout);
        setChecker("CFR_payoffs_expected", v);
    }
    if (chMyPayout >= gameTree[0]->utility[me])
        asExpected = true;
    else
        asExpected = false;

    chMyPayout = 0.0;
    numRoundMoves = numSupportedMoves = 0;
    
    return 0;
}

int CFR::generateAction(double *v, int numActs) {
    int i;
    
    double num = rand() / (double)RAND_MAX;
    double sum = 0.0;
    for (i = 0; i < numActs; i++) {
        sum += v[i];
        if (num <= sum)
            return i;
    }
    
    printf("CFR: generate action failed: %lf\n", num);
    
    return numActs-1;
}