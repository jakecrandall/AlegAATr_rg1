#ifndef BBL_H
#define BBL_H

#include "defs.h"
#include "AbstractAlegAATr.h"
#include "MarkovGame.h"
#include "State.h"
#include "CFR.h"
#include "Xprt.h"

using namespace std;

class BBL : public AbstractAlegAATr {
public:
    BBL();
    BBL(int _plyrNum, MarkovGame *_mg, string partido, int _predictedGameRounds);
    ~BBL();

    int makeMove(State *s);
    void updateAfterMove(State *s, int actions[2]);
    void updateRound();

    int selectGeneratorGreedy(int _tiempo);
    void readMatrixOutcomes(string partido);
    void computeTheirMGThings();
    void createTheirGenerators(vector<string> genConfig);

private:
    int t;
    State *lastState;

    MarkovGame *theirMG;
    vector<Player *> theirGenerators;
    vector<double> probsThisRound;

    vector<double> typeKappa;
    double gengenOutcomes[20][10][10];
    int predictedGameRounds;

    int inARow;
};

#endif