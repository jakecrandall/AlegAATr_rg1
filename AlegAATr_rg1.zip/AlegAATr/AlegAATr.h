#ifndef ALEGAATR_H
#define ALEGAATR_H

#include "defs.h"
#include "AbstractAlegAATr.h"
#include "MarkovGame.h"
#include "State.h"
#include "CFR.h"
#include "Xprt.h"
#include "DataSet.h"

using namespace std;

// struct utilityPair {
//     double util, weight;
// };

class AlegAATr : public AbstractAlegAATr {
public:
    AlegAATr();
    AlegAATr(int _plyrNum, MarkovGame *_mg, string _elPartido, int _predictedGameLength, int _utilityCharacter);
    ~AlegAATr();

    void configureTrainingRun();
    int makeMove(State *s);
    void updateAfterMove(State *s, int actions[2]);
    void updateRound();

    int selectGeneratorGreedily();
    vector<double> getAATAssessments(DataSet *data, vector<double> estado, int tiempo, int elModo);
    vector<double> getCurrentAATState();
    void setAspirationLevel(string genStr);
    void setAspirationLevel(double propOfCoop);
    double getMax(vector<double> utils);
    int argMax(vector<double> utils);
    // int argMax(vector<utilityPair> utils);

    void logStatus();
    // void createGenerators(vector<string> genConfig);
    // vector<string> readGeneratorConfig();

    vector<double> generatorPayouts;

    DataSet data0, dataSameGen, dataDiffGen;
    int predictedGameLength;
    int t;
    int prevGenerator;

    double aspiration, expAveReward, roundPayout, theirRoundPayout, lambda;
    int notSatisfiedCount;
    State *lastState;

    ofstream logstream;
    string wasUsing, willUse;
    double payoffsSoFar, theirPayoffsSoFar;

    int utilityCharacter;
    int theMode;
    double nbsVal;

    bool verbose;

    bool logEm;
    ofstream logUtils;
};

#endif