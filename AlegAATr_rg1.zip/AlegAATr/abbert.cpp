#include "abbert.h"

extern char partido[1024];

abbert::abbert() {
    printf("incomplete a-bert constructor\n");
    exit(1);
}

abbert::abbert(MarkovGame *_mg, int _me, bool _allowSwitching) {
    mg = _mg;
    me = _me;
    allowSwitching = _allowSwitching;
    
    cLen = 3 + rand() % 2;

    numSolss = 0;
    
    numHighLevelActions = 1;//mg->states[0]->numQsets + 2;    
    reset();
    numStateHistoryPrev = 0;
    bron = false;
    
    //egalPoint = -1;
    
    deltaMax = 4.0;
    
    backward = false;
    numHighLevelActions = 1;//mg->states[0]->numQsets + 2;
}

abbert::~abbert() {
    int i;
    
    for (i = 0; i < numExperts; i++)
        delete xprts[i];
    delete xprts;

    for (i = 0; i < numSolss; i++)
        delete sols[i];
}

void abbert::computeMaxminExpert(double _lambda) {
    numExperts = 1;
    xprts = new Expert*[1];
    xprts[0] = new Expert(MINIMAX, -1, -1, cLen, _lambda, false, 0.0);    
}

void abbert::computeFolkEgalExpert(double _lambda, bool lead) {
    double w[2], P[2];
    
    //double deltaMax = 4.0;
    int numSols = 0;
    int sol[2];
    double rmax_me = -99999;
    for (w[0] = mg->wvals[0]; w[0] < mg->wvals[1] + 0.000001; w[0] += mg->wvals[2]) {
        w[1] = 1.0 - w[0];
        getMax(mg->startStates[0], w, P);
        
        if (P[me] > rmax_me)
            rmax_me = P[me];
        
        sol[0] = sol[1] = numSols;
        sols[numSols] = new Solution(sol, P, mg, me, deltaMax);
        
        numSols++;
    }
    int numPureSols = numSols;

    // prune back the solutions
    bool *keepers = new bool[numSols];
    for (int i = 0; i < numSols; i++) {
        keepers[i] = false;
    }
    
    int curInd = 0;
    int markers[2];
    while (true) {
        pruneTheSols(sols, numSols, curInd, markers);
        keepers[markers[0]] = true;
        // std::cout << "Keep: " << markers[0] << std::endl;
        curInd = markers[1];
        if (curInd >= numSols)
            break;
    }
    
    double v[2];
    for (int i = 0; i < numPureSols; i++) {
        if (!keepers[i]) {
            sols[i]->payouts[0] = sols[i]->payouts[1] = -99999;
            continue;
        }
        for (int j = i+1; j < numPureSols; j++) {
            if (!keepers[j])
                continue;

            v[0] = (sols[i]->payouts[0] + sols[j]->payouts[0]) / 2.0;
            v[1] = (sols[i]->payouts[1] + sols[j]->payouts[1]) / 2.0;
            
            sol[0] = sols[i]->indices[0];
            sol[1] = sols[j]->indices[0];
            sols[numSols] = new Solution(sol, v);
            sols[numSols]->maxGuilt[0] = sols[i]->maxGuilt[0];
            sols[numSols]->maxGuilt[1] = sols[j]->maxGuilt[1];
            // printf("combo(%i, %i): (%.2lf, %.2lf)\n", sols[numSols]->indices[0], sols[numSols]->indices[1], sols[numSols]->payouts[0], sols[numSols]->payouts[1]);
            sols[numSols]->computePunishmentRatio(mg, me);
            
            numSols++;
        }
    }
    
    double mvs[2];
    mvs[0] = mg->states[0]->mm[0]->mv;
    mvs[1] = mg->states[0]->mm[1]->mv;
    selectSolutions(1, sols, numSols, mvs);
    
    numExperts = 0;
    xprts = new Expert*[1];
    
    for (int i = 0; i < numSols; i++) {
        if (sols[i]->selected) {
            if (lead) {
                xprts[0] = new Expert(LEADER2, sols[i]->indices[0], sols[i]->indices[1],
                                   sols[sols[i]->indices[0]]->payouts, sols[sols[i]->indices[1]]->payouts, deltaMax, cLen, _lambda, me, allowSwitching);
            }
            else {
                xprts[0] = new Expert(FOLLOWER, sols[i]->indices[0], sols[i]->indices[1],
                                      sols[sols[i]->indices[0]]->payouts, sols[sols[i]->indices[1]]->payouts, deltaMax, cLen, _lambda, me, allowSwitching);
            }
            numExperts ++;
        }
    }
    
    bron = false;

    delete[] keepers;

    numSolss = numSols;
}

void abbert::pruneTheSols(Solution *sols[MAX_EXPERTS], int numSols, int strt, int markers[2]) {
    int indx = strt + 1;
    while ((sols[indx]->payouts[0] == sols[strt]->payouts[0]) &&  (sols[indx]->payouts[1] == sols[strt]->payouts[1])) {
        indx ++;

        if (indx == numSols)
            break;
    }
    // std::cout << "0 to " << indx << " are the same" << std::endl;
    if ((indx != numSols) && (strt == 0)) {
        markers[0] = strt;
    }
    else if ((indx != numSols) && (strt != 0)) {
        markers[0] = (strt + indx) / 2;
    }
    else {
        markers[0] = numSols-1;
    }

    markers[1] = indx;
}

void abbert::computeBullyExpert(double _lambda, bool opposite, bool lead) {
    int s, i, j;
    
    double w[2], P[2];
    
    //double deltaMax = 2.0;
    int numSols = 0;
    int sol[2];
    double rmax_me = -99999;
    for (w[0] = mg->wvals[0]; w[0] < mg->wvals[1] + 0.000001; w[0] += mg->wvals[2]) {
        w[1] = 1.0 - w[0];
        getMax(mg->startStates[0], w, P);
        // if (me == 0)
        //     P[0] += 0.001 * w[0];//0.001 * (1.0 - w[0]) * (1.0 - w[0]);
        // else
        //     P[1] += 0.001 * (1-w[0]);//0.001 * w[0] * w[0];
        // printf("w = %.2lf: (%.2lf, %.2lf)\n", w[0], P[0], P[1]);
        
        if (P[me] > rmax_me)
            rmax_me = P[me];
        
        sol[0] = sol[1] = numSols;
        sols[numSols] = new Solution(sol, P, mg, me, deltaMax);
        
        numSols++;
    }
    int numPureSols = numSols;

    // prune back the solutions
    bool *keepers = new bool[numSols];
    for (int i = 0; i < numSols; i++) {
        keepers[i] = false;
    }
    
    int curInd = 0;
    int markers[2];
    while (true) {
        pruneTheSols(sols, numSols, curInd, markers);
        keepers[markers[0]] = true;
        // std::cout << "Keep: " << markers[0] << std::endl;
        curInd = markers[1];
        if (curInd >= numSols)
            break;
    }
    
    double v[2];
    for (i = 0; i < numPureSols; i++) {
        if (!keepers[i]) {
            sols[i]->payouts[0] = sols[i]->payouts[1] = -99999;
            continue;
        }
        for (j = i+1; j < numPureSols; j++) {
            if (!keepers[j])
                continue;

            v[0] = (sols[i]->payouts[0] + sols[j]->payouts[0]) / 2.0;
            v[1] = (sols[i]->payouts[1] + sols[j]->payouts[1]) / 2.0;
            
            sol[0] = sols[i]->indices[0];
            sol[1] = sols[j]->indices[0];
            sols[numSols] = new Solution(sol, v);
            sols[numSols]->maxGuilt[0] = sols[i]->maxGuilt[0];
            sols[numSols]->maxGuilt[1] = sols[j]->maxGuilt[1];
            // printf("combo(%i, %i): (%.2lf, %.2lf)\n", sols[numSols]->indices[0], sols[numSols]->indices[1], sols[numSols]->payouts[0], sols[numSols]->payouts[1]);
            sols[numSols]->computePunishmentRatio(mg, me);
            
            numSols++;
        }
    }
    
    double mvs[2];
    mvs[0] = mg->states[0]->mm[0]->mv;
    mvs[1] = mg->states[0]->mm[1]->mv;
    selectSolutions(2, sols, numSols, mvs);
    
    numExperts = 0;
    xprts = new Expert*[1];
    bool primero;
    if (!backward)
        primero = opposite;
    else
        primero = !opposite;
    // printf("me = %i\n", me);
    // if (primero)
    //     printf("primero = true\n");
    // else
    //     printf("primero = false\n");
    for (i = 0; i < numSols; i++) {
        if (sols[i]->selected) {
            if (((me == 0) && !primero) || ((me == 1) && primero)) {
                // printf("right one (%i): %.2lf, %.2lf\n", i, sols[i]->payouts[0], sols[i]->payouts[1]);
                if (lead) {
                    xprts[0] = new Expert(LEADER2, sols[i]->indices[0], sols[i]->indices[1],
                                        sols[sols[i]->indices[0]]->payouts, sols[sols[i]->indices[1]]->payouts, deltaMax, cLen, _lambda, me, allowSwitching);
                }
                else {
                    xprts[0] = new Expert(FOLLOWER, sols[i]->indices[0], sols[i]->indices[1],
                                        sols[sols[i]->indices[0]]->payouts, sols[sols[i]->indices[1]]->payouts, deltaMax, cLen, _lambda, me, allowSwitching);
                }
                numExperts ++;
            }
            // else {
            //     printf("wrong one (%i): %.2lf, %.2lf\n", i, sols[i]->payouts[0], sols[i]->payouts[1]);
            // }
            primero = !primero;//opposite;
        }
    }

    // std::cout << xprts[0]->strat[0] << std::endl;
    // std::cout << xprts[0]->strat[1] << std::endl;

    // printf("numExperts = %i\n", numExperts);
    
    bron = false;

    delete[] keepers;

    numSolss = numSols;
}

bool abbert::isUnique2(int ind, int numUnique, int *uniqueSolutions) {
    int b_ind[2];
    double Vme = mg->startStates[0]->qsets[ind]->V;
    int i, j;
    
    for (i = 0; i < mg->startStates[0]->numActions[0]; i++) {
        for (j = 0; j < mg->startStates[0]->numActions[1]; j++) {
            if (mg->startStates[0]->qsets[ind]->Qs[i][j] == Vme) {
                b_ind[0] = i;
                b_ind[1] = j;
            }
        }
    }
    
    double d;
    for (i = 0; i < numUnique; i++) {
        d = fabs(mg->startStates[0]->qsets[uniqueSolutions[i]]->M[b_ind[0]][b_ind[1]][0] - mg->startStates[0]->qsets[ind]->M[b_ind[0]][b_ind[1]][0]);
        d += fabs(mg->startStates[0]->qsets[uniqueSolutions[i]]->M[b_ind[0]][b_ind[1]][1] - mg->startStates[0]->qsets[ind]->M[b_ind[0]][b_ind[1]][1]);
        if (d < 0.1)
            return false;
    }
    
    return true;
}


bool abbert::isUnique(int ind, int numUnique, int *uniqueSolutions) {
    int i, j, k;
    int acts[2];
    
    acts[0] = mg->startStates[0]->numActions[0];
    acts[1] = mg->startStates[0]->numActions[1];
    //printf("acts: (%i, %i); numUnique = %i\n", acts[0], acts[1], numUnique);
    //printf("test vs. %i ... ", numUnique);
    
    double d;
    for (i = 0; i < numUnique; i++) {
        bool diff = false;
        for (j = 0; j < acts[0]; j++) {
            for (k = 0; k < acts[1]; k++) {
                d = fabs(mg->startStates[0]->qsets[uniqueSolutions[i]]->M[j][k][0] - mg->startStates[0]->qsets[ind]->M[j][k][0]);
                d += fabs(mg->startStates[0]->qsets[uniqueSolutions[i]]->M[j][k][1] - mg->startStates[0]->qsets[ind]->M[j][k][1]);
                //printf("%lf ... ", d);
                if (d >= 0.01) {
                    diff = true;
                }
            }
        }
        if (!diff)
            return false;
    }
    
    return true;
}

void abbert::getMax(State *s, double w[2], double R[2]) {
    int i, j;
    int mIndi = -1, mIndj = -1;
    double mx = -999999, val;
    
    int qind = s->findQset(w[0]);
    
    for (i = 0; i < s->numActions[0]; i++) {
        for (j = 0; j < s->numActions[1]; j++) {
            //val = w[0] * (s->qsets[qind]->M[i][j][0] - s->mm[0]->mv) + w[1] * (s->qsets[qind]->M[i][j][1] - s->mm[1]->mv);
            val = w[0] * s->qsets[qind]->M[i][j][0] + w[1] * s->qsets[qind]->M[i][j][1];
            if (val > mx) {
                mx = val;
                mIndi = i;
                mIndj = j;
            }
        }
    }
    
    //R[0] = s->qsets[qind]->M[mIndi][mIndj][0] - s->mm[0]->mv;
    //R[1] = s->qsets[qind]->M[mIndi][mIndj][1] - s->mm[1]->mv;
    R[0] = s->qsets[qind]->M[mIndi][mIndj][0];
    R[1] = s->qsets[qind]->M[mIndi][mIndj][1];
}

void abbert::moveUpdate(State *s, State *sprime, int acts[2], int experto, double rPayout[2], double aspiration, int corA) {
    //printf("(#%i,%i#", acts[0], acts[1]); fflush(stdout);
    // std::cout << "abbert moveUpdate" << std::endl;

    s->cuentas[acts[0]][acts[1]]++;

    stateHistory[numStateHistory] = s->ID;
    numStateHistory++;

    //printf("e"); fflush(stdout);
    
    if (repeatedVisit() && bron) {
        //printf("r"); fflush(stdout);
        mg->computeBR(me, true);
    }

    
    // update conformance to each high-level action
    updateConformance(s, acts);

    //printf("g"); fflush(stdout);
    
    // char message[1024];
    // if ((xprts[experto]->tipo == FOLLOWER) || (xprts[experto]->tipo == LEADER) || (xprts[experto]->tipo == LEADER2)) {
    //     if ((corA >= 0) && (corA < mg->numLabels)) {
    //         //printf("!%i!", corA);
    //         sprintf(message, "%s %s", mg->actionDescription, mg->actionLabels[corA]);
    //     }
    //     else
    //         strcpy(message, "");
    // }
    // else {
    //     strcpy(message, "");
    // }
    
    //printf("a<%i>", experto); fflush(stdout);
    // std::cout << "updated conformance" << std::endl;

    xprts[experto]->updateMove(sprime, rPayout, me, acts, aspiration);

    // std::cout << "updated from Expert.cpp" << std::endl;
    
    //printf("l"); fflush(stdout);
}

void abbert::roundUpdate(double rPayout[2]) {
    
    if (bron)
        mg->computeBR(me, true);
    
    int i;

    //printf("Conformance:\n");
    //int highestInd[2] = {0, 0};
    highestInd[0] = highestInd[1] = 0;
    //printf("numStateHistory = %i\n", numStateHistory);
    for (i = 0; i < numHighLevelActions; i++) {
        //printf("%i: %.2lf, %.2lf\n", i, conformance[0][i] / numStateHistory, conformance[1][i] / numStateHistory);
        if (conformance[0][i] > conformance[0][highestInd[0]])
            highestInd[0] = i;
        if (conformance[1][i] > conformance[1][highestInd[1]])
            highestInd[1] = i;
    }
    //printf("lastAction (%i): ", highestInd[0]);
    for (i = 0; i < numHighLevelActions; i++) {
        if (fabs(conformance[0][i] - conformance[0][highestInd[0]]) < 0.001)
            lastActions[0][i] = 1;
        else
            lastActions[0][i] = 0;
        //printf("%i", lastActions[0][i]);
    }
    //printf("\n");
    
    //printf("lastAction (%i): ", highestInd[1]);
    for (i = 0; i < numHighLevelActions; i++) {
        if (fabs(conformance[1][i] - conformance[1][highestInd[1]]) < 0.001)
            lastActions[1][i] = 1;
        else
            lastActions[1][i] = 0;
        //printf("%i", lastActions[1][i]);
    }
    //printf("\n");
    
    
    //printf("actions: %i, %i\n", highestInd[0], highestInd[1]);
    
    
    numStateHistoryPrev = numStateHistory;
    for (i = 0; i < numStateHistory; i++) {
        stateHistoryPrev[i] = stateHistory[i];
    }
    
    
    reset();
}

bool abbert::repeatedVisit() {
    int i;
    
    //printf("check ... "); fflush(stdout);
    for (i = 0; i < numStateHistory-1; i++) {
        if (stateHistory[i] == stateHistory[numStateHistory-1]) {
            //printf("repeated visit\n");
            return true;
        }
    }
    //printf("none\n"); fflush(stdout);
    
    return false;
}

void abbert::reset() {
    numStateHistory = 0;
    //numStateHistoryPrev = 0;
    //rPayout[0] = rPayout[1] = 0.0;

    int i;
    for (i = 0; i < numHighLevelActions; i++) {
        conformance[0][i] = conformance[1][i] = 0.0;
    }
}

int abbert::selectSolutions(int maxSols, Solution *sols[MAX_EXPERTS], int numSols, double mv[2]) {
    int selected[MAX_EXPERTS];
    double score[MAX_EXPERTS];
    int numSelected = 0;
    int i, j;
    int ind;
    double mx, mn;
    
    // printf("select %i solutions\n", maxSols); fflush(stdout);
    
    // std::cout << mv[0] << ", " << mv[1] << std::endl;
    if (maxSols > 1) {
        // find the extreme points (highest for each person, but greater than mv)
        for (j = 0; j < 2; j++) {
            mx = -99999;
            ind = -1;
            for (i = 0; i < numSols; i++) {
                if (sols[i]->selected || (sols[i]->payouts[0] < mv[0]) || (sols[i]->payouts[1] < mv[1]))
                    continue;
                
                if ((sols[i]->payouts[j] > mx) || ((sols[i]->payouts[j] == mx) && (rand() % 2))) {
                    mx = sols[i]->payouts[j];
                    ind = i;
                }
            }
            
            if (ind < 0) {
                printf("selection gone bad\n");
                exit(1);
            }
            
            sols[ind]->selected = true;
            selected[numSelected] = ind;
            numSelected++;
            
            // printf("extreme %i = %i: (%lf, %lf)\n", j, ind, sols[ind]->payouts[0], sols[ind]->payouts[1]);
        }
        
        // printf("selected[0] = %i\nselected[1] = %i\n", selected[0], selected[1]);
        if (selected[0] < selected[1])
            backward = true;
    }
    
    
    if ((maxSols == 1) || (maxSols > 2)) {
        // std::cout << "primero" << std::endl;
        // select the egalitarian equilibrium
        mx = -99999;
        ind = -1;
        for (i = 0; i < numSols; i++) {
            if (sols[i]->selected || (sols[i]->payouts[0] <= mv[0]) || (sols[i]->payouts[1] <= mv[1]))
                continue;
            
            if (sols[i]->payouts[1] < sols[i]->payouts[0])
                mn = sols[i]->payouts[1];
            else
                mn = sols[i]->payouts[0];
            
            if ((mn > mx) || ((mn == mx) && (rand() % 2))) {
                mx = mn;
                ind = i;
            }
        }
        sols[ind]->selected = true;
        selected[numSelected] = ind;
        numSelected++;
        
        //printf("egalitarian point = %i: (%lf, %lf)\n", ind, sols[ind]->payouts[0], sols[ind]->payouts[1]);
        //egalPoint = ind;
    }
    
    while (numSelected < maxSols) {
        double normDist = dist(sols[selected[0]]->payouts, sols[selected[1]]->payouts);
        //printf("normDist = %lf\n", normDist);
        
        bool one = false;
        for (i = 0; i < numSols; i++) {
            if (sols[i]->selected || (sols[i]->payouts[0] <= mv[0]) || (sols[i]->payouts[1] <= mv[1]))
                score[i] = -1;
            else {
                score[i] = distance(i, sols, numSols) / normDist;
                if (score[i] > 0.00001) {
                    one = true;
                    if (!isParetoDominated(i, sols, numSols))
                        score[i] += 0.05;
                    if (sols[i]->punishmentRatio <= 1)
                        score[i] += 0.05;
                    if (sols[i]->indices[0] == sols[i]->indices[1])
                        score[i] += 0.05;
                }
                //printf("%i: %lf\n", i, score[i]);
            }
        }
        
        if (!one)
            break;
        
        ind = -1;
        mx = -99999;
        for (i = 0; i < numSols; i++) {
            if ((score[i] > mx) || ((score[i] == mx) && (rand() % 2))) {
                ind = i;
                mx = score[i];
            }
        }
        
        if (ind == -1)
            break;

        //printf("picked %i: (%lf, %lf)\n", ind, sols[ind]->payouts[0], sols[ind]->payouts[1]);
        sols[ind]->selected = true;
        selected[numSelected] = ind;
        numSelected++;
    }
    
    return numSelected;
}

void abbert::findHighFair(double barR[2], char gname[1024]) {
    if (!strcmp(gname, "prisoners"))
        barR[0] = barR[1] = 16.0;
    else if (!strcmp(gname, "legos"))
        barR[0] = barR[1] = 18.0;
    else if (!strcmp(gname, "gridwar1")) {
        barR[0] = 20.40;
        barR[1] = 19.70;
    }
    else {
        printf("preventer barR not found\n");
        exit(1);
    }
}

bool abbert::isParetoDominated(int index, Solution *sols[MAX_EXPERTS], int numSols) {
    int i;
    
    for (i = 0; i < numSols; i++) {
        if (i == index)
            continue;
        
        if ((sols[i]->payouts[0] > sols[index]->payouts[0]) && (sols[i]->payouts[1] > sols[index]->payouts[1])) {
            //printf("%lf, %lf is pareto dominated\n", sols[index]->payouts[0], sols[index]->payouts[1]);
            return true;
        }
    }
    
    return false;
}

double abbert::distance(int index, Solution *sols[MAX_EXPERTS], int numSols) {
    int i;
    double minDist = 99999, d;
    
    for (i = 0; i < numSols; i++) {
        if (sols[i]->selected) {
            d = dist(sols[i]->payouts, sols[index]->payouts);
            if (d < minDist)
                minDist = d;
        }
    }
    
    //printf("minDist = %lf\n", minDist);
    
    return minDist;
}

double abbert::dist(double P1[2], double P2[2]) {
    //printf("P1: %lf, %lf; P2: %lf, %lf\n", P1[0], P1[1], P2[0], P2[1]);
    
    return sqrt((P1[0] - P2[0]) * (P1[0] - P2[0]) + (P1[1] - P2[1]) * (P1[1] - P2[1]));
}

void abbert::determineRewardBins(double separator[2][3], Solution *sols[MAX_EXPERTS], int numPureSols) {
    int i, j;
    double *l1 = new double[numPureSols+1];
    double *l2 = new double[numPureSols+1];
    double tmp;
    int num1 = numPureSols+1, num2 = numPureSols+1;
    
    l1[0] = mg->startStates[0]->mm[0]->mv;
    l2[0] = mg->startStates[0]->mm[1]->mv;
    for (i = 0; i < numPureSols; i++) {
        l1[i+1] = sols[i]->payouts[0];
        l2[i+1] = sols[i]->payouts[1];
    }
    
    for (i = 0; i < numPureSols+1; i++) {
        for (j = 0; j < numPureSols; j++) {
            if (l1[j] > l1[j+1]) {
                tmp = l1[j];
                l1[j] = l1[j+1];
                l1[j+1] = tmp;
            }
            if (l2[j] > l2[j+1]) {
                tmp = l2[j];
                l2[j] = l2[j+1];
                l2[j+1] = tmp;
            }
        }
    }
    
//    printf("0: ");
//    for (i = 0; i < numPureSols+1; i++) {
//        printf("%lf ", l1[i]);
//    }
//    printf("\n");
    
//    printf("1: ");
//    for (i = 0; i < numPureSols+1; i++) {
//        printf("%lf ", l2[i]);
//    }
//    printf("\n");
    
    for (i = num1-1; i >= 1; i--) {
        if (fabs(l1[i] - l1[i-1]) < 0.001) {
            num1--;
            for (j = i; j < num1; j++)
                l1[j] = l1[j+1];
        }
    }
//    printf("0: ");
//    for (i = 0; i < num1; i++) {
//        printf("%lf ", l1[i]);
//    }
//    printf("\n");
    for (i = num2-1; i >= 1; i--) {
        if (fabs(l2[i] - l2[i-1]) < 0.001) {
            num2--;
            for (j = i; j < num2; j++)
                l2[j] = l2[j+1];
        }
    }
//    printf("1: ");
//    for (i = 0; i < num2; i++) {
//        printf("%lf ", l2[i]);
//    }
//    printf("\n");
    
    double temper[2][4];
    temper[0][0] = l1[0];
    temper[0][1] = l1[(int)(num1 / 4.0)];
    temper[0][2] = l1[(int)(3.0 * num1 / 4.0)-1];
    temper[0][3] = l1[num1-1];
    //printf("%lf %lf %lf %lf\n", temper[0][0], temper[0][1], temper[0][2], temper[0][3]);
    temper[1][0] = l2[0];
    temper[1][1] = l2[(int)(num1 / 4.0)];
    temper[1][2] = l2[(int)(3.0 * num1 / 4.0)-1];
    temper[1][3] = l2[num1-1];
    //printf("%lf %lf %lf %lf\n", temper[1][0], temper[1][1], temper[1][2], temper[1][3]);
    
    for (i = 0; i < 2; i++) {
        printf("separator %i: ", i);
        for (j = 0; j < 3; j++) {
            separator[0][j] = (temper[i][j] + temper[i][j+1]) / 2.0;
            printf("%.2lf ", separator[0][j]);
        }
        printf("\n");
    }
    
    delete[] l1;
    delete[] l2;
}

// Assume that state 0 is the unique start state for this
void abbert::tweakCuentasPriors() {
    // find which qset we need to use
    int qind;
    if (me == 1)
        qind = mg->states[0]->findQset(0.9);
    else
        qind = mg->states[0]->findQset(0.1);
    
    //printf("qind = %i\n", qind); fflush(stdout);

    int s, i, j;
    double high, low;
    for (s = 0; s < mg->numStates; s++) {
        //printf("s = %i\n", mg->states[s]->ID); fflush(stdout);
        double *vals = new double[mg->states[s]->numActions[1-me]];
        for (i = 0; i < mg->states[s]->numActions[1-me]; i++)
            vals[i] = 0.0;
        
        for (i = 0; i < mg->states[s]->numActions[0]; i++) {
            for (j = 0; j < mg->states[s]->numActions[1]; j++) {
                if (me == 0) {
                    vals[j] += mg->states[s]->qsets[qind]->Qs[i][j];
                }
                else {
                    vals[i] += mg->states[s]->qsets[qind]->Qs[i][j];
                }
            }
        }
        
        high = -99999;
        low = 99999;
        for (i = 0; i < mg->states[s]->numActions[1-me]; i++) {
            if (vals[i] > high)
                high = vals[i];
            if (vals[i] < low)
                low = vals[i];
        }
        
        //printf("high = %lf; low = %lf\n", high, low); fflush(stdout);
        
        for (i = 0; i < mg->states[s]->numActions[0]; i++) {
            for (j = 0; j < mg->states[s]->numActions[1]; j++) {
                if (fabs(high - low) < 0.01) {
                    mg->states[s]->cuentas[i][j] = 0.1;
                }
                else {
                    if (me == 0) {
                        mg->states[s]->cuentas[i][j] = (vals[j] - low) / (high - low);
                    }
                    else {
                        mg->states[s]->cuentas[i][j] = (vals[i] - low) / (high - low);
                    }
                }
            }
        }
        
        
        delete[] vals;
    }
    
    //printf("tweaked\n"); fflush(stdout);
}

void abbert::adjustBRPriors() {
    int s, a, j;
    
    double pwrVal = 1;
    
    for (s = 0; s < mg->numStates; s++) {
        for (a = 0; a < mg->states[s]->numActions[0]; a++) {
            for (j = 0; j < mg->states[s]->numActions[1]; j++) {
                mg->states[s]->cuentas[a][j] = mg->states[s]->cuentas_real[a][j];
            }
        }
    }
}

void abbert::updateConformance(State *s, int acts[2]) {
    double pi[20];
    int i, j;
    double probs[2*NUMACTIONS];
    
    for (j = 0; j < 2; j++) {
        for (i = 0; i < s->numActions[j]; i++) {
            if (acts[j] != i)
                pi[i] = 0.0;
            else
                pi[i] = 1.0;
        }

        conformance[j][0] += policyAgreement(s->mm[j]->ms, pi, s->numActions[j]);
        conformance[j][1] += policyAgreement(s->attack[j]->ms, pi, s->numActions[j]);
        
        for (i = 0; i < s->numQsets; i++)
            conformance[j][2+i] += s->qsets[i]->getConformance(j, acts[j]);
    }
}

void abbert::determineHighLevelActions() {
    numHighLevelActions = mg->states[0]->numQsets + 2;
    
    int i;
    for (i = 0; i < numHighLevelActions; i++)
        lastActions[0][i] = lastActions[1][i] = -1;
}

// tdiff = 0 means complete policy agreement
double abbert::policyAgreement(double *p1, double *p2, int numActs) {
    double tdiff = 0.0;
    int i;
    
    //printf("policy agreement (%i)\n", numActs); fflush(stdout);
    
    for (i = 0; i < numActs; i++) {
        //printf("%i: %lf vs %lf\n", i, p1[i], p2[i]);
        tdiff += fabs(p1[i] - p2[i]);
    }
    
    //printf("tdiff = %lf\n", tdiff);
    
    tdiff = 1 - tdiff/2;
    if (tdiff < 0)
        tdiff = 0;
    
    return tdiff;

    //printf("tdiff = %lf\n", tdiff);
    
    /*if (tdiff > 0.1) {
        printf("tdiff = %.3lf\n", tdiff);
        for (i = 0; i < numActs; i++)
            printf("%i: %lf vs %lf\n", i, p1[i], p2[i]);
        printf("\n");
    }*/
    
    //return tdiff / 2.0;
}

