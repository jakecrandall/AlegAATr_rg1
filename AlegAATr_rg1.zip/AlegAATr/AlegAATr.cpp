#include "AlegAATr.h"

AlegAATr::AlegAATr() {
    cout << "Incomplete AlegAATr constructor" << endl;
    exit(1);
}

AlegAATr::AlegAATr(int _plyrNum, MarkovGame *_mg, string _elPartido, int _predictedGameLength, int _utilityCharacter) {
    // read the config file to determine version of training and verbose
    verbose = false;
    logEm = false;
    string verbline, logline;
    int trainingDepth;
    ifstream in("alegaatr_config.txt");
    in >> trainingDepth;
    getline(in, verbline);
    cout << "no more than " << trainingDepth << " self play iterations" << endl;
    getline(in, verbline);
    if (verbline == "verbose=true") {
        cout << "verbose mode" << endl;
        verbose = true;
    }
    getline(in, logline);
    if (logline == "logValues=true") {
        cout << "logging values" << endl;
        logEm = true;    
    }
    in.close();

    plyrNum = _plyrNum;
    mg = _mg;
    computeMGThings();

    predictedGameLength = _predictedGameLength; // parameter
    t = 0;

    // cout << "about to read data" << endl;

    // read in the training data
    stringstream fnombre0, fnombre1;
    fnombre0 << "Data_" << _elPartido << "_" << plyrNum << ".txt";
    data0.loadData(fnombre0.str(), trainingDepth, predictedGameLength);

    data0.divideData(dataSameGen, dataDiffGen, predictedGameLength);

    vector<string> genConfig = readGeneratorConfig();
    createGenerators(genConfig);

    // cout << "generators created" << endl;

    // create checker masks
    for (int g = 0; g < generators.size(); g++) {
        for (int i = 0; i < generators.size(); i++) {
            for (int j = 0; j < generators[i]->checkers.size(); j++) {
                if (i == g)
                    generators[g]->checkerMask.push_back(1.0);
                else
                    generators[g]->checkerMask.push_back(0.25);
            }
        }
    }

    utilityCharacter = _utilityCharacter; //3;//SELF_MODE; //rand() % 3;
    if (utilityCharacter == 3)
        theMode = SELF_MODE;//FRIEND_MODE;
    else
        theMode = utilityCharacter;

    cout << "utilityCharacter: " << utilityCharacter << endl;

    // parameters
    lambda = 0.95;
    // setAspirationLevel("coop");
    setAspirationLevel(1.0);
    nbsVal = aspiration;
    for (int i = 0; i < generators.size(); i++) {
        generatorPayouts.push_back(generators[i]->chExpectedPayout);
    }

    expAveReward = aspiration;
    roundPayout = theirRoundPayout = 0.0;
    notSatisfiedCount = 0;

    if (logEm) {
        string fnombre;
        if (plyrNum == 0)
            fnombre = "utilLog0.csv";
        else
            fnombre = "utilLog1.csv";
        logUtils.open(fnombre);

        logUtils << "Round,Generator,Util" << endl;
    }

    currentGenerator = prevGenerator = -1;
    currentGenerator = selectGeneratorGreedily();

    // now, open the file for logging (for continued learning)
    // logstream.open(fnombre0.str(), std::ios_base::app);
    // logstream << fixed;

    wasUsing = "----";
    willUse = generators[currentGenerator]->nickname;
    payoffsSoFar = theirPayoffsSoFar = 0.0;

    // logStatus();

}

AlegAATr::~AlegAATr() {
    for (int i = 0; i < generators.size(); i++) {
        delete generators[i];
    }

    // logstream.close();
    if (logEm) {
        logUtils.close();
    }
}

void AlegAATr::configureTrainingRun() {
    if (utilityCharacter == 3)
        theMode = SELF_MODE; //FRIEND_MODE;
    else
        theMode = utilityCharacter;

    // setAspirationLevel("coop");
    setAspirationLevel(1.0);

    expAveReward = aspiration;
    roundPayout = theirRoundPayout = 0.0;
    notSatisfiedCount = 0;

    currentGenerator = prevGenerator = -1;
    currentGenerator = selectGeneratorGreedily();

    // now, open the file for logging (for continued learning)
    // logstream.open(fnombre0.str(), std::ios_base::app);
    // logstream << fixed;

    wasUsing = "----";
    willUse = generators[currentGenerator]->nickname;
    payoffsSoFar = theirPayoffsSoFar = 0.0;
    t = 0;

    // reset the generators
    for (int i = 0; i < generators.size(); i++)
        generators[i]->restoreFactorySettings();
}

int AlegAATr::makeMove(State *s) {
    lastState = s;

    vector<int> theMoves;
    for (int i = 0; i < generators.size(); i++) {
        theMoves.push_back(generators[i]->Move(s));
    }

    return theMoves[currentGenerator];
}

void AlegAATr::updateAfterMove(State *s, int actions[2]) {
    for (int i = 0; i < generators.size(); i++) {
        generators[i]->moveUpdate(s, actions);
    }
    int jact = lastState->jointCode(actions);

    roundPayout += lastState->rewards[jact][0][plyrNum];
    theirRoundPayout += lastState->rewards[jact][0][1-plyrNum];
}

void AlegAATr::updateRound() {
    if (verbose)
        cout << endl << endl;

    for (int i = 0; i < generators.size(); i++) {
        if ((i == currentGenerator) || (i == prevGenerator))
            generators[i]->roundUpdate(true);
        else
            generators[i]->roundUpdate(false);
        // cout << "\nCheckers for " << generators[i]->nickname << " (" << generators[i]->checkers.size() << ")" << endl;
        // for (int j = 0; j < generators[i]->checkers.size(); j++) {
        //     generators[i]->checkers[j]->print();
        // }
    }
    t++;

    payoffsSoFar += roundPayout;
    theirPayoffsSoFar += theirRoundPayout;
    roundPayout = theirRoundPayout = 0.0;

    // decide which mode to be in
    if (utilityCharacter == CHANGER) {
        // if ((t <= 2) || (payoffsSoFar > (0.8 * nbsVal * t))) {
        //     cout << "Friend Mode" << endl;
        //     theMode = FRIEND_MODE;
        // }
        // else 
        if ((t > 5) && (payoffsSoFar < (0.65 * theirPayoffsSoFar))){
            if (verbose)
                cout << "Competitor Mode" << endl;
            theMode = COMPETITOR_MODE;
        }
        else {
            if (verbose)
                cout << "Self Mode" << endl;
            theMode = SELF_MODE;
        }
    }

    prevGenerator = currentGenerator;

    // if (generators[currentGenerator]->lock) {
    //     selectGeneratorGreedily();
    //     if (verbose)
    //         cout << "generator " << currentGenerator << " has a lock (" << generators[currentGenerator]->lockCount << ")" << endl;
    // }
    // else {
        currentGenerator = selectGeneratorGreedily();
    // }

    wasUsing = generators[prevGenerator]->nickname;
    willUse = generators[currentGenerator]->nickname;

    // logStatus();

    if ((prevGenerator != currentGenerator) && strncmp(generators[currentGenerator]->nickname, "cfr", 3)) {
        ((Xprt *)generators[currentGenerator])->ab->xprts[0]->guilt = 0.0;
        ((Xprt *)generators[currentGenerator])->ab->xprts[0]->betrayed = false;
    }
}

int AlegAATr::selectGeneratorGreedily() {
    vector<double> curAATState = getCurrentAATState();

    cout << fixed;
    cout << setprecision(1);

    vector<double> utils = getAATAssessments(&dataSameGen, curAATState, t, theMode);
    if (verbose && (t < predictedGameLength)) {
        cout << "     actual:     ";
        for (int i = 0; i < generators.size(); i++)
            cout << (utils[i] / (predictedGameLength - t)) << " ";
        cout << endl;
    }

    int select = argMax(utils);
    if (verbose && (t < predictedGameLength))
        cout << "chose " << select << endl;

    if (logEm && (t < predictedGameLength)) {
        for (int i = 0; i < generators.size(); i++) {
            // logUtils << t << "," << generators[i]->nickname << "," << (utils[i] + payoffsSoFar) << endl;
            logUtils << (t+1) << "," << generators[i]->nickname << "," << utils[i] / (predictedGameLength - t) << endl;
        }
    }

    return select;
}

double AlegAATr::getMax(vector<double> utils) {
    double mx = utils[0];
    for (int i = 1; i < utils.size(); i++) {
        if (utils[i] > mx)
            mx = utils[i];
    }

    return mx;
}

int AlegAATr::argMax(vector<double> utils) {
    double mx = utils[0];
    int mxInd = 0;
    for (int i = 1; i < utils.size(); i++) {
        if (utils[i] > mx) {
            mx = utils[i];
            mxInd = i;
        }
    }

    return mxInd;
}

// int AlegAATr::argMax(vector<utilityPair> utils) {
//     double mx = utils[0].util;
//     int mxInd = 0;
//     for (int i = 1; i < utils.size(); i++) {
//         if (utils[i].util > mx) {
//             mx = utils[i].util;
//             mxInd = i;
//         }
//     }

//     return mxInd;
// }

vector<double> AlegAATr::getAATAssessments(DataSet *data, vector<double> estado, int tiempo, int elModo) {
    vector<double> utils;

    for (int i = 0; i < generators.size(); i++) {
        utils.push_back(data->computeUtility(estado, tiempo, generators[i]->checkerMask, generators[i]->nickname, elModo, predictedGameLength, aspiration));        
    }

    return utils;
}

vector<double> AlegAATr::getCurrentAATState() {
    vector<double> elEstado;

    for (int i = 0; i < generators.size(); i++) {
        for (int j = 0; j < generators[i]->checkers.size(); j++) {
            elEstado.push_back(generators[i]->checkers[j]->val);
            if (verbose) {
                cout << generators[i]->checkers[j]->nombre << ": ";
                printf("%.2lf\n", generators[i]->checkers[j]->val);
            }
        }
    }

    return elEstado;
}

void AlegAATr::setAspirationLevel(string genStr) {
    for (int i = 0; i < generators.size(); i++) {
        string str = generators[i]->nickname;
        if (str == genStr) {
            aspiration = generators[i]->chExpectedPayout;
            if (verbose)
                cout << "aspiration level set at: " << aspiration << endl;
            return;
        }
    }

    cout << "don't know how to set the aspiration level: " << genStr << endl;
    exit(1);
}

void AlegAATr::setAspirationLevel(double propOfCoop) {
    for (int i = 0; i < generators.size(); i++) {
        string str = generators[i]->nickname;
        if (str == "coop") {
            aspiration = generators[i]->chExpectedPayout * propOfCoop;
            if (verbose)
                cout << "aspiration level set at: " << aspiration << endl;
            return;
        }
    }

    cout << "don't know how to set the aspiration level: " << propOfCoop << endl;
    exit(1);
}

// void AlegAATr::createGenerators(vector<string> genConfig) {
//     char tipito[1024];

//     for (int i = 0; i < genConfig.size(); i++) {
//         cout << "Generator: " << genConfig[i] << endl;
//         if (genConfig[i] == "cfr") {
//             generators.push_back(new CFR(plyrNum, mg, 40, false));
//         }
//         else if (genConfig[i] == "maxmin") {
//             strcpy(tipito, "maxmin");
//             generators.push_back(new Xprt(plyrNum, mg, tipito));
//         }
//         else if (genConfig[i] == "coop") {
//             strcpy(tipito, "coop");
//             generators.push_back(new Xprt(plyrNum, mg, tipito));
//         }
//         else if (genConfig[i] == "coopp") {
//             strcpy(tipito, "coopp");
//             generators.push_back(new Xprt(plyrNum, mg, tipito));
//         }
//         else if (genConfig[i] == "bullyp") {
//             strcpy(tipito, "bullyp");
//             generators.push_back(new Xprt(plyrNum, mg, tipito));
//         }
//         else if (genConfig[i] == "bullied") {
//             strcpy(tipito, "bullied");
//             generators.push_back(new Xprt(plyrNum, mg, tipito));
//         }
//         else {
//             cout << "generator " << genConfig[i] << " not found" << endl;
//         }
//     }
// }

// vector<string> AlegAATr::readGeneratorConfig() {
//     vector<string> genConfig;

//     stringstream ss;
//     ss << "configGens";
//     ss << plyrNum;
//     ss << ".txt";
//     ifstream input(ss.str());

//     string line;
//     while (!input.eof()) {
//         getline(input, line);
//         if (line.length() > 1)
//             genConfig.push_back(line);
//         else
//             break;
//     }

//     input.close();

//     return genConfig;
// }

void AlegAATr::logStatus() {
    logstream << (data0.theData.size() / (predictedGameLength+1)) << ",";
    logstream << t << ",";
    logstream << wasUsing << ",";
    // logstream << willUse << ",";
    logstream << payoffsSoFar << ",";
    logstream << theirPayoffsSoFar << ",";
    double expectedPayoffs2Go = (EXPECTED_ROUNDS - t) * generators[currentGenerator]->chExpectedPayout;
    logstream << expectedPayoffs2Go << ",";
    for (int i = 0; i < generators.size(); i++) {
        for (int j = 0; j < generators[i]->checkers.size(); j++) {
            generators[i]->checkers[j]->print2File(logstream);
        }
    }
    logstream << endl;
}

