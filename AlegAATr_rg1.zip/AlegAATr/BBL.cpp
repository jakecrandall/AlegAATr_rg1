#include "BBL.h"

BBL::BBL() {
    cout << "incomplete BBL constructor" << endl;
    exit(1);
}

BBL::BBL(int _plyrNum, MarkovGame *_mg, string partido, int _predictedGameRounds) {
    plyrNum = _plyrNum;
    mg = _mg;
    predictedGameRounds = _predictedGameRounds;
    computeMGThings();

    vector<string> genConfig = readGeneratorConfig();
    createGenerators(genConfig);

    theirMG = new MarkovGame(partido.c_str());
    cout << "computing their thing" << endl;
    computeTheirMGThings();
    cout << "computing their generators" << endl;
    createTheirGenerators(genConfig);

    t = 0;

    for (int i = 0; i < generators.size(); i++) {
        typeKappa.push_back(1.0);
        probsThisRound.push_back(1.0);
    }

    readMatrixOutcomes(partido);

    currentGenerator = selectGeneratorGreedy(t);

    inARow = 0;
}

BBL::~BBL() {
    for (int i = 0; i < generators.size(); i++) {
        delete generators[i];
    }

    delete theirMG;
}

int BBL::makeMove(State *s) {
    lastState = s;

    vector<int> theMoves;
    for (int i = 0; i < generators.size(); i++) {
        // cout << "me: " << plyrNum << "; ";
        theMoves.push_back(generators[i]->Move(s));
        // cout << "them: ";
        theirGenerators[i]->Move(s);
    }

    return theMoves[currentGenerator];
}

void BBL::updateAfterMove(State *s, int actions[2]) {
    for (int i = 0; i < generators.size(); i++) {
        generators[i]->moveUpdate(s, actions);
       theirGenerators[i]->moveUpdate(s, actions);
    }

    for (int i = 0; i < generators.size(); i++) {
        if (theirGenerators[i]->actionConsiderations.find(actions[1-plyrNum]) != theirGenerators[i]->actionConsiderations.end()) {
            // if (i == 4) {
            //     // cout << "    played: " << actions[1-plyrNum] << endl;
            //     cout << "    moveProb: " << theirGenerators[i]->actionConsiderations[actions[1-plyrNum]] << endl;
            // }
            probsThisRound[i] *= theirGenerators[i]->actionConsiderations[actions[1-plyrNum]];
        }
        else {
            probsThisRound[i] = 0.0;
        }
    }
}

void BBL::updateRound() {
    for (int i = 0; i < generators.size(); i++) {
        if (i == currentGenerator) {
            generators[i]->roundUpdate(true);
            theirGenerators[i]->roundUpdate(true);
        }
        else {
            generators[i]->roundUpdate(false);
            theirGenerators[i]->roundUpdate(false);
        }
    }

    cout << "  prob type: ";
    for (int i = 0; i < generators.size(); i++) {
        cout << probsThisRound[i] << " ";
    }
    cout << endl;
    cout << "  typeKappas: ";
    for (int i = 0; i < generators.size(); i++) {
        if (probsThisRound[i] > 0.0) {
            if (!strcmp(generators[i]->nickname, "coop")) {
                if (probsThisRound[i] < 0.11) {
                    if (inARow == 0)
                        typeKappa[i] += t+1;
                    
                    inARow ++;

                }
                else {
                    typeKappa[i] += t+1;
                    inARow = 0;
                }
            }
            else {
                typeKappa[i] += t+1; //1.0;
            }
        }
        else if (!strcmp(generators[i]->nickname, "coop"))
            inARow = 0;
        cout << typeKappa[i] << " ";
    }
    cout << endl;

    int prevGenerator = currentGenerator;
    currentGenerator = selectGeneratorGreedy(t+1);
    if ((prevGenerator != currentGenerator) && strncmp(generators[currentGenerator]->nickname, "cfr", 3)) {
        ((Xprt *)generators[currentGenerator])->ab->xprts[0]->guilt = 0.0;
        ((Xprt *)generators[currentGenerator])->ab->xprts[0]->betrayed = false;
    }

    // reset round probs
    for (int i = 0; i < generators.size(); i++) {
        probsThisRound[i] = 1.0;
    }
    t++;
}

int BBL::selectGeneratorGreedy(int _tiempo) {
    if (_tiempo >= predictedGameRounds)
        return currentGenerator;

    int count = 0;
    for (int i = 0; i < generators.size(); i++) {
        count += typeKappa[i];
    }

    vector<double> probs;
    for (int i = 0; i < generators.size(); i++) {
        probs.push_back(typeKappa[i] / (double)count);
    }

    vector<double> vals;
    int mxInd = 0;
    cout << "   Utils: ";
    for (int i = 0; i < generators.size(); i++) {
        vals.push_back(0.0);
        for (int j = 0; j < generators.size(); j++) {
            if (plyrNum == 0)
                vals[i] += gengenOutcomes[predictedGameRounds - (_tiempo+1)][i][j] * probs[j];
            else
                vals[i] += gengenOutcomes[predictedGameRounds - (_tiempo+1)][j][i] * probs[j];
        }
        cout << vals[i] << " ";
        if (vals[i] > vals[mxInd])
            mxInd = i;
    }
    cout << endl;

    cout << "    select " << mxInd << endl;


    return mxInd;
}

void BBL::readMatrixOutcomes(string partido) {
    for (int r = 0; r < 20; r++) {
        stringstream ff;
        ff << "../Train/payoffs_" << plyrNum << "_" << partido << "_" << (r+1) << ".txt";
        string fnombre = ff.str();
        ifstream input(fnombre);

        if (!input) {
            cout << "gengen payoffs not found" << endl;
            exit(1);
        }

        for (int i = 0; i < generators.size(); i++) {
            for (int j = 0; j < generators.size(); j++) {
                input >> gengenOutcomes[r][i][j];
            }
        }

        input.close();
    }
}

void BBL::computeTheirMGThings() {
    theirMG->solveZero(1-plyrNum);
    theirMG->solveZero(plyrNum);
    
    // reset qvals;
    int s, i, j;
    for (s = 0; s < theirMG->numStates; s++) {
        for (i = 0; i < theirMG->states[s]->numActions[0]; i++) {
            for (j = 0; j < theirMG->states[s]->numActions[1]; j++) {
                theirMG->states[s]->qsets[0]->Qs[i][j] = 0.0;
            }
        }
        theirMG->states[s]->qsets[0]->V = 0.0;
    }

    theirMG->solveAttack(plyrNum);
    theirMG->solveAttack(1-plyrNum);
    
    double w[2];
    for (w[0] = theirMG->wvals[0]; w[0] < theirMG->wvals[1] + 0.000001; w[0] += theirMG->wvals[2]) {
        w[1] = 1.0 - w[0];
        theirMG->vIteration(w[0], w[1]);
    }
}

void BBL::createTheirGenerators(vector<string> genConfig) {
    char tipito[1024];

    for (int i = 0; i < genConfig.size(); i++) {
        cout << "Generator: " << genConfig[i] << endl;
        if (genConfig[i] == "cfr") {
            theirGenerators.push_back(new CFR(1-plyrNum, theirMG, 40, false));
        }
        else if (genConfig[i] == "maxmin") {
            strcpy(tipito, "maxmin");
            theirGenerators.push_back(new Xprt(1-plyrNum, theirMG, tipito));
        }
        else if (genConfig[i] == "coop") {
            strcpy(tipito, "coop");
            theirGenerators.push_back(new Xprt(1-plyrNum, theirMG, tipito, false));
        }
        else if (genConfig[i] == "coopp") {
            strcpy(tipito, "coopp");
            theirGenerators.push_back(new Xprt(1-plyrNum, theirMG, tipito, false));
        }
        else if (genConfig[i] == "bullyp") {
            strcpy(tipito, "bullyp");
            theirGenerators.push_back(new Xprt(1-plyrNum, theirMG, tipito, false));
        }
        else if (genConfig[i] == "bullied") {
            strcpy(tipito, "bullied");
            theirGenerators.push_back(new Xprt(1-plyrNum, theirMG, tipito, false));
        }
        else {
            cout << "generator " << genConfig[i] << " not found" << endl;
        }
    }
}

