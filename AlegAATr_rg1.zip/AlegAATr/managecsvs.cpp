#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>

using namespace std;


vector<string> splitString(string line, string delimiter) {
    vector<string> palabras;
    string token;
    int posStart = 0;
    int posEnd = line.find(delimiter, posStart);
    while (posEnd != string::npos) {
        token = line.substr(posStart, posEnd - posStart);
        posStart = posEnd + 1;
        palabras.push_back(token);
        posEnd = line.find(delimiter, posStart);
    }

    palabras.push_back(line.substr(posStart));

    return palabras;
}

void extractData(string fnombre, const string partido, const double nbsVal, ofstream &output) {
    ifstream input(fnombre);

    string line;
    getline(input, line);
    while (getline(input, line)) {
        vector<string> palabras = splitString(line, ",");

        output << partido << "," << palabras[0] << "," << (stof(palabras[2]) / nbsVal) << endl;
        output << partido << "," << palabras[1] << "," << (stof(palabras[3]) / nbsVal) << endl;
    }

    input.close();
}

int main() {
    ofstream output("../Results_i1/all.csv");

    output << "Game,Algorithm,Value" << endl;

    extractData("../Results_i1/blockDilemma.csv", "blockDilemma", 2500.0, output);
    extractData("../Results_i1/prisoners.csv", "prisoners", 1200.0, output);
    extractData("../Results_i1/chicken.csv", "chicken", 1680.0, output);

    output.close();

    return 0;
}