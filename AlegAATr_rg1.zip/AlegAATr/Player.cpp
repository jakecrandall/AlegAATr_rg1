#include "Player.h"

Player::Player() {
    strcpy(nickname, "null");
}

Player::~Player() {
    for (int i = 0; i < checkers.size(); i++) {
        delete checkers[i];
    }
}

void Player::Reset() {
    asExpected = false;
}

void Player::restoreFactorySettings() {
}

int Player::Move(State *s) {
    printf("virtual move\n");
	return 0;
}

int Player::moveUpdate(State *s, int actions[2]) {
	printf("virtual update\n");
    
    return 0;
}

int Player::roundUpdate(bool wasUsed) {
	printf("virtual update\n");
    
    return 0;    
}

void Player::print(int config, int x1, int y1, int x2, int y2) {
}

void Player::updateChecker(string _nombre, double value, double rate) {
    for (int i = 0; i < checkers.size(); i++) {
        if (checkers[i]->nombre == _nombre)
            checkers[i]->update(value, rate);
    }
}

void Player::setChecker(string _nombre, double value) {
    for (int i = 0; i < checkers.size(); i++) {
        if (checkers[i]->nombre == _nombre) {
            checkers[i]->val = value;
            checkers[i]->timesUpdated ++;
        }
    }
}
