#ifndef EEE_H
#define EEE_H

#include "defs.h"
#include "AbstractAlegAATr.h"
#include "MarkovGame.h"
#include "State.h"
#include "CFR.h"
#include "Xprt.h"

using namespace std;

class EEE : public AbstractAlegAATr {
public:
    EEE();
    EEE(int _plyrNum, MarkovGame *_mg);
    ~EEE();

    int makeMove(State *s);
    void updateAfterMove(State *s, int actions[2]);
    void updateRound();

    int selectGeneratorGreedily();

private:
    int t;
    State *lastState;

    int rndsInCycle, cycleCount;
    vector<double> vals;
    vector<int> counts;
    double roundPayout;
};

#endif