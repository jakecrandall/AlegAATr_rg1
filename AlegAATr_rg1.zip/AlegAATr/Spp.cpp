#include "Spp.h"

Spp::Spp() {
    cout << "incomplete Spp constructor" << endl;
    exit(1);
}

Spp::Spp(int _plyrNum, MarkovGame *_mg) {
    mg = _mg;
    plyrNum = _plyrNum;
    computeMGThings();

    vector<string> genConfig = readGeneratorConfig();
    createGenerators(genConfig);

    t = 0;

    setAspirationLevel("coop");
    lambda = 0.975;

    roundPayouts[0] = roundPayouts[1] = 0.0;
    totalPayouts[0] = totalPayouts[1] = 0.0;
    cyclePayout = 0.0;
    cycleCount = 0;

    currentGenerator = -1;
    double high = -99999;
    for (int i = 0; i < generators.size(); i++) {
        if (generators[i]->chExpectedPayout > high)
            high = generators[i]->chExpectedPayout;

        if (!strcmp(generators[i]->nickname, "cfr")) {
            currentGenerator = brIndex = i;
        }
        if (!strcmp(generators[i]->nickname, "maxmin")) {
            mmIndex = i;
        }
    }
    cout << "high: " << high << endl;
    for (int i = 0; i < generators.size(); i++) {
        xphi.push_back(high);
        kappa.push_back(0);
    }

    if (currentGenerator < 0) {
        cout << "didn't find cfr" << endl;
        exit(1);
    }

    // currentGenerator = rand() % generators.size();
}

Spp::~Spp() {
    for (int i = 0; i < generators.size(); i++) {
        delete generators[i];
    }
}

int Spp::makeMove(State *s) {
    lastState = s;

    vector<int> theMoves;
    for (int i = 0; i < generators.size(); i++) {
        theMoves.push_back(generators[i]->Move(s));
    }

    return theMoves[currentGenerator];
}

void Spp::updateAfterMove(State *s, int actions[2]) {
    for (int i = 0; i < generators.size(); i++) {
        generators[i]->moveUpdate(s, actions);
    }
    int jact = lastState->jointCode(actions);

    roundPayouts[0] += lastState->rewards[jact][0][0];
    roundPayouts[1] += lastState->rewards[jact][0][1];
}

void Spp::updateRound() {
    // cout << "  xphi: ";
    for (int i = 0; i < generators.size(); i++) {
        if (i == currentGenerator) {
            generators[i]->roundUpdate(true);
            kappa[i] ++;
            double beta = 1.0 / kappa[i];
            double other = 2.0 * (1.0 - lambda);
            if (other > beta)
                beta = other;
            // cout << "beta: " << beta << endl;
            xphi[i] = (1 - beta) * xphi[i] + beta * roundPayouts[plyrNum];
        }
        else
            generators[i]->roundUpdate(false);
        // cout << xphi[i] << " (" << kappa[i] << ")  ";
    }
    // cout << endl;

    cycleCount ++;
    cyclePayout += roundPayouts[plyrNum];
    totalPayouts[0] += roundPayouts[0];
    totalPayouts[1] += roundPayouts[1];

    // determine if cycled
    int outcome = determineOutcome(roundPayouts);
    if (cycled(outcome)) {
        double rBar = cyclePayout / cycleCount;
        // cout << "  cycled: " << rBar << " (" << cyclePayout << "; " << cycleCount << ")" << endl;
        double lambdaPrime = pow(lambda, cycleCount);
        // cout << "  aspiration: " << aspiration << endl;
        rho = pow(rBar / aspiration, cycleCount);
        if (rho > 1.0)
            rho = 1.0;
        if (rBar < 0.0)
            rho = 0.0;
        aspiration = lambdaPrime * aspiration + (1-lambdaPrime) * rBar;
        // cout << "  aspiration = " << aspiration << endl;

        selectTheGenerator();

        cycleCount = 0;
        cyclePayout = 0.0;
        outcomeHistory.clear();
        outcomeHistory.insert(outcome);
    }

    roundPayouts[0] = roundPayouts[1] = 0.0;
    t++;
}

void Spp::selectTheGenerator() {
    double num = rand() / (double)RAND_MAX;
    // cout << "  rho = " << rho << "; num = " << num << endl;
    if (num < (1.0 - rho)) {

        // see if we have a safety override
        if (totalPayouts[plyrNum] < ((mg->states[0]->mm[plyrNum]->mv * (t+1)) - 100)) {
            // cout << "**************** Spp Safety Override ******************" << endl;
            currentGenerator = mmIndex;
            return;
        }

        // see if we have a best-response override
        if ((generators[brIndex]->chExpectedPayout >= aspiration) && brBest()) {
            // cout << "**************** BR Override ******************" << endl;
            currentGenerator = brIndex;
            return;
        }

        // cout << "**************** NO Override ******************" << endl;

        // compute potentials and find satisficing set        
        vector<double> potentials;
        vector<int> satSet;
        // cout << "  potentials: ";
        for (int i = 0; i < generators.size(); i++) {
            double v = generators[i]->chExpectedPayout;
            potentials.push_back(v);
            // cout << v << " ";
            if (v >= aspiration)
                satSet.push_back(i);
        }
        // cout << endl;

        // cout << "  satisficing set: ";
        // for (vector<int>::iterator itr = satSet.begin(); itr != satSet.end(); itr++) {
        //     cout << *itr << " ";
        // }
        // cout << endl;

        currentGenerator = satSet[rand() % satSet.size()];
        
        // cout << "    selected: " << currentGenerator << endl;
    }
}

bool Spp::brBest() {
    for (int i = 0; i < generators.size(); i++) {
        if (i == brIndex)
            continue;

        if ((kappa[i] > 0) && (xphi[i] > xphi[brIndex]))
            return false;
    }

    return true;
}

// *****************************************************
// 
//  Possible outcomes:
//      0: both less than mx
//      1: 0 less than mx, 1 greater than mx
//      2: 1 less than mx, 0 greter than mx
//      3: NBS
//      4: 0 > NBS; 1 < NBS
//      5: 1 > NBS; 0 < NBS
//      6: otherwise (dominated)
// 
//  ****************************************************
int Spp::determineOutcome(double roundPayouts[2]) {
    // cout << "  roundPayouts: " << roundPayouts[0] << ", " << roundPayouts[1] << endl;
    if ((roundPayouts[0] <= mg->states[0]->mm[0]->mv) && (roundPayouts[1] <= mg->states[0]->mm[1]->mv)) {
        // cout << "  outcome 0: both <= mx" << endl;
        return 0;
    }
    else if ((roundPayouts[0] <= mg->states[0]->mm[0]->mv) && (roundPayouts[1] > mg->states[0]->mm[1]->mv)) {
        // cout << "  outcome 1: 0 <= mx; 1 > mx" << endl;
        return 1;
    }    
    else if ((roundPayouts[0] > mg->states[0]->mm[0]->mv) && (roundPayouts[1] <= mg->states[0]->mm[1]->mv)) {
        // cout << "  outcome 2: 0 > mx; 1 <= mx" << endl;
        return 2;
    }    
    else if ((roundPayouts[0] == nbsVal[0]) && (roundPayouts[1] == nbsVal[1])) {
        // cout << "  outcome 3: NBS" << endl;
        return 3;
    }
    else if ((roundPayouts[0] <= nbsVal[0]) && (roundPayouts[1] > nbsVal[1])) {
        // cout << "  outcome 4: 0 <= NBS; 1 > NBS" << endl;
        return 4;
    }    
    else if ((roundPayouts[0] > nbsVal[0]) && (roundPayouts[1] <= nbsVal[1])) {
        // cout << "  outcome 5: 0 > NBS; 1 <= NBS" << endl;
        return 5;
    }    

    // cout << "  outcome 6: otherwise" << endl;

    return 6;
}

bool Spp::cycled(int outcome) {
    if (outcomeHistory.find(outcome) != outcomeHistory.end())
        return true;
    
    outcomeHistory.insert(outcome);
    return false;
}

void Spp::setAspirationLevel(string genStr) {
    for (int i = 0; i < generators.size(); i++) {
        string str = generators[i]->nickname;
        if (str == genStr) {
            aspiration = generators[i]->chExpectedPayout;
            cout << "aspiration level set at: " << aspiration << endl;
            nbsVal[0] = ((Xprt *)(generators[i]))->ab->xprts[0]->barR[0];
            nbsVal[1] = ((Xprt *)(generators[i]))->ab->xprts[0]->barR[1];
            cout << "nbsVals = " << nbsVal[0] << ", " << nbsVal[1] << endl;
            return;
        }
    }

    cout << "don't know how to set the aspiration level: " << genStr << endl;
    exit(1);
}

