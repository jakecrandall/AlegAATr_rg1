#ifndef DEFS_H
#define DEFS_H

#include <iostream>
#include <fstream>
#include <sstream>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <unistd.h>
#include <vector>
#include <chrono>

#include <set>
#include <vector>
#include <map>

#define NUMACTIONS          9
#define MAX_ROUNDS          100
#define MAX_QSETS           11

#define EXPECTED_ROUNDS     20

#define FRIEND_MODE      0
#define SELF_MODE        1
#define COMPETITOR_MODE  2
#define CHANGER          3


#endif