#ifndef DATASET_H
#define DATASET_H

#include "defs.h"
#include <queue>
#include "Player.h"

using namespace std;

struct DataEntry {
    DataEntry() {
        cout << "incomplete DataEntry constructor" << endl;
        exit(1);
    }

    DataEntry(string line) {
        vector<string> palabras = splitString(line, ",");

        // for (int i = 0; i < palabras.size(); i++) {
        //     cout << palabras[i] << endl;
        // }

        id = stoi(palabras[0]);
        t = stoi(palabras[1]);
        genName = palabras[2];
        perfSoFar = stof(palabras[3]);
        theirPerfSoFar = stof(palabras[4]);
        predictedPerf2Go = stof(palabras[5]);

        // cout << "predictedPerf2Go: " << predictedPerf2Go << endl;

        for (int i = 6; i < palabras.size(); i++) {
            // cout << "<" << palabras[i] << "> (" << palabras[i].length() << ")" << endl;
            if (palabras[i].length() > 0)
                checkerVals.push_back(stof(palabras[i]));
        }
    }

    ~DataEntry() {}

    double getDistance(vector<double> estado, int _t, vector<double> mask) {
        if (estado.size() != checkerVals.size()) {
            cout << "state sizes differ" << endl;
            exit(1);
        }

        double dist = 0.0;
        for (int i = 0; i < estado.size(); i++) {
            dist += mask[i] * fabs(estado[i] - checkerVals[i]);
        }
        dist += (1.0 / 5.0) * abs(t - _t);
        // dist += (1.0 / 2.5) * abs(t - _t);

        return dist;
    }

    double getDistance2(vector<double> estado, int _t, vector<double> mask) {
        if (estado.size() != checkerVals.size()) {
            cout << "state sizes differ" << endl;
            exit(1);
        }

        double dist = 0.0;
        for (int i = 0; i < estado.size(); i++) {
            dist += mask[i] * fabs(estado[i] - checkerVals[i]);
        }
        dist += (1.0 / 20.0) * abs(t - _t);

        return dist;
    }

    vector<string> splitString(string line, string delimiter) {
        vector<string> palabras;
        string token;
        int posStart = 0;
        int posEnd = line.find(delimiter, posStart);
        while (posEnd != string::npos) {
            token = line.substr(posStart, posEnd - posStart);
            posStart = posEnd + 1;
            palabras.push_back(token);
            posEnd = line.find(delimiter, posStart);
        }

        palabras.push_back(line.substr(posStart));

        return palabras;
    }

    int t, id;
    string genName;
    double perfSoFar, theirPerfSoFar, predictedPerf2Go;//, ratioOfActual;
    int endIndex;
    vector<double> checkerVals;
};

struct pqNode {
    // data members
    int index;
    double dist;

    // comparitor function
    bool operator() (pqNode const& p1, pqNode const& p2) {
        if (p1.dist == p2.dist)
            return rand() % 2;
        else
            return p1.dist > p2.dist;
    }
};

class DataSet {
public:
    DataSet() {}
    ~DataSet() {}

    void loadData(string _fnombre, int trainingDepth, int predictedGameLength) {
        // cout << "get data from " << _fnombre << endl;
        ifstream input(_fnombre);

        if (!input) {
            cout << "File not found: " << _fnombre << endl;
            exit(1);
        }

        // assumes 360 training samples
        int numSamples = 0;
        int sampleMax = (1800 + trainingDepth * 360) * (predictedGameLength+1);

        string line;
        while (!input.eof()) {
            getline(input, line);
            if (line.length() > 1) {
                DataEntry dEntry(line);
                theData.push_back(dEntry);

                numSamples ++;
                if (numSamples >= sampleMax)
                    break;
            }
            else {
                break;
            }
        }

        input.close();

        cout << "Data entries: " << theData.size() << endl;

        // compute the actual2predictedRatios
        int ind;
        double actualGain;
        for (int i = 0; i < theData.size(); i++) {
            theData[i].endIndex = getIndexOfActual2GoPayout(i);
            // cout << "entry: " << i << "; end: " << theData[i].endIndex << endl;
            // actualGain = theData[ind].perfSoFar - theData[i].perfSoFar;
            // if (theData[i].predictedPerf2Go != 0.0)
            //     theData[i].ratioOfActual = actualGain / theData[i].predictedPerf2Go;
            // else
            //     theData[i].ratioOfActual = 1.0;            
            // cout << "end indices for " << i << " is " << ind << " (" << theData[ind].perfSoFar << ")" << endl;
            // cout << "     " << theData[i].ratioOfActual << endl;
        }

        // cout << "end: " << theData[3834].endIndex << endl;
    }

    int getIndexOfActual2GoPayout(int entry) {
        int i = entry+1;
        // while ((i < theData.size()) && (theData[i].t > theData[entry].t))
        while ((i < theData.size()) && (theData[i].id == theData[entry].id))
            i++;

        return i-1;
    }

    double computeUtility(vector<double> curAATState, int t, vector<double> mask, string _genStr, int elModo, int predictedGameLength, double _aspiration) {
        int j = 0;
        double util = 0.0, mag = 0.0, gain, w, distancia;
        for (int i = 0; i < theData.size()-1; i++) {
            if ((theData[i].genName == _genStr) || ((theData[i].genName == "----") && (theData[i+1].genName == _genStr))) {
                if (theData[i].t == predictedGameLength)
                    continue;
                distancia = theData[i].getDistance(curAATState, t, mask);
                w = getWeight(distancia);
                mag += w;
                if (elModo == FRIEND_MODE)
                    gain = sampleReturn_Friend(i, predictedGameLength - t);
                else if (elModo == SELF_MODE) {
                    gain = sampleReturn_Self(i, predictedGameLength - t);
                    // if ((_genStr == "cfr") && (gain < 20.0)) {
                    //     cout << "sample " << theData[i].id << " " << theData[i].t << ": " << gain << endl;
                    // }
                }
                else {
                    gain = sampleReturn_Competitor(i, predictedGameLength - t);
                }

                gain *= (predictedGameLength - t);
                util += w * gain;

                j++;
            }
        }

        if (mag == 0.0) {
            cout << "something's a miss" << endl;
            exit(1);
        }

        util /= mag;

        return util;
    }

    vector<pqNode> kNN(vector<double> curAATState, int t, vector<double> mask, string _curGen, string _newGen, int k) {
        // vector<double> mask;
        // for (int i = 0; i < curAATState.size(); i++)
        //     mask.push_back(1.0);

        // cout << "_curGen: " << _curGen << endl;
        // cout << "_newGen: " << _newGen << endl;

        priority_queue<pqNode, vector<pqNode>, pqNode> pqueue;

        for (int i = 0; i < theData.size()-1; i++) {
            if ((theData[i].genName == _curGen) && (theData[i+1].genName == _newGen) && (theData[i].id == theData[i+1].id)) {
                pqNode n;
                n.index = i;
                n.dist = theData[i].getDistance(curAATState, t, mask);
                pqueue.push(n);
            }
        }

        // cout << "zeroCount: " << zeroCount << endl;
        // cout << "pqueue size: " << pqueue.size() << endl;

        vector<pqNode> nearestNeighbors;
        int i = 0;
        double lastDist = -1;
        while ((i < k) || ((pqueue.top().dist == lastDist)) && (pqueue.size() > 0)) {
            pqNode n = pqueue.top();
            pqueue.pop();

            // cout << "pqueue size: " << pqueue.size() << endl;
            // cout << "   Node " << n.index << " selected with distance " << n.dist << endl;
            // cout << "       t = " << theData[n.index].t << endl;
            nearestNeighbors.push_back(n);
            lastDist = n.dist;
            i++;
        }

        // cout << "number of neighbors: " << nearestNeighbors.size() << endl;

        return nearestNeighbors;
    }

    vector<pqNode> kNN(vector<double> curAATState, int t, vector<double> mask, string _genStr, int k) {
        // cout << "get the current nearest neighbors for generator " << _genStr << endl;

        priority_queue<pqNode, vector<pqNode>, pqNode> pqueue;

        for (int i = 0; i < theData.size()-1; i++) {
            if ((theData[i].genName == _genStr) || ((theData[i].genName == "----") && (theData[i+1].genName == _genStr))) {
                pqNode n;
                n.index = i;
                n.dist = theData[i].getDistance(curAATState, t, mask);
                pqueue.push(n);
            }
        }

        // cout << "zeroCount: " << zeroCount << endl;
        // cout << "pqueue size: " << pqueue.size() << endl;

        vector<pqNode> nearestNeighbors;
        int i = 0;
        double lastDist = -1;
        while ((i < k) || ((pqueue.top().dist == lastDist)) && (pqueue.size() > 0)) {
            pqNode n = pqueue.top();
            pqueue.pop();

            // cout << "   Node " << n.index << " selected with distance " << n.dist << endl;
            // cout << "       t = " << theData[n.index].t << endl;
            nearestNeighbors.push_back(n);
            lastDist = n.dist;
            i++;
        }

        // cout << "number of neighbors: " << nearestNeighbors.size() << endl;

        return nearestNeighbors;
    }

    vector<pqNode> kNN2(vector<double> curAATState, int t, vector<double> mask, string _genStr, int k) {
        // cout << "get the current nearest neighbors for generator " << _genStr << endl;
        vector<pqNode> nearestNeighbors;
        if (theData.size() < 1)
            return nearestNeighbors;

        priority_queue<pqNode, vector<pqNode>, pqNode> pqueue;

        // cout << "kNN2" << endl;
        // cout << theData.size() << endl;

        for (int i = 0; i < theData.size()-1; i++) {
            if ((theData[i+1].genName == _genStr) && (theData[i].t >= 0)) {
                pqNode n;
                n.index = i;
                n.dist = theData[i].getDistance2(curAATState, t, mask);
                pqueue.push(n);
            }
        }

        // cout << "pqueue size: " << pqueue.size() << endl;

        if (pqueue.size() > 0) {
            int i = 0;
            double lastDist = -1;
            while ((pqueue.size() > 0) && ((i < k) || (pqueue.top().dist == lastDist))) {
                pqNode n = pqueue.top();
                pqueue.pop();

                // cout << "   Node " << n.index << " selected with distance " << n.dist << endl;
                // cout << "       t = " << theData[n.index].t << endl;
                nearestNeighbors.push_back(n);
                lastDist = n.dist;
                i++;
            }
        }

        // cout << "number of neighbors: " << nearestNeighbors.size() << endl;

        return nearestNeighbors;
    }

    double samplePerfPredict(int entry, int rounds2Go) {
        int lookAhead = rounds2Go;
        if (rounds2Go > (theData[entry].endIndex - entry))
            lookAhead = theData[entry].endIndex - entry;
        // cout << "    " << entry << " to " << (entry+lookAhead) << endl;            
        // cout << "    " << theData[entry].perfSoFar << " to " << theData[entry+lookAhead].perfSoFar << endl;
        double actualGain = theData[entry+lookAhead].perfSoFar - theData[entry].perfSoFar;
        double predictedGain = theData[entry].predictedPerf2Go;// * (lookAhead / (double)rounds2Go);
        // cout << "   " << actualGain << endl;
        // cout << "   " << predictedGain << endl;

        if (predictedGain != 0.0)
            return (actualGain / predictedGain);
        else
            return 0.0;
    }

    double sampleReturn_Friend(int entry, int rounds2Go) {
        int lookAhead = rounds2Go;
        if (rounds2Go > (theData[entry].endIndex - entry))
            lookAhead = theData[entry].endIndex - entry;

        double actualGainMe = theData[entry+lookAhead].perfSoFar - theData[entry].perfSoFar;
        double actualGainThem = theData[entry+lookAhead].theirPerfSoFar - theData[entry].theirPerfSoFar;
        double mn = actualGainMe;
        if (actualGainMe > actualGainThem)
            mn = actualGainThem;
        if (lookAhead > 0)
            return (actualGainMe + actualGainThem + mn) / lookAhead;
        else
            return 0.0;
    }

    double sampleReturn_Self(int entry, int rounds2Go) {
        int lookAhead = rounds2Go;
        if (rounds2Go > (theData[entry].endIndex - entry))
            lookAhead = theData[entry].endIndex - entry;

        double actualGainMe = theData[entry+lookAhead].perfSoFar - theData[entry].perfSoFar;

        if (lookAhead > 0)
            return actualGainMe / lookAhead;
        else
            return 0.0;
    }

    double sampleReturnProb_Self(int entry, int rounds2Go, double _aspiration) {
        int lookAhead = rounds2Go;
        if (rounds2Go > (theData[entry].endIndex - entry))
            lookAhead = theData[entry].endIndex - entry;

        double actualGainMe = theData[entry+lookAhead].perfSoFar - theData[entry].perfSoFar;

        double val = 0.0;
        if (lookAhead > 0)
            val = actualGainMe / lookAhead;

        if (val >= _aspiration)
            return 1.0;
        else
            return 0.0;
    }

    double sampleReturn_Competitor(int entry, int rounds2Go) {
        int lookAhead = rounds2Go;
        if (rounds2Go > (theData[entry].endIndex - entry))
            lookAhead = theData[entry].endIndex - entry;

        double actualGainMe = theData[entry+lookAhead].perfSoFar - theData[entry].perfSoFar;
        double actualGainThem = theData[entry+lookAhead].theirPerfSoFar - theData[entry].theirPerfSoFar;

        double diff = actualGainMe - actualGainThem;
        // if (diff > 0.0)
        //     diff = 0.0;

        if (lookAhead > 0)
            return diff / lookAhead; //(actualGainMe + diff) / lookAhead;
        else
            return 0.0;
    }

    double getChangeValue(int entry) {
        int j = entry + 1;
        int i = j;
        while ((theData[i].id == theData[j].id) && (i < theData.size()))
            i++;
        double actualGainMe = (theData[i-1].perfSoFar - theData[entry].perfSoFar) / (theData[i-1].t - theData[entry].t);

        return actualGainMe;
    }

    double getChangeFriendValue(int entry) {
        int j = entry + 1;
        int i = j;
        while ((theData[i].id == theData[j].id) && (i < theData.size()))
            i++;
        double actualGainMe = (theData[i-1].perfSoFar - theData[entry].perfSoFar) / (theData[i-1].t - theData[entry].t);
        double actualGainThem = (theData[i-1].theirPerfSoFar - theData[entry].theirPerfSoFar) / (theData[i-1].t - theData[entry].t);
        double mn = actualGainMe;
        if (actualGainMe > actualGainThem)
            mn = actualGainThem;
        
        return actualGainMe + actualGainThem + mn;
    }

    double getChangeCompetitorValue(int entry) {
        int j = entry + 1;
        int i = j;
        while ((theData[i].id == theData[j].id) && (i < theData.size()))
            i++;
        double actualGainMe = (theData[i-1].perfSoFar - theData[entry].perfSoFar) / (theData[i-1].t - theData[entry].t);
        double actualGainThem = (theData[i-1].theirPerfSoFar - theData[entry].theirPerfSoFar) / (theData[i-1].t - theData[entry].t);

        double diff = actualGainMe - actualGainThem;
        if (diff > 0.0)
            diff = 0.0;
        
        return actualGainMe + diff;
    }

    double getTransitions(vector<pqNode> nn, vector<double> &sprime, int timeStep) {
        if (nn.size() == 0) {
            cout << "no nearest neighbors" << endl;
            exit(1);
        }

        // initialize sprime
        for (int i = 0; i < theData[nn[0].index].checkerVals.size(); i++) {
            sprime.push_back(0.0);
        }

        double immReward = 0.0, mag = 0.0;
        for (int i = 0; i < nn.size(); i++) {
            // find the lookahead
            int ind = nn[i].index;
            while ((theData[ind+1].id == theData[nn[i].index].id) && ((ind - nn[i].index) < timeStep))
                ind ++;

            int lookAhead = ind - nn[i].index;

            if (lookAhead == 0) {
                cout << "0 lookAhead" << endl;
                exit(1);
            }

            double actualGain = (theData[nn[i].index+lookAhead].perfSoFar - theData[nn[i].index].perfSoFar) * ((timeStep)/(double)lookAhead);
            // cout << "actualGain (" << theData[nn[i].index].id << "): " << actualGain << endl;
            // cout << "     lookAhead: " << lookAhead << endl;
            // cout << "     t: " << theData[nn[i].index].t << endl;
            double w = getWeight(nn[i].dist, nn[nn.size()-1].dist, nn[0].dist);
            immReward += actualGain * w;
            mag += w;

            for (int j = 0; j < sprime.size(); j++) {
                sprime[j] += w * theData[nn[i].index+lookAhead].checkerVals[j];
            }
        }

        for (int j = 0; j < sprime.size(); j++) {
            sprime[j] /= mag;
        }

        return immReward / mag;
    }

    double getWeight(double dist) {//, double mxDist, double mnDist) {
        double weight = 1.0 / (1.0 + (dist * dist * dist * dist * dist));

        return weight;
        // double weight = 0.0000000001;
        // if (mxDist != mnDist)
        //     weight += (mxDist - val) / (mxDist - mnDist);

        // return weight * weight;
    }

    double getWeight(double val, double mxDist, double mnDist) {
        double weight = 0.01;
        if (mxDist != mnDist)
            weight += (mxDist - val) / (mxDist - mnDist);

        return weight * weight;
    }

    vector<double> averageCheckerState(vector<Player *> generators, int _t) {
        vector<double> aveCheckerVals, losCounts;
        for (int i = 0; i < theData[0].checkerVals.size(); i++) {
            aveCheckerVals.push_back(0.0);
            losCounts.push_back(0.0);
        }

        // cout << "num generators: " << generators.size() << endl;

        for (int i = 0; i < theData.size(); i++) {
            if (theData[i].t == _t) {
                // find out which generator index it is
                int genInd = getGeneratorIndex(generators, theData[i].genName);
                // cout << genInd << endl;

                // add in the counts and the checkerVals
                // cout << "checker mask:";
                for (int j = 0; j < theData[i].checkerVals.size(); j++) {
                    // cout << " " << generators[genInd]->checkerMask[j];
                    if (theData[i].checkerVals[j] > 1.0)
                        cout << "way fishy: " << theData[i].checkerVals[j] << " (" << theData[i].id << ")" << endl;
                    aveCheckerVals[j] += generators[genInd]->checkerMask[j] * theData[i].checkerVals[j];
                    losCounts[j] += generators[genInd]->checkerMask[j];
                }
            }
        }

        cout << "average checker vals:";
        for (int i = 0; i < aveCheckerVals.size(); i++) {
            if (losCounts[i] > 0.0)
                aveCheckerVals[i] /= losCounts[i];
            else
                cout << "*fishy*";

            cout << " " << aveCheckerVals[i];
        }
        cout << endl;

        return aveCheckerVals;
    }

    int getGeneratorIndex(vector<Player *> generators, string genName) {
        for (int i = 0; i < generators.size(); i++) {
            string str = generators[i]->nickname;
            if (str == genName)
                return i;
        }

        cout << "didn't find generators: " << genName << endl;
        exit(1);

        return -1;
    }

    void divideData(DataSet &dataSameGen, DataSet &dataDiffGen, int gameLength) {
        int entriesPerGame = gameLength + 1;
        for (int i = 0; i < theData.size(); i += entriesPerGame) {
            string genStr = theData[i+1].genName;
            bool distinct = false;
            int k;
            for (int j = i+2; j < i+entriesPerGame; j++) {
                if (theData[j].genName != genStr) {
                    // cout << "distinct is true" << endl;
                    distinct = true;
                    k = j-1;
                    break;
                }
            }

            if (!distinct) {
                for (int j = i; j < i+entriesPerGame; j++) {
                    dataSameGen.theData.push_back(theData[j]);
                }
            }
            else {
                int staple = dataSameGen.theData.size();
                for (int j = k; j < i+entriesPerGame; j++) {
                    dataSameGen.theData.push_back(theData[j]);
                }
                // dataSameGen.theData[staple].genName = genStr;
                dataSameGen.theData[staple].genName = dataSameGen.theData[dataSameGen.theData.size()-1].genName;
            }
        }

        // cout << "recompute endIndex" << endl;

        // recompute the endIndex for each entry
        for (int i = 0; i < dataSameGen.theData.size(); i++) {
            dataSameGen.theData[i].endIndex = dataSameGen.getIndexOfActual2GoPayout(i);
            // cout << i << " << " << dataSameGen.theData[i].endIndex << endl;
            if ((dataSameGen.theData[i].endIndex - i) > 20) {
                cout << "id: " << dataSameGen.theData[i].id << endl;
                cout << "t: " << dataSameGen.theData[i].t << endl;
                cout << "to" << endl;
                cout << "id: " << dataSameGen.theData[dataSameGen.theData[i].endIndex].id << endl;
                cout << "t: " << dataSameGen.theData[dataSameGen.theData[i].endIndex].t << endl;
                exit(1);
            }
        }

        // for (int i = 0; i < dataSameGen.theData.size(); i++) {
        //     cout << i << ": " << dataSameGen.theData[i].id << " " << dataSameGen.theData[i].t << " " << dataSameGen.theData[i].endIndex << " " << dataSameGen.theData[i].genName << endl;
        // }
        // exit(1);

    }

    vector<DataEntry> theData;
};

#endif
