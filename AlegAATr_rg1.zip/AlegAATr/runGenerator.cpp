#include "runGenerator.h"

runGenerator::runGenerator() {
    cout << "Incomplete runGenerator constructor" << endl;
    exit(1);
}

runGenerator::runGenerator(string _genStr, int _plyrNum, MarkovGame *_mg) {
    plyrNum = _plyrNum;
    mg = _mg;
    computeMGThings();

    createGenerator(_genStr);
}

runGenerator::~runGenerator() {
    delete generators[0];
}

int runGenerator::makeMove(State *s) {
    return generators[0]->Move(s);
}

void runGenerator::updateAfterMove(State *s, int actions[2]) {
    generators[0]->moveUpdate(s, actions);
}

void runGenerator::updateRound() {
    generators[0]->roundUpdate(true);

    cout << "\nCheckers for " << generators[0]->nickname << " (" << generators[0]->checkers.size() << ")" << endl;
    for (int j = 0; j < generators[0]->checkers.size(); j++) {
        generators[0]->checkers[j]->print();
    }
}

void runGenerator::createGenerator(string _genStr) {
    char tipito[1024];

    cout << "Generator: " << _genStr << endl;
    if (_genStr == "cfr") {
        generators.push_back(new CFR(plyrNum, mg, 40, false));
    }
    else if (_genStr == "maxmin") {
        strcpy(tipito, "maxmin");
        generators.push_back(new Xprt(plyrNum, mg, tipito));
    }
    else if (_genStr == "coop") {
        strcpy(tipito, "coop");
        generators.push_back(new Xprt(plyrNum, mg, tipito));
    }
    else if (_genStr == "coopp") {
        strcpy(tipito, "coopp");
        generators.push_back(new Xprt(plyrNum, mg, tipito));
    }
    else if (_genStr == "bullyp") {
        strcpy(tipito, "bullyp");
        generators.push_back(new Xprt(plyrNum, mg, tipito));
    }
    else if (_genStr == "bullied") {
        strcpy(tipito, "bullied");
        generators.push_back(new Xprt(plyrNum, mg, tipito));
    }
    else {
        cout << "generator " << _genStr << " not found" << endl;
    }
}
