#ifndef TRAININGASSOCIATE_H
#define TRAININGASSOCIATE_H

#include "defs.h"
#include "AbstractAlegAATr.h"
#include "MarkovGame.h"
#include "State.h"
#include "CFR.h"
#include "Xprt.h"

using namespace std;

#define STATIONARY      0
#define COURNOT         1
#define FAIR            2
#define STACKELBERG     3

class TrainingAssociate : public AbstractAlegAATr {
public:
    TrainingAssociate();
    TrainingAssociate(int _plyrNum, MarkovGame *_mg);
    ~TrainingAssociate();

    int makeMove(State *s);
    void updateAfterMove(State *s, int actions[2]);
    void updateRound();

    void configureTrainingRun(string _genStart, double _switchProb, int _tipo, AbstractAlegAATr *_trainee);
    void setGenVsGen(double _genM[10][10][2], int _numRounds);
    int getBestResponse(int quien, int a);

    int switchGenerator(int alegaatr);

    // void createGenerators(vector<string> genConfig);
    // vector<string> readGeneratorConfig();

private:
    AbstractAlegAATr *trainee;
    int prevTraineeGen, curTraineeGen;
    int lastTraineeGenChange, lastSelfGenChange;

    int t;
    int theGenStart, tipo, numRounds;
    double switchProb;
   
    double genM[10][10][2];
    double myAttackedVal, myStackelberguedVal, myCFRVal, hisCFRVal;
};

#endif