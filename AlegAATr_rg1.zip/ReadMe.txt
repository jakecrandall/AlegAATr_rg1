This code is designed to run two players in repeated games of chicken, prisoner's dilemma, and the block dilemma, do the following:

The code compiles on MacOS (and should also work in Linux).

1.  Compile the code.  

From the AlegAATr directory, type "make" in the terminal, which will compile the code using the makefile

Code for a GUI of a human player is also available in Java (in the SimulatedHuman directory).  Compile with: javac humanPlyr.java

2.  Run the code.

Navigate to the AlegAATr directory in the terminal.  Type:

./play game [game] [numRounds] [agent0] [agent1]

Parameters:

[game] :  Can be prisoners, chicken, or blockDilemma
[numRounds] : Number of rounds in the game
[agent0] : Player type of first agent
[agent1] : Player type of second agent

[agent0] and [agent1] can be: alegaatr, eee, spp, bbl, or human.  Additional static agents can be invoked (see the createPlayer function in runGame.cpp)

If human is invoked, a separate program must be run.  This program pulls up a GUI in which a human player can select actions.

To run this program, navigate to the SimulatedHuman directory, and compile the java program:

javac javaPlyr.java

To then run the program, type:

java humanPlyr [agentID]

where agentID is 0 for the first player and 1 for the second player